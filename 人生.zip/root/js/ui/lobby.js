import { Game, mount, navigate, openModal, closeModal, toast, injectStyle } from '../main.js';
import { getSlots } from '../core/storage.js';
import { WORLD, STREETS } from '../data/world.js';

export function renderLobby() {
  injectStyle(lobbyStyle(), 'lobby');
  const screen = document.createElement('div');
  screen.className = 'screen';
  screen.style.background = 'var(--bg-gradient)';

  const inner = document.createElement('div');
  inner.className = 'content-center';
  inner.style.cssText = 'display:flex;flex-direction:column;align-items:center;padding:30px;text-align:center;';
  inner.style.animation = 'floatUp 0.5s ease-in-out';

  inner.innerHTML = `
    <div class="font-kai lobby-title">此间少年行</div>
    <div class="lobby-divider"></div>
    <div class="lobby-studio">清姈工作室</div>
    <div style="height:36px;"></div>
    <button class="btn btn-primary lobby-btn" id="lbStart">开始游戏</button>
    <button class="btn lobby-btn" id="lbGuide">玩法记录</button>
    <button class="btn lobby-btn" id="lbSave">存档</button>
    <button class="btn lobby-btn" id="lbSettings">设置</button>
    <div style="flex:1;min-height:20px;"></div>
    <div style="color:var(--text-faint);font-size:12px;letter-spacing:2px;">v3.0 · 献给每一个正在长大的少年</div>
  `;

  inner.querySelector('#lbStart').addEventListener('click', () => {
    navigate('creation', true);
  });

  inner.querySelector('#lbGuide').addEventListener('click', () => {
    showGuide();
  });

  inner.querySelector('#lbSave').addEventListener('click', () => {
    import('./panels.js').then((m) => m.openSavePanel(Game.state, true));
  });

  inner.querySelector('#lbSettings').addEventListener('click', () => {
    import('./panels.js').then((m) => m.openSettingsPanel(Game.state, () => renderLobby()));
  });

  screen.appendChild(inner);
  mount(screen);
}

function showGuide() {
  const content = document.createElement('div');
  content.className = 'modal-body';
  content.style.cssText = 'padding:0;';

  content.innerHTML = `
    <div class="guide-wrap">
      <h3 class="guide-h">四大发展方向</h3>
      <div class="guide-dir">
        <div class="guide-card" style="border-left:4px solid var(--accent);">
          <div class="guide-name">事业</div>
          <div>从打工到职场，从兴趣到职业。你可以选择成为医生、艺术家、创业者……在云栖市闯出一片天地。</div>
        </div>
        <div class="guide-card" style="border-left:4px solid var(--mist);">
          <div class="guide-name">恋爱</div>
          <div>六十多位性格各异的角色等待与你相识。友谊、爱意与恨意三条数值线，决定每一段关系的走向。</div>
        </div>
        <div class="guide-card" style="border-left:4px solid var(--sage);">
          <div class="guide-name">亲情</div>
          <div>被收养的你，与许临安之间将建立怎样的羁绊？家是港湾，也可能是最复杂的命题。</div>
        </div>
        <div class="guide-card" style="border-left:4px solid var(--butter);">
          <div class="guide-name">友情</div>
          <div>校园里的同窗、街角的店长、教堂里的少年……每一段友情都可能改变你的人生轨迹。</div>
        </div>
      </div>
      <h3 class="guide-h">云栖市简介</h3>
      <p class="guide-p">${WORLD.intro}</p>
      <h3 class="guide-h">城市布局</h3>
      <div class="guide-streets">
        ${STREETS.map((s) => `<span class="tag" style="margin:2px;">${s.name}</span>`).join('')}
      </div>
      <p class="guide-p" style="font-size:13px;color:var(--text-secondary);">
        六条主街呈"井"字形交叉排列，将城市划分为商业区、行政区、住宅区、工业区、娱乐区与教育区。
        更多城市信息，可在游戏内的【日志→世界观】中查阅。
      </p>
    </div>
  `;

  const { card } = openModal(content, {});
  card.style.maxWidth = '540px';
  card.querySelector('.modal-body').style.cssText = 'padding:0;overflow-y:auto;';
}

export function lobbyStyle() {
  return `
    .lobby-title { font-size: 46px; letter-spacing: 12px; color: var(--text-primary); text-shadow: 0 2px 18px rgba(255,255,255,0.6); margin-bottom: 4px; }
    .lobby-divider { width: 180px; height: 1px; background: linear-gradient(90deg, transparent, var(--accent), transparent); margin: 14px 0 10px; }
    .lobby-studio { font-size: 13px; letter-spacing: 8px; color: var(--text-secondary); margin-bottom: 12px; }
    .lobby-btn { width: 220px; height: 52px; margin: 8px 0; border-radius: var(--radius-md); font-size: 15px; letter-spacing: 6px; }
    .guide-wrap { padding: 18px 20px; }
    .guide-h { font-size: 15px; margin: 16px 0 10px; color: var(--accent-deep); letter-spacing: 2px; }
    .guide-h:first-child { margin-top: 6px; }
    .guide-dir { display: flex; flex-direction: column; gap: 8px; }
    .guide-card { background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 14px; font-size: 13px; line-height: 1.7; color: var(--text-primary); }
    .guide-name { font-weight: 700; font-size: 14px; margin-bottom: 4px; letter-spacing: 2px; }
    .guide-p { font-size: 14px; line-height: 1.8; color: var(--text-primary); }
    .guide-streets { margin-bottom: 6px; }
  `;
}
