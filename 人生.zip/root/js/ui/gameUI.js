import { Game, mount, navigate, openModal, closeModal, toast, injectStyle } from '../main.js';
import { saveState } from '../core/storage.js';
import { getScene, advanceScene, pushHistory, aiGenerateNarrative } from '../core/narrative.js';
import { getInfoBar } from '../core/time.js';
import { getPlayer } from '../core/state.js';
import { CHARACTERS } from '../data/characters.js';
import { charGender, gendText } from '../core/gender.js';

let narrativeState = { typing: false, busy: false };
let swipeStartX = null;
let tipTimer = null;

export function renderGameUI() {
  injectStyle(gameStyle(), 'gameUI');
  const screen = document.createElement('div');
  screen.className = 'screen game-screen';
  screen.style.background = 'var(--bg-gradient)';

  screen.innerHTML = `
    <div class="game-stage" id="gameStage">
      <div class="narrative-area" id="narrativeArea"></div>
      <div class="free-area" id="freeArea" style="display:none;"></div>
      <div class="action-bar">
        <input type="text" id="playerAction" placeholder="输入你的行动，然后发送…" maxlength="120">
        <button class="btn btn-sm btn-primary" id="actionSend">发送</button>
      </div>
      <button class="sidebar-toggle" id="sidebarToggle"><span class="st-glow"></span>‹</button>
      <div class="float-phone" id="floatPhone">📱</div>
      <div class="float-bag" id="floatBag">🎒</div>
      <div class="sidebar" id="sidebar"></div>
    </div>`;

  mount(screen);

  const stage = screen.querySelector('#gameStage');
  const narrativeArea = screen.querySelector('#narrativeArea');
  const freeArea = screen.querySelector('#freeArea');
  const sidebarToggle = screen.querySelector('#sidebarToggle');
  const floatPhone = screen.querySelector('#floatPhone');
  const floatBag = screen.querySelector('#floatBag');
  const sidebar = screen.querySelector('#sidebar');
  const actionInput = screen.querySelector('#playerAction');
  const actionSend = screen.querySelector('#actionSend');

  buildSidebar(sidebar);
  renderScene();
  startDynamicTips(sidebar);

  sidebarToggle.addEventListener('click', () => {
    sidebar.classList.toggle('open');
    syncToggle();
  });
  function syncToggle() {
    const open = sidebar.classList.contains('open');
    sidebarToggle.classList.toggle('expanded', open);
    sidebarToggle.innerHTML = `<span class="st-glow"></span>${open ? '›' : '‹'}`;
  }
  syncToggle();
  // 右滑展开 / 点击左侧上边缘展开
  stage.addEventListener('touchstart', (e) => {
    if (sidebar.classList.contains('open')) return;
    if (e.touches[0].clientX < 46) swipeStartX = e.touches[0].clientX;
    else swipeStartX = null;
  }, { passive: true });
  stage.addEventListener('touchmove', (e) => {
    if (swipeStartX != null && !sidebar.classList.contains('open')) {
      const dx = e.touches[0].clientX - swipeStartX;
      if (dx > 56) {
        swipeStartX = null;
        sidebar.classList.add('open');
      }
    }
  }, { passive: true });
  stage.addEventListener('touchend', () => { swipeStartX = null; });
  sidebar.addEventListener('click', (e) => {
    if (e.target === sidebar) sidebar.classList.remove('open');
  });

  floatPhone.addEventListener('click', openPhone);
  floatBag.addEventListener('click', () => {
    import('./panels.js').then((m) => m.openBagPanel(Game.state, () => {}));
  });

  function renderScene() {
    const s = Game.state;
    const scene = getScene(s);
    if (scene.id === 'free') {
      narrativeArea.style.display = 'none';
      freeArea.style.display = 'block';
      renderFreeMode();
    } else {
      freeArea.style.display = 'none';
      narrativeArea.style.display = 'block';
      renderNarrative(scene);
    }
  }

  function renderNarrative(scene) {
    narrativeState.busy = false;
    narrativeArea.innerHTML = '';
    const card = document.createElement('div');
    card.className = 'narrative-card';

    const titleEl = document.createElement('div');
    titleEl.className = 'narrative-title font-kai';
    titleEl.textContent = scene.title;
    card.appendChild(titleEl);

    const divider = document.createElement('div');
    divider.className = 'narrative-divider';
    card.appendChild(divider);

    const textWrap = document.createElement('div');
    textWrap.className = 'narrative-text';
    card.appendChild(textWrap);

    const choicesEl = document.createElement('div');
    choicesEl.className = 'narrative-choices';
    card.appendChild(choicesEl);

    narrativeArea.appendChild(card);

    typewriter(textWrap, scene.text, () => {
      renderChoices(scene, choicesEl);
    });
  }

  function renderChoices(scene, container) {
    narrativeState.busy = false;
    container.innerHTML = '';
    (scene.options || []).forEach((opt) => {
      const btn = document.createElement('button');
      btn.className = 'btn btn-ghost choice-btn';
      btn.textContent = opt.text;
      btn.addEventListener('click', () => {
        if (narrativeState.busy) return;
        choose(scene, opt.id);
      });
      container.appendChild(btn);
    });
  }

  function choose(scene, choiceId) {
    const s = Game.state;
    const next = advanceScene(s, choiceId);
    if (choiceId === 'free') {
      narrativeState.busy = true;
      saveState(s);
      renderScene();
      return;
    }
    narrativeState.busy = true;
    // 打字机推进效果：淡出后渲染下一幕
    const card = narrativeArea.querySelector('.narrative-card');
    if (card) {
      card.style.transition = 'opacity 0.25s ease-in-out';
      card.style.opacity = '0';
    }
    saveState(s);
    setTimeout(() => {
      renderScene();
    }, 250);
  }

  // ===== 自由模式 =====
  function renderFreeMode() {
    const s = Game.state;
    const p = getPlayer(s);
    freeArea.innerHTML = '';
    const wrap = document.createElement('div');
    wrap.className = 'free-wrap';

    const greet = document.createElement('div');
    greet.className = 'free-greet font-kai';
    greet.textContent = `${p.nickname}，今天想做什么？`;
    wrap.appendChild(greet);

    const tip = document.createElement('div');
    tip.className = 'free-tip';
    tip.textContent = '在下方输入框输入你的行动，发送后推进剧情。';
    wrap.appendChild(tip);

    freeArea.appendChild(wrap);
  }

  function openPhone() {
    import('../phone/index.js').then((m) => m.openPhone(Game.state, { onClose: () => {} }));
  }

  // ===== 中央文本区行动输入框：发送键 → 用户输入自己的行动 =====
  function sendPlayerAction() {
    if (narrativeState.busy) return toast('正在生成剧情，请稍候');
    const text = actionInput.value.trim();
    if (!text) return;
    actionInput.value = '';
    const s = Game.state;
    const isFree = freeArea.style.display !== 'none';
    let container;
    if (isFree) {
      container = freeArea.querySelector('.free-wrap');
    } else {
      let msgWrap = narrativeArea.querySelector('.narrative-messages');
      if (!msgWrap) {
        msgWrap = document.createElement('div');
        msgWrap.className = 'narrative-messages';
        narrativeArea.appendChild(msgWrap);
      }
      container = msgWrap;
    }
    const actionEl = document.createElement('div');
    actionEl.className = 'user-action';
    actionEl.textContent = '你：' + text;
    container.appendChild(actionEl);
    const resultEl = document.createElement('div');
    resultEl.className = 'ai-result';
    container.appendChild(resultEl);
    (isFree ? freeArea : narrativeArea).scrollTop = (isFree ? freeArea : narrativeArea).scrollHeight;
    actionSend.disabled = true;
    actionSend.textContent = '…';
    aiGenerateNarrative(s, text).then((story) => {
      typewriter(resultEl, story, () => {});
      pushHistory(s, '自由剧情', story);
      saveState(s);
      actionSend.disabled = false;
      actionSend.textContent = '发送';
    });
  }
  actionSend.addEventListener('click', sendPlayerAction);
  actionInput.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendPlayerAction(); });
}

function maxHP(p) {
  return Math.max(1, Math.round(50 + p.attributes.con * 5 + (p.stats.sta || 0) * 0.2));
}

function typewriter(el, text, done, onSkip) {
  const segments = parseSegments(text);
  narrativeState.typing = true;

  const all = document.createElement('div');
  all.className = 'narrative-flow';
  el.appendChild(all);

  let finished = false;
  let idx = 0;
  let timer = null;

  function renderSegment(seg) {
    if (seg.type === 'note') {
      const note = document.createElement('div');
      note.className = 'narrative-note ' + (seg.kind || 'note');
      note.innerHTML = `<div class="note-inner"><div class="note-title">${NOTE_TITLES[seg.kind] || '📜 纸条'}</div><div class="note-text"></div></div>`;
      const textEl = note.querySelector('.note-text');
      all.appendChild(note);
      typeNote(textEl, seg.text, () => {});
      return;
    }
    if (seg.type === 'bubble') {
      const s = document.createElement('span');
      s.className = 'bubble';
      s.innerHTML = `<span class="bubble-name">${seg.speaker || '说话的人'}</span><span class="bubble-txt"></span>`;
      all.appendChild(s);
      typeChars(s.querySelector('.bubble-txt'), seg.text, () => {});
      return;
    }
    const s = document.createElement('span');
    s.className = 'narrative-para';
    all.appendChild(s);
    typeChars(s, seg.text, () => {});
  }

  function typeNote(el, text, doneNote) {
    const chars = text.split('');
    let i = 0;
    const iv = setInterval(() => {
      if (i >= chars.length) { clearInterval(iv); doneNote && doneNote(); return; }
      el.textContent += chars[i++];
      if (el.parentElement) el.parentElement.scrollTop = el.parentElement.scrollHeight;
    }, 14);
    notesTimers.push(iv);
  }

  function typeChars(el, text, doneSeg) {
    const chars = text.split('');
    let i = 0;
    const iv = setInterval(() => {
      if (i >= chars.length) { clearInterval(iv); doneSeg && doneSeg(); return; }
      el.textContent += chars[i++];
      if (el.parentElement) el.parentElement.scrollTop = el.parentElement.scrollHeight;
    }, 18);
    segTimers.push(iv);
  }

  const segTimers = [];
  const notesTimers = [];
  let segIdx = 0;
  function stepSeg() {
    if (segIdx >= segments.length) {
      narrativeState.typing = false;
      done && done();
      return;
    }
    renderSegment(segments[segIdx++]);
    timer = setTimeout(stepSeg, 260);
  }
  stepSeg();

  const skip = () => {
    if (finished) return;
    finished = true;
    clearInterval(timer);
    segTimers.forEach(clearInterval);
    notesTimers.forEach(clearInterval);
    all.innerHTML = '';
    let rest = '';
    segments.forEach((seg) => {
      if (seg.type === 'bubble') {
        const s = document.createElement('span');
        s.className = 'bubble';
        s.innerHTML = `<span class="bubble-name">${seg.speaker || '说话的人'}</span><span class="bubble-txt">${seg.text}</span>`;
        all.appendChild(s);
      } else if (seg.type === 'note') {
        const note = document.createElement('div');
        note.className = 'narrative-note ' + (seg.kind || 'note');
        note.innerHTML = `<div class="note-inner"><div class="note-title">${NOTE_TITLES[seg.kind] || '📜 纸条'}</div><div class="note-text">${seg.text}</div></div>`;
        all.appendChild(note);
      } else {
        const s = document.createElement('span');
        s.className = 'narrative-para';
        s.textContent = seg.text;
        all.appendChild(s);
      }
    });
    narrativeState.typing = false;
    done && done();
  };
  el.addEventListener('click', skip);
}

const NOTE_TITLES = { note: '📜 纸条', love: '💌 情书', letter: '✉️ 信', bookmark: '📖 书签', flower: '🌸 花束' };

// 从引号前的文本中推测说话人（角色名 / 称谓）
const SPEAKER_POOL = (() => {
  const names = (CHARACTERS || []).map((c) => c.name);
  const titles = ['院长', '老师', '同学', '邻居', '店员', '老板', '店主', '朋友', '社工', '朋友', '同事'];
  return [...new Set([...names, ...titles])];
})();

function detectSpeaker(prefix) {
  let best = '';
  let bestIdx = -1;
  SPEAKER_POOL.forEach((n) => {
    const idx = prefix.lastIndexOf(n);
    if (idx > bestIdx) { bestIdx = idx; best = n; }
  });
  return best || '';
}

function parseSegments(text) {
  const out = [];
  let rest = text;
  const re = /【纸条】(.*?)【\/纸条】|【情书】(.*?)【\/情书】|【信】(.*?)【\/信】|【书签】(.*?)【\/书签】|【花束】(.*?)【\/花束】|「([^」]+)」/g;
  let last = 0;
  let m;
  let buffer = '';
  const flush = () => { if (buffer.trim()) { out.push({ type: 'text', text: buffer }); } buffer = ''; };
  const kinds = ['note', 'love', 'letter', 'bookmark', 'flower'];
  while ((m = re.exec(text)) !== null) {
    if (m.index > last) buffer += text.slice(last, m.index);
    let kind = null;
    for (let k = 0; k < kinds.length; k++) {
      if (m[k + 1] != null) { kind = kinds[k]; break; }
    }
    if (kind) {
      flush();
      out.push({ type: 'note', kind, text: m[kinds.indexOf(kind) + 1] });
    } else if (m[6] != null) {
      buffer += '「';
      flush();
      out.push({ type: 'bubble', text: m[6], speaker: detectSpeaker(text.slice(0, m.index)) });
    }
    last = m.index + m[0].length;
  }
  if (last < text.length) buffer += text.slice(last);
  flush();
  const merged = out.filter((s) => s.text && s.text.trim());
  if (!merged.length) merged.push({ type: 'text', text });
  return merged;
}

function buildSidebar(sidebar) {
  const s = Game.state;
  const p = getPlayer(s);
  // 侧边栏栏目：第1行1个，第2行2个，第3行2个，第4行2个，第5行1个
  const groups = [
    [
      { icon: '⭐', label: '属性', cls: 'panel-attr', fn: () => import('./panels.js').then((m) => m.openAttrPanel(s)) },
    ],
    [
      { icon: '💬', label: '社交', cls: 'panel-social', fn: () => import('./panels.js').then((m) => m.openSocialPanel(s)) },
      { icon: '📔', label: '日志', cls: 'panel-journal', fn: () => import('./panels.js').then((m) => m.openJournalPanel(s)) },
    ],
    [
      { icon: '🏅', label: '成就', cls: 'panel-achievements', fn: () => import('./panels.js').then((m) => m.openAchievePanel(s)) },
      { icon: '💾', label: '存档', cls: 'panel-save', fn: () => import('./panels.js').then((m) => m.openSavePanel(s)) },
    ],
    [
      { icon: '📦', label: '模组', cls: 'panel-mods', fn: () => import('./panels.js').then((m) => m.openModPanel(s)) },
      { icon: '🃏', label: '作弊', cls: 'panel-cheat', fn: () => import('./panels.js').then((m) => m.openCheatPanel(s)) },
    ],
    [
      { icon: '⚙️', label: '设置', cls: 'panel-settings', fn: () => import('./panels.js').then((m) => m.openSettingsPanel(s)) },
    ],
  ];

  const info = getInfoBar(s);
  const maxes = { hp: maxHP(p), ep: 200, sat: 100, cln: 100, sta: 200, stress: 100 };
  const statRows = [
    ['hp', '生命'], ['ep', '精力'], ['sat', '饱腹'],
    ['cln', '清洁'], ['sta', '体能'], ['stress', '压力'],
  ].map(([k, label]) => {
    const v = p.stats[k];
    const pct = Math.max(0, Math.min(100, (v / maxes[k]) * 100));
    const color = k === 'stress'
      ? (v > 70 ? 'var(--danger)' : v > 40 ? 'var(--warn)' : 'var(--good)')
      : (pct > 50 ? 'var(--good)' : pct > 25 ? 'var(--warn)' : 'var(--danger)');
    return `
      <div class="sb-stat">
        <span class="sb-stat-name">${label}</span>
        <div class="sb-stat-bar"><div class="sb-stat-fill" style="width:${pct}%;background:${color};"></div></div>
        <span class="sb-stat-val">${Math.round(v)}%</span>
      </div>`;
  }).join('');

  sidebar.innerHTML = `
    <div class="sidebar-profile">
      <button class="sidebar-avatar" id="sbAvatar">${p.name.slice(0, 1)}</button>
      <div class="sidebar-name">${p.name} <span style="font-size:11px;color:var(--text-secondary);">${p.age}岁</span></div>
    </div>
    <div class="sidebar-info" title="${info.date} ${info.location}">${info.month}月${info.day}号 ${info.period} ${info.weather} ${info.season}季 ${info.shortLocation} ¥${info.money}</div>
    <div class="sidebar-status">${statRows}</div>
    <div class="sidebar-tips" id="sbTips"></div>
    <div class="sidebar-groups">
      ${groups.map((row) => `
        <div class="sidebar-row">
          ${row.map((it) => `
            <button class="sidebar-item ${it.cls}" data-key="${it.label}">
              <span class="sidebar-ico">${it.icon}</span>
              <span class="sidebar-txt">${it.label}</span>
            </button>`).join('')}
        </div>`).join('')}
    </div>
  `;
  sidebar.querySelectorAll('.sidebar-item').forEach((el) => {
    const row = groups.flat();
    const item = row.find((x) => x.label === el.dataset.key);
    if (item) el.addEventListener('click', () => { item.fn(); });
  });
  sidebar.querySelector('#sbAvatar').addEventListener('click', () => showPortrait(s));
}

// 角色形象窗口：点击弹出全屏用户窗口，一行一个（头像/姓名/年龄/性别/外貌详情）
function showPortrait(s) {
  const p = getPlayer(s);
  const overlay = document.createElement('div');
  overlay.className = 'portrait-overlay';
  overlay.innerHTML = `
    <div class="portrait-card">
      <button class="portrait-close" id="portraitClose">✕</button>
      <div class="portrait-row p-row-avatar"><div class="portrait-avatar">${p.name.slice(0, 1)}</div></div>
      <div class="portrait-row"><span class="p-label">姓名</span><span class="p-val">${p.name}</span></div>
      <div class="portrait-row"><span class="p-label">年龄</span><span class="p-val">${p.age} 岁</span></div>
      <div class="portrait-row"><span class="p-label">性别</span><span class="p-val">${p.gender}</span></div>
      <div class="portrait-row"><span class="p-label">外貌详情</span><span class="p-val">${portraitAppearance(p)}</span></div>
    </div>`;
  overlay.querySelector('#portraitClose').addEventListener('click', () => overlay.remove());
  overlay.addEventListener('click', (e) => { if (e.target === overlay) overlay.remove(); });
  document.body.appendChild(overlay);
}

function portraitAppearance(p) {
  const parts = [];
  const h = p.hair || {};
  const bangs = h.bangs && h.bangs !== '无刘海' ? `，${h.bangs}${h.bangsLen || ''}` : '';
  const back = h.back ? `${h.back}${h.backLen || ''}` : '';
  parts.push(`${p.height || 165}cm、身形${p.figure}${p.aura ? `、气质${p.aura}` : ''}`);
  parts.push(`${back}${bangs}的发型`.replace(/^，/, ''));
  parts.push('眼眸清澈');
  if (p.marks && p.marks.length) {
    const names = { eyebrow: '眉心痣', 'eye-l-left': '左眼角痣', 'eye-l-down': '左眼睑痣', 'eye-r-left': '右眼角痣', 'eye-r-down': '右眼睑痣', 'mouth-l': '左侧嘴角痣', 'mouth-r': '右侧嘴角痣', nose: '鼻翼痣', collarbone: '锁骨痣' };
    const list = p.marks.map((id) => names[id]).filter(Boolean);
    if (list.length) parts.push(list.join('、'));
  }
  if (p.freckles > 0) parts.push(p.freckles >= 2 ? '面上点缀着明显雀斑' : '鼻翼有淡淡雀斑');
  return parts.join('，') + '。';
}

// 动态提示：最多保留5条，自动轮播
function startDynamicTips(sidebar) {
  const tipsEl = sidebar.querySelector('#sbTips');
  if (!tipsEl) return;
  const tips = () => (Game.state.narrative.history || []).slice(-5).map((h) => h.text).reverse();
  let idx = 0;
  function render() {
    if (!tipsEl || !tipsEl.parentElement) return;
    const list = tips();
    if (!list.length) { tipsEl.innerHTML = '<div class="sb-tip-empty">近期没有新的事件记录</div>'; return; }
    const text = list[idx % list.length];
    tipsEl.innerHTML = `<div class="sb-tip">${text.length > 46 ? text.slice(0, 46) + '…' : text}</div>`;
    idx = (idx + 1) % Math.max(1, list.length);
  }
  render();
  if (tipTimer) clearInterval(tipTimer);
  tipTimer = setInterval(render, 3500);
}

function gameStyle() {
  return `
    .game-screen { position: fixed; inset: 0; overflow: hidden; }
    .game-stage { position: relative; width: 100%; height: 100%; display: flex; flex-direction: column; align-items: center; }
    .narrative-area {
      position: absolute; top: 0; bottom: 0; left: 0; right: 0;
      display: flex; flex-direction: column; align-items: center;
      overflow-y: auto; padding: 0 16px 96px; z-index: 10;
    }
    .narrative-card {
      width: 100%; max-width: 540px;
      background: transparent;
      padding: 24px 22px;
      margin-top: 8px;
      animation: floatUp 0.4s ease-in-out;
    }
    .narrative-messages { width: min(100%, 540px); display: flex; flex-direction: column; padding: 0 22px 12px; }
    .narrative-title { font-size: 20px; letter-spacing: 4px; color: var(--accent-deep); text-align: center; }
    .narrative-divider { width: 90px; height: 1px; margin: 12px auto 16px; background: linear-gradient(90deg, transparent, var(--accent), transparent); }
    .narrative-text {
      font-size: var(--font-size, 16px);
      line-height: 1.8;
      color: var(--text-primary);
      white-space: pre-wrap;
      word-break: break-word;
    }
    .narrative-flow { display: block; width: 100%; }
    .narrative-para { display: block; text-indent: 0; }
    .bubble {
      display: inline-block;
      position: relative;
      background: rgba(255, 255, 255, 0.38);
      -webkit-backdrop-filter: blur(10px);
      backdrop-filter: blur(10px);
      border: 1.5px dashed rgba(127, 168, 201, 0.65);
      border-radius: 14px 14px 14px 4px;
      padding: 10px 14px 9px;
      margin: 16px 4px 6px;
      color: var(--accent-deep);
      font-weight: 600;
      box-shadow: 0 4px 14px rgba(100, 120, 140, 0.12);
      animation: bubbleIn 0.35s cubic-bezier(0.22, 1, 0.36, 1);
      letter-spacing: 1px;
    }
    .bubble-name {
      position: absolute;
      top: -12px; left: 8px;
      font-size: 11px;
      line-height: 1;
      padding: 3px 9px;
      background: var(--bg-top);
      border: 1.5px dashed rgba(127, 168, 201, 0.65);
      border-radius: 9px;
      color: var(--accent-deep);
      letter-spacing: 2px;
      font-weight: 600;
      box-shadow: 0 2px 6px rgba(100, 120, 140, 0.08);
    }
    .bubble::before {
      content: "";
      position: absolute; left: 12px; bottom: -6px;
      width: 11px; height: 11px;
      background: inherit;
      border-right: 1.5px dashed rgba(127, 168, 201, 0.65);
      border-bottom: 1.5px dashed rgba(127, 168, 201, 0.65);
      transform: rotate(45deg);
      border-radius: 2px;
      -webkit-backdrop-filter: blur(10px);
      backdrop-filter: blur(10px);
    }
    @keyframes bubbleIn { from { opacity: 0; transform: scale(0.86); } to { opacity: 1; transform: scale(1); } }
    .narrative-note {
      display: block; margin: 14px auto; width: min(86%, 320px);
      background: linear-gradient(160deg, rgba(255, 253, 247, 0.82), rgba(251, 246, 232, 0.72));
      -webkit-backdrop-filter: blur(12px);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(180, 160, 110, 0.35);
      border-radius: 6px;
      padding: 18px 16px 20px;
      box-shadow: 0 6px 22px rgba(90, 110, 130, 0.18), 2px 3px 0 rgba(0, 0, 0, 0.05);
      position: relative;
      transform: rotate(-1.2deg);
      animation: noteIn 0.7s cubic-bezier(0.22, 1, 0.36, 1), noteSway 6s ease-in-out 0.7s infinite;
    }
    .narrative-note.love {
      background: linear-gradient(160deg, rgba(255, 245, 245, 0.84), rgba(255, 237, 239, 0.74));
      border: 1px solid rgba(200, 130, 140, 0.4);
      transform: rotate(1.4deg);
      animation: noteInLove 0.7s cubic-bezier(0.22, 1, 0.36, 1), noteSwayLove 6s ease-in-out 0.7s infinite;
    }
    .narrative-note.letter {
      background: linear-gradient(160deg, rgba(248, 250, 255, 0.84), rgba(238, 242, 250, 0.74));
      border: 1px solid rgba(120, 140, 190, 0.4);
      transform: rotate(0.6deg);
      animation: noteIn 0.7s cubic-bezier(0.22, 1, 0.36, 1), noteSway 6s ease-in-out 0.7s infinite;
    }
    .narrative-note.bookmark {
      width: min(70%, 240px);
      background: linear-gradient(180deg, rgba(244, 235, 255, 0.85), rgba(226, 222, 250, 0.75));
      border: 0;
      border-radius: 4px 12px 12px 4px;
      transform: rotate(-0.5deg);
      box-shadow: 0 4px 12px rgba(120, 100, 160, 0.16);
      animation: noteIn 0.7s cubic-bezier(0.22, 1, 0.36, 1);
      padding: 22px 16px 26px;
    }
    .narrative-note.flower {
      width: min(78%, 300px);
      background: linear-gradient(160deg, rgba(255, 244, 235, 0.82), rgba(255, 230, 220, 0.7));
      border: 0;
      border-radius: 40% 40% 10px 10px;
      transform: rotate(0.8deg);
      box-shadow: 0 6px 20px rgba(210, 120, 90, 0.18);
      animation: noteIn 0.7s cubic-bezier(0.22, 1, 0.36, 1), noteSway 6s ease-in-out 0.7s infinite;
      padding: 20px 16px 22px;
    }
    .narrative-note::before {
      content: "";
      position: absolute; top: -9px; left: 50%;
      width: 64px; height: 18px;
      margin-left: -32px;
      background: rgba(150, 170, 190, 0.3);
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
      transform: rotate(-2deg);
      clip-path: polygon(0 0, 100% 0, 94% 100%, 6% 100%);
    }
    .narrative-note.bookmark::after {
      content: "";
      position: absolute; left: 6px; bottom: 6px;
      width: 2px; height: 34px;
      background: rgba(150, 130, 190, 0.5);
      border-radius: 2px;
    }
    .note-inner { position: relative; z-index: 1; }
    .note-title {
      font-size: 12px; letter-spacing: 3px;
      color: rgba(120, 100, 60, 0.75);
      text-align: center; margin-bottom: 8px;
      border-bottom: 1px dashed rgba(150, 130, 80, 0.35);
      padding-bottom: 6px;
    }
    .narrative-note.love .note-title { color: rgba(160, 90, 100, 0.8); border-bottom-color: rgba(180, 110, 120, 0.35); }
    .narrative-note.letter .note-title { color: rgba(90, 110, 160, 0.8); border-bottom-color: rgba(120, 140, 190, 0.35); }
    .narrative-note.bookmark .note-title { color: rgba(120, 100, 170, 0.8); border-bottom: 0; }
    .narrative-note.flower .note-title { color: rgba(200, 110, 90, 0.8); border-bottom-color: rgba(220, 130, 110, 0.3); }
    .note-text {
      font-family: "Kaiti SC", "STKaiti", serif;
      font-size: 14px; line-height: 2; color: #5C5348;
      white-space: pre-wrap; text-align: left;
    }
    .narrative-note.bookmark .note-text { text-align: center; }
    @keyframes noteIn { from { opacity: 0; transform: rotate(-4deg) translateY(18px) scale(0.9); } to { opacity: 1; transform: rotate(-1.2deg) translateY(0) scale(1); } }
    @keyframes noteInLove { from { opacity: 0; transform: rotate(4deg) translateY(18px) scale(0.9); } to { opacity: 1; transform: rotate(1.4deg) translateY(0) scale(1); } }
    @keyframes noteSway { 0%,100% { transform: rotate(-1.2deg); } 50% { transform: rotate(-0.4deg); } }
    @keyframes noteSwayLove { 0%,100% { transform: rotate(1.4deg); } 50% { transform: rotate(0.6deg); } }
    .narrative-choices { margin-top: 18px; display: flex; flex-direction: column; gap: 10px; }
    .choice-btn { width: 100%; min-height: 46px; border-radius: var(--radius-md); font-size: 14px; letter-spacing: 2px; justify-content: flex-start; padding: 0 18px; }
    .free-area { position: absolute; top: 0; bottom: 0; left: 0; right: 0; overflow-y: auto; padding: 12px 16px 96px; z-index: 10; }
    .free-wrap { max-width: 540px; margin: 0 auto; display: flex; flex-direction: column; gap: 14px; }
    .free-greet { font-size: 20px; letter-spacing: 3px; text-align: center; color: var(--accent-deep); padding-top: 6px; }
    .free-tip { font-size: 12px; color: var(--text-faint); text-align: center; letter-spacing: 1px; }
    .action-bar {
      position: absolute; left: 0; right: 0; bottom: 0; z-index: 30;
      display: flex; gap: 10px; align-items: center;
      padding: 12px 14px calc(12px + env(safe-area-inset-bottom, 0px));
      background: linear-gradient(180deg, transparent, var(--bg-top) 34%, var(--bg-top));
    }
    .action-bar input {
      flex: 1; height: 44px; padding: 0 16px; border-radius: 22px;
      border: 1px solid var(--card-border);
      background: rgba(255,255,255,0.78);
      -webkit-backdrop-filter: blur(12px); backdrop-filter: blur(12px);
      font-size: 14px; color: var(--text-primary); outline: none;
      box-shadow: 0 2px 10px rgba(100,120,140,0.12);
    }
    .action-bar input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px rgba(127,168,201,0.25); }
    .action-bar input::placeholder { color: var(--text-faint); }
    .action-bar .btn { flex-shrink: 0; min-width: 68px; }
    .user-action {
      margin: 14px 0 4px auto; width: fit-content; max-width: 82%;
      background: linear-gradient(135deg, var(--accent), var(--accent-deep));
      color: #fff; font-size: 14px; line-height: 1.7;
      padding: 9px 15px; border-radius: 16px 4px 16px 16px;
      box-shadow: 0 3px 12px rgba(127,168,201,0.32);
      text-align: left; word-break: break-word;
      animation: bubbleIn 0.3s cubic-bezier(0.22, 1, 0.36, 1);
    }
    .ai-result { margin: 12px 0 22px; width: 100%; }
    .sidebar-toggle {
      position: absolute; left: 0; top: 70px; z-index: 60;
      width: 20px; height: 44px; border-radius: 0 12px 12px 0;
      background: var(--card-strong); backdrop-filter: blur(16px);
      border: 1px solid var(--card-border); box-shadow: var(--shadow);
      font-size: 16px; color: var(--accent-deep);
      display: flex; align-items: center; justify-content: center;
      animation: glowPulse 2.2s ease-in-out infinite;
      transition: left 0.35s ease-in-out;
    }
    .sidebar-toggle.expanded { left: calc(80% - 20px); }
    .st-glow {
      position: absolute; inset: -6px; border-radius: inherit;
      box-shadow: 0 0 14px 2px rgba(127,168,201,0.45);
      animation: glowPulse 2.2s ease-in-out infinite;
      pointer-events: none;
    }
    @keyframes glowPulse { 0%,100% { box-shadow: 0 0 8px 0 rgba(127,168,201,0.35); } 50% { box-shadow: 0 0 16px 3px rgba(127,168,201,0.55); } }
    .float-phone, .float-bag {
      position: absolute; right: 12px; z-index: 40;
      width: 54px; height: 54px; border-radius: 50%;
      background: var(--card-strong); backdrop-filter: blur(16px);
      border: 1px solid var(--card-border); box-shadow: var(--shadow);
      font-size: 22px; display: flex; align-items: center; justify-content: center;
      animation: floatBounce 3s ease-in-out infinite;
    }
    .float-phone { top: 70px; }
    .float-bag { top: 132px; animation-delay: 0.5s; }
    @keyframes floatBounce { 0%,100% { transform: translateY(0); } 50% { transform: translateY(-6px); } }
    .sidebar {
      position: absolute; left: 0; top: 0; bottom: 0; z-index: 50;
      width: 80%;
      background: linear-gradient(160deg, var(--bg-top), var(--bg-bottom));
      backdrop-filter: blur(24px);
      -webkit-backdrop-filter: blur(24px);
      border-right: 1px solid var(--card-border);
      box-shadow: 8px 0 40px rgba(100,120,140,0.2);
      transform: translateX(-102%);
      transition: transform 0.35s ease-in-out;
      display: flex; flex-direction: column; padding: 20px 16px;
      overflow-y: auto;
    }
    .sidebar.open { transform: translateX(0); }
    .sidebar-profile { text-align: center; padding: 10px 0 14px; border-bottom: 1px solid rgba(127,168,201,0.2); margin-bottom: 12px; flex-shrink: 0; }
    .sidebar-avatar {
      width: 60px; height: 60px; margin: 0 auto 10px; border-radius: 50%;
      background: linear-gradient(135deg, var(--accent-soft), var(--accent));
      color: #fff; font-size: 24px; display: flex; align-items: center; justify-content: center;
      box-shadow: 0 4px 16px rgba(127,168,201,0.35);
      cursor: pointer; border: none;
    }
    .sidebar-avatar:active { filter: brightness(0.92); }
    .sidebar-name { font-size: 15px; font-weight: 700; letter-spacing: 2px; color: var(--accent-deep); margin-top: 8px; }
    .sidebar-info {
      background: var(--card); border: 1px solid var(--card-border);
      border-radius: 14px; padding: 8px 12px; margin-bottom: 10px;
      font-size: 11px; line-height: 1; color: var(--text-secondary);
      white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
      flex-shrink: 0;
    }
    .sidebar-status { display: flex; flex-direction: column; gap: 6px; padding: 10px 12px; background: var(--card); border: 1px solid var(--card-border); border-radius: 14px; margin-bottom: 10px; flex-shrink: 0; }
    .sb-stat { display: flex; align-items: center; gap: 6px; }
    .sb-stat-name { width: 28px; font-size: 11px; color: var(--text-secondary); flex-shrink: 0; }
    .sb-stat-bar { flex: 1; height: 7px; border-radius: 4px; background: rgba(100,120,140,0.15); overflow: hidden; }
    .sb-stat-fill { height: 100%; border-radius: 4px; transition: width 0.4s ease; }
    .sb-stat-val { width: 34px; text-align: right; font-size: 10px; color: var(--text-secondary); flex-shrink: 0; }
    .sidebar-tips {
      background: var(--card); border: 1px solid var(--card-border);
      border-radius: 14px; padding: 10px 12px; margin-bottom: 10px;
      min-height: 42px; display: flex; align-items: center;
      flex-shrink: 0;
    }
    .sb-tip { font-size: 12px; color: var(--text-secondary); line-height: 1.6; animation: fadeIn 0.6s ease; }
    .sb-tip-empty { font-size: 12px; color: var(--text-faint); }
    .sidebar-groups { display: flex; flex-direction: column; gap: 10px; padding-bottom: 20px; }
    .sidebar-row { display: flex; gap: 10px; }
    .sidebar-item {
      flex: 1; min-height: 62px;
      border-radius: var(--radius-md);
      background: var(--card);
      border: 1px solid var(--card-border);
      display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 3px;
      color: var(--text-primary);
      transition: var(--transition);
    }
    .sidebar-item:hover { transform: translateY(-2px); box-shadow: var(--shadow); }
    .sidebar-ico { font-size: 18px; }
    .sidebar-txt { font-size: 12px; letter-spacing: 1px; }
    .portrait-overlay {
      position: fixed; inset: 0; z-index: 300;
      background: rgba(20,16,14,0.78); backdrop-filter: blur(6px);
      display: flex; align-items: center; justify-content: center;
      animation: fadeIn 0.3s ease-in-out;
    }
    .portrait-card {
      width: min(78vw, 320px); text-align: center;
      background: var(--card-strong); backdrop-filter: blur(20px);
      border: 1px solid var(--card-border); border-radius: var(--radius-lg);
      box-shadow: var(--shadow); padding: 30px 22px 24px; position: relative;
      animation: modalPop 0.35s cubic-bezier(0.18, 0.89, 0.32, 1.28);
    }
    .portrait-close {
      position: absolute; top: 10px; right: 10px;
      width: 32px; height: 32px; border-radius: 50%;
      background: rgba(0,0,0,0.06); border: none; font-size: 14px; cursor: pointer;
    }
    .portrait-avatar {
      width: 96px; height: 96px; border-radius: 50%;
      background: linear-gradient(135deg, var(--accent-soft), var(--accent));
      color: #fff; font-size: 40px; display: flex; align-items: center; justify-content: center;
      box-shadow: 0 8px 28px rgba(127, 168, 201, 0.4);
    }
    .portrait-row { display: flex; align-items: flex-start; gap: 12px; padding: 9px 0; border-bottom: 1px dashed rgba(127, 168, 201, 0.25); }
    .portrait-row:last-child { border-bottom: 0; }
    .p-row-avatar { justify-content: center; border-bottom: 0; padding-bottom: 14px; }
    .p-label { flex-shrink: 0; width: 62px; font-size: 13px; color: var(--text-secondary); letter-spacing: 2px; padding-top: 1px; }
    .p-val { flex: 1; font-size: 14px; color: var(--accent-deep); line-height: 1.8; word-break: break-word; }
  `;
}
