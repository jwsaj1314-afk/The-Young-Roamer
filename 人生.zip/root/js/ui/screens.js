import { Game, mount, navigate, openModal, closeModal } from '../main.js';
import { saveState } from '../core/storage.js';

export function showDisclaimer() {
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay no-close';
  overlay.style.zIndex = 1000;
  overlay.style.background = 'rgba(20,16,14,0.75)';

  const card = document.createElement('div');
  card.className = 'modal-card';
  card.style.maxHeight = '80vh';

  const header = document.createElement('div');
  header.className = 'modal-header';
  header.style.justifyContent = 'center';
  header.innerHTML = '<h2 class="font-kai" style="font-size:20px;letter-spacing:6px;">免责声明</h2>';

  const body = document.createElement('div');
  body.className = 'modal-body';
  body.style.fontSize = '14px';
  body.style.lineHeight = '1.6';

  const terms = [
    '1. 本游戏《此间少年行》为个人创作的作品，当前版本为 v3.0，旨在提供一段治愈向的文字冒险体验。',
    '2. 游戏内容纯属虚构，所有人物、地点与情节均不映射现实，仅作娱乐用途，不构成任何形式的投资、医疗或生活建议。',
    '3. 游戏采用 AI 动态生成剧情，服务可能存在中断、延迟或生成内容不稳定的情况，作者不对生成内容的准确性作任何保证。',
    '4. 游戏内所有文字、设定、美术资源的著作权归作者所有。未经许可，禁止复制、修改、传播或用于商业用途。',
    '5. 游戏包含少量 18+ 敏感内容标识，部分剧情涉及成人向、心理与现实议题，未成年玩家请在监护人陪同下体验。',
    '6. 本游戏内容不可二次传播、二创发布或用于任何公开用途，请尊重创作者的劳动成果。',
  ];
  terms.forEach((t) => {
    const p = document.createElement('p');
    p.style.marginBottom = '12px';
    p.textContent = t;
    body.appendChild(p);
  });

  const footer = document.createElement('div');
  footer.className = 'modal-footer';
  footer.style.justifyContent = 'space-between';

  const cancelBtn = document.createElement('button');
  cancelBtn.className = 'btn btn-ghost';
  cancelBtn.style.flex = '1';
  cancelBtn.textContent = '取消';
  cancelBtn.addEventListener('click', () => {
    closeModal();
    renderExit();
  });

  const agreeBtn = document.createElement('button');
  agreeBtn.className = 'btn btn-primary';
  agreeBtn.style.flex = '1';
  agreeBtn.textContent = '同意';
  agreeBtn.addEventListener('click', () => {
    Game.state.flags.disclaimer = true;
    saveState(Game.state);
    closeModal();
    playOpening();
  });

  footer.appendChild(cancelBtn);
  footer.appendChild(agreeBtn);
  card.appendChild(header);
  card.appendChild(body);
  card.appendChild(footer);
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  Game.activeModal = { overlay, card, opts: { noClose: true } };
}

function renderExit() {
  mount(document.createElement('div'));
  const screen = document.createElement('div');
  screen.className = 'screen';
  screen.style.background = 'var(--bg-gradient)';
  screen.innerHTML = `
    <div style="text-align:center;padding:30px;">
      <div class="font-kai" style="font-size:22px;letter-spacing:4px;margin-bottom:16px;">此间少年行</div>
      <p style="color:var(--text-secondary);font-size:14px;margin-bottom:28px;">你不愿踏入这段旅程。<br>故事还没有开始，就已经结束。</p>
      <button class="btn btn-primary" id="reopen">重新阅读声明</button>
    </div>`;
  screen.querySelector('#reopen').addEventListener('click', () => {
    Game.state.flags.disclaimer = false;
    saveState(Game.state);
    showDisclaimer();
  });
  mount(screen);
}

export function playOpening() {
  const screen = document.createElement('div');
  screen.className = 'screen opening-screen';

  screen.innerHTML = `
    <div class="opening-stage" id="stage">
      <div class="opening-sky" id="openingSky"></div>
      <div class="city-silhouette" id="cityScape"></div>
      <div class="bird-wrap" id="birdWrap"></div>
      <div class="cloud-wrap" id="cloudWrap"></div>
      <div class="planet-wrap" id="planet">
        <div class="planet-dots" id="planetDots"></div>
        <div class="planet-glow"></div>
      </div>
      <div class="opening-title-wrap" id="titleWrap">
        <div class="opening-title font-kai">此间少年行</div>
        <div class="opening-studio">清姈工作室</div>
      </div>
      <button class="skip-btn" id="skipBtn">跳过</button>
    </div>`;

  mount(screen);

  // 阶段控制
  const stage = screen.querySelector('#stage');
  const planet = screen.querySelector('#planet');
  const dotsEl = screen.querySelector('#planetDots');
  const titleWrap = screen.querySelector('#titleWrap');
  const cityScape = screen.querySelector('#cityScape');
  const birdWrap = screen.querySelector('#birdWrap');
  const cloudWrap = screen.querySelector('#cloudWrap');
  const skip = screen.querySelector('#skipBtn');

  let skipped = false;
  const timers = [];
  const t = (fn, ms) => { const id = setTimeout(() => { if (!skipped) fn(); }, ms); timers.push(id); };

  // 1. 由星星点点的圆圈组成的星球浮现
  buildDotPlanet(dotsEl);
  planet.classList.add('show');

  // 2. 星点向外散去并淡化（2s后）
  t(() => {
    dotsEl.querySelectorAll('.planet-dot').forEach((d, i) => {
      d.style.transition = 'transform 1.2s ease-in, opacity 1.2s ease-in';
      const a = (i * 47) % 360;
      const dist = 260 + (i * 13) % 220;
      d.style.transform = `translate(${Math.cos(a * Math.PI / 180) * dist}px, ${Math.sin(a * Math.PI / 180) * dist}px)`;
      d.style.opacity = '0';
    });
    planet.classList.add('burst');
  }, 2000);

  // 3. 浮现标题「此间少年行」(包含工作室)（3.4s后）
  t(() => {
    planet.style.display = 'none';
    titleWrap.classList.add('show');
  }, 3400);

  // 4. 标题背景后浮现城市剪影、飞鸟、云朵（4.2s后）
  t(() => {
    cityScape.classList.add('show');
    birdWrap.classList.add('show');
    cloudWrap.classList.add('show');
    spawnBirds(birdWrap);
    spawnClouds(cloudWrap);
  }, 4200);

  // 5. 淡入大厅（7.2s后）
  t(() => {
    screen.style.transition = 'opacity 0.7s ease-in-out';
    screen.style.opacity = '0';
    setTimeout(() => { if (!skipped) finish(); }, 800);
  }, 7200);

  skip.addEventListener('click', () => {
    skipped = true;
    timers.forEach(clearTimeout);
    finish();
  });

  function finish() {
    mount(document.createElement('div'));
    navigate('lobby');
  }
}

// 由星星点点的圆圈组成星球（随机散布的小圆点聚集呈球体轮廓）
function buildDotPlanet(el) {
  el.innerHTML = '';
  const dots = 150;
  const cx = 50;
  const cy = 50;
  const R = 40;
  for (let i = 0; i < dots; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = R * Math.sqrt(Math.random());
    const x = cx + Math.cos(a) * r;
    const y = cy + Math.sin(a) * r;
    const d = document.createElement('div');
    d.className = 'planet-dot';
    d.style.left = x + '%';
    d.style.top = y + '%';
    d.style.animationDelay = (Math.random() * 0.9) + 's';
    el.appendChild(d);
  }
}

function spawnBirds(el) {
  el.innerHTML = '';
  for (let i = 0; i < 4; i++) {
    const b = document.createElement('div');
    b.className = 'bird';
    b.style.top = (14 + Math.random() * 26) + '%';
    b.style.animationDelay = (Math.random() * 1.6) + 's';
    b.style.animationDuration = (7 + Math.random() * 6) + 's';
    el.appendChild(b);
  }
}

function spawnClouds(el) {
  el.innerHTML = '';
  for (let i = 0; i < 5; i++) {
    const c = document.createElement('div');
    c.className = 'cloud';
    c.style.top = (6 + Math.random() * 22) + '%';
    c.style.animationDelay = (Math.random() * 4) + 's';
    c.style.animationDuration = (26 + Math.random() * 18) + 's';
    c.style.transform = `scale(${0.7 + Math.random() * 0.7})`;
    el.appendChild(c);
  }
}
