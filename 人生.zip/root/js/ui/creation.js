import { Game, mount, navigate, openModal, closeModal, toast, injectStyle } from '../main.js';
import { saveState } from '../core/storage.js';
import { rand, clamp } from '../core/utils.js';
import { TALENTS } from '../data/misc.js';
import { startGame } from '../core/narrative.js';

const SKIN_COLORS = ['#FCE4D6', '#F5CDB8', '#EDB98F', '#D9A066', '#C68B5A', '#A9744D', '#8A5A3B'];
const HAIR_COLORS = ['#1A1A1A', '#4A3B32', '#6B4F3A', '#8B5A33', '#A67B5B', '#C69C6D', '#E5C8A5', '#B5A6C9'];
const EYE_COLORS = ['#1E1E1E', '#4A3728', '#5B4A3F', '#6B5A8A', '#3D5A80', '#4E7A5C', '#7A5A4E', '#8A6B5A'];

const BANG_STYLES = ['空气刘海', '齐刘海', '斜刘海', '八字刘海', '龙须刘海', '薄刘海', '法式刘海', '三七分刘海', '公主切', '无刘海'];
const BACK_STYLES = ['直发', '微卷', '大波浪', '羊毛卷', '束发', '短发', '及腰', '精灵短发', '经典波波头', '日系狼尾剪', '高马尾', '低马尾', '双马尾', '侧马尾', '丸子头', '半丸子头', '双丸子头', '麻花辫', '鱼骨辫', '拳击辫', '丝带编发', '半扎发', '微分碎盖', '飞机头', '寸头', '狼尾', '中分'];
const LEN_STYLES = ['短', '中', '长'];
const BACK_LEN = ['耳下', '及肩', '及胸', '及腰', '及臀'];
const FIGURES = ['娇小', '高挑', '纤细', '丰满', '健硕', '魁梧', '薄肌', '匀称', '精壮', '矫健', '单薄', '修长', '宽厚', '紧致', '丰腴', '婀娜', '飒爽'];
const AURAS = ['温柔', '妩媚', '清冷', '可爱', '清新', '书卷气', '硬朗', '刚毅', '粗犷', '稳重', '痞帅', '不羁', '慵懒', '矜贵', '精英感', '高智感', '文艺', '颓废', '忧郁', '随性', '元气', '明艳', '大气', '干练', '英气'];
const GENDERS = ['男', '女', '双性偏男', '双性偏女', '无性'];
const ORIENTATIONS = ['异性恋', '同性恋', '双性恋', '无性恋'];
const MARKS = [
  { id: 'eyebrow', label: '眉心痣' },
  { id: 'eye-l-left', label: '左眼角痣（上睑）' },
  { id: 'eye-l-down', label: '左眼角痣（下睑）' },
  { id: 'eye-r-left', label: '右眼角痣（上睑）' },
  { id: 'eye-r-down', label: '右眼角痣（下睑）' },
  { id: 'mouth-l', label: '嘴角痣（左）' },
  { id: 'mouth-r', label: '嘴角痣（右）' },
  { id: 'nose', label: '鼻翼痣' },
  { id: 'collarbone', label: '锁骨痣' },
];

export function renderCreation(isNew = true) {
  injectStyle(creationStyle(), 'creation');
  const s = Game.state;
  const p = s.player;
  const form = {
    name: p.name || '蒋华',
    nick: p.nickname || '小华',
    gender: p.gender || '男',
    orientation: p.orientation || '异性恋',
    skin: p.skin || '中性',
    height: p.height || 165,
    figure: p.figure || '纤细',
    aura: p.aura || '清冷',
    hair: { ...p.hair },
    eyes: p.eyes || '#5B4A3F',
    marks: [...(p.marks || [])],
    freckles: p.freckles || 0,
    attrMode: 'random',
    attrs: { ...p.attributes },
    talents: [...(p.talents || [])],
  };

  const screen = document.createElement('div');
  screen.className = 'screen';
  screen.style.background = 'var(--bg-gradient)';

  const backBtn = document.createElement('button');
  backBtn.className = 'creation-back';
  backBtn.setAttribute('aria-label', '返回游戏大厅');
  backBtn.textContent = '←';
  backBtn.addEventListener('click', () => navigate('lobby'));
  screen.appendChild(backBtn);

  const scroll = document.createElement('div');
  scroll.style.cssText = 'flex:1;width:100%;overflow-y:auto;display:flex;justify-content:center;';
  const inner = document.createElement('div');
  inner.className = 'content-center';
  inner.style.cssText = 'padding:24px 20px 110px;';

  inner.innerHTML = `
    <div style="text-align:center;margin-bottom:22px;">
      <div class="font-kai" style="font-size:26px;letter-spacing:6px;">角色创造</div>
      <div style="width:120px;height:1px;background:linear-gradient(90deg,transparent,var(--accent),transparent);margin:12px auto 0;"></div>
    </div>
    <div id="creation-form"></div>
  `;

  const formEl = inner.querySelector('#creation-form');
  const sections = [];

  function addSection(title, html) {
    sections.push({ title, html });
  }

  function renderForm() {
    formEl.innerHTML = sections.map((sec, i) => `
      <div class="create-section">
        <div class="create-sec-title"><span>${sec.title}</span><span class="create-sec-index">${String(i + 1).padStart(2, '0')}</span></div>
        <div class="create-sec-body">${sec.html}</div>
      </div>`).join('')
      + `
      <div style="height:20px;"></div>
      <button class="btn btn-primary btn-lg" id="enterGame" style="letter-spacing:8px;font-size:17px;">进入游戏</button>`;
    bindSectionEvents();
    formEl.querySelector('#enterGame').addEventListener('click', finish);
  }

  // ===== 基础信息 =====
  function customAddHtml(target) {
    return `
      <div class="form-row custom-add">
        <input type="text" class="custom-add-input" placeholder="进行自定义添加…" maxlength="8" data-target="${target}">
        <button class="btn btn-sm custom-add-btn" data-target="${target}">添加</button>
      </div>`;
  }

  const OPT_LISTS = {
    bangs: { get: () => BANG_STYLES, set: (v) => { form.hair.bangs = v; }, cur: () => form.hair.bangs, multi: false },
    back: { get: () => BACK_STYLES, set: (v) => { form.hair.back = v; }, cur: () => form.hair.back, multi: false },
    banglen: { get: () => LEN_STYLES, set: (v) => { form.hair.bangsLen = v; }, cur: () => form.hair.bangsLen, multi: false },
    backlen: { get: () => BACK_LEN, set: (v) => { form.hair.backLen = v; }, cur: () => form.hair.backLen, multi: false },
    figure: { get: () => FIGURES, set: (v) => { form.figure = v; }, cur: () => form.figure, multi: false },
    aura: { get: () => AURAS, set: (v) => { form.aura = v; }, cur: () => form.aura, multi: false },
  };

  function renderOptBlock(key) {
    const cfg = OPT_LISTS[key];
    const el = formEl.querySelector(`#opt-${key}`);
    if (!el || !cfg) return;
    const cur = cfg.cur();
    el.innerHTML = cfg.get().map((v) => {
      const sel = cfg.multi ? cur.includes(v) : cur === v;
      return `<div class="opt ${sel ? 'selected' : ''}" data-v="${v}">${v}</div>`;
    }).join('');
    el.querySelectorAll('.opt').forEach((o) => {
      o.addEventListener('click', () => {
        if (cfg.multi) {
          const id = o.dataset.v;
          const arr = cfg.cur();
          if (arr.includes(id)) { form[key === 'marks' ? 'marks' : key] = arr.filter((x) => x !== id); o.classList.remove('selected'); }
          else { arr.push(id); o.classList.add('selected'); }
          return;
        }
        el.querySelectorAll('.opt').forEach((x) => x.classList.remove('selected'));
        o.classList.add('selected');
        cfg.set(o.dataset.v);
      });
    });
  }

  function bindCustomAdds() {
    formEl.querySelectorAll('.custom-add-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const key = btn.dataset.target;
        const input = formEl.querySelector(`.custom-add-input[data-target="${key}"]`);
        const value = input.value.trim();
        if (!value) return;
        const cfg = OPT_LISTS[key];
        if (!cfg) return;
        if (!cfg.get().includes(value)) cfg.get().push(value);
        cfg.set(value);
        input.value = '';
        renderOptBlock(key);
        toast(`已添加「${value}」`);
      });
    });
  }

  function secBasic() {
    return `
      <div class="form-row"><label>姓名</label><input id="in-name" value="${form.name}" maxlength="6"></div>
      <div class="form-row"><label>昵称</label><input id="in-nick" value="${form.nick}" maxlength="8"></div>
      <div class="form-row"><label>性别</label><div class="opt-list" id="opt-gender">${GENDERS.map((g) => `<div class="opt ${form.gender === g ? 'selected' : ''}" data-v="${g}">${g}</div>`).join('')}</div></div>
      <div class="form-row"><label>年龄</label><div style="display:flex;align-items:center;gap:10px;"><div class="age-lock" style="font-size:16px;font-weight:600;color:var(--text-secondary);">14 岁</div><span style="font-size:12px;color:var(--text-faint);">（固定）</span></div></div>
      <div class="form-row"><label>性取向</label><div class="opt-list" id="opt-orient">${ORIENTATIONS.map((o) => `<div class="opt ${form.orientation === o ? 'selected' : ''}" data-v="${o}">${o}</div>`).join('')}</div></div>
      <div class="form-row" style="flex-direction:column;align-items:stretch;"><span style="font-size:12px;color:var(--text-faint);">游戏中所有角色的性别将根据你的性取向动态生成，每次开局都有不同的可能性。</span></div>
      <div class="form-row"><label>皮肤</label><div class="swatch-list" id="skin-swatches">
        ${SKIN_COLORS.map((c, i) => `<div class="swatch ${form.skin === SKIN_NAMES[i] ? 'selected' : ''}" data-c="${c}" data-n="${SKIN_NAMES[i]}" style="background:${c}"></div>`).join('')}
        <span style="font-size:12px;color:var(--text-secondary);align-self:center;">${form.skin}</span>
      </div></div>
      <div class="form-row"><label>身高</label>
        <div style="display:flex;align-items:center;gap:12px;width:100%;">
          <input type="range" id="in-height" min="140" max="190" step="1" value="${form.height}" style="flex:1;">
          <span id="height-val" style="font-size:14px;font-weight:600;min-width:52px;text-align:right;">${form.height}cm</span>
        </div>
      </div>
      <div class="form-row"><label>身材</label><div class="opt-list" id="opt-figure">${FIGURES.map((f) => `<div class="opt ${form.figure === f ? 'selected' : ''}" data-v="${f}">${f}</div>`).join('')}</div></div>
      ${customAddHtml('figure')}
      <div class="form-row"><label>形态</label><div class="opt-list" id="opt-aura">${AURAS.map((a) => `<div class="opt ${form.aura === a ? 'selected' : ''}" data-v="${a}">${a}</div>`).join('')}</div></div>
      ${customAddHtml('aura')}
    `;
  }

  // ===== 外貌 =====
  function secAppearance() {
    return `
      <div class="form-row"><label>刘海形态</label><div class="opt-list" id="opt-bangs">${BANG_STYLES.map((b) => `<div class="opt ${form.hair.bangs === b ? 'selected' : ''}" data-v="${b}">${b}</div>`).join('')}</div></div>
      ${customAddHtml('bangs')}
      <div class="form-row"><label>后发形态</label><div class="opt-list" id="opt-back">${BACK_STYLES.map((b) => `<div class="opt ${form.hair.back === b ? 'selected' : ''}" data-v="${b}">${b}</div>`).join('')}</div></div>
      ${customAddHtml('back')}
      <div class="form-row"><label>刘海长度</label><div class="opt-list" id="opt-banglen">${LEN_STYLES.map((l) => `<div class="opt ${form.hair.bangsLen === l ? 'selected' : ''}" data-v="${l}">${l}</div>`).join('')}</div></div>
      ${customAddHtml('banglen')}
      <div class="form-row"><label>后发长度</label><div class="opt-list" id="opt-backlen">${BACK_LEN.map((l) => `<div class="opt ${form.hair.backLen === l ? 'selected' : ''}" data-v="${l}">${l}</div>`).join('')}</div></div>
      ${customAddHtml('backlen')}
      <div class="form-row"><label>头发颜色</label>
        <div class="swatch-list" id="hair-swatches" style="margin-bottom:8px;">
          ${HAIR_COLORS.map((c) => `<div class="swatch ${form.hair.color === c ? 'selected' : ''}" data-c="${c}" style="background:${c}"></div>`).join('')}
        </div>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px;">
          <input type="color" id="hair-picker" value="${form.hair.color}" style="width:44px;height:34px;border:none;background:none;padding:0;cursor:pointer;">
          <span style="font-size:12px;color:var(--text-secondary);">调色盘取色</span>
          <input type="text" id="hair-hex" value="${form.hair.color}" style="width:80px;font-size:12px;">
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
          <input type="checkbox" id="hair-grad-toggle">
          <label for="hair-grad-toggle" style="font-size:13px;color:var(--text-secondary);">渐变双色</label>
          <input type="color" id="hair-grad-picker" value="${form.hair.gradient || '#E5C8A5'}" style="width:40px;height:30px;border:none;background:none;padding:0;cursor:pointer;">
        </div>
      </div>
      <div class="form-row"><label>眼睛颜色</label>
        <div class="swatch-list" id="eye-swatches" style="margin-bottom:8px;">
          ${EYE_COLORS.map((c) => `<div class="swatch ${form.eyes === c ? 'selected' : ''}" data-c="${c}" style="background:${c}"></div>`).join('')}
        </div>
        <div style="display:flex;align-items:center;gap:10px;">
          <input type="color" id="eye-picker" value="${form.eyes}" style="width:44px;height:34px;border:none;background:none;padding:0;cursor:pointer;">
          <span style="font-size:12px;color:var(--text-secondary);">调色盘取色</span>
        </div>
      </div>
      <div class="form-row"><label>特征（多选）</label>
        <div class="opt-list" id="opt-marks" style="margin-bottom:8px;">
          ${MARKS.map((m) => `<div class="opt ${form.marks.includes(m.id) ? 'selected' : ''}" data-v="${m.id}">${m.label}</div>`).join('')}
        </div>
        <div style="display:flex;align-items:center;gap:12px;">
          <span style="font-size:13px;color:var(--text-secondary);white-space:nowrap;">雀斑密度</span>
          <input type="range" id="in-freckles" min="0" max="2" step="1" value="${form.freckles}" style="flex:1;">
          <span id="freckles-val" style="font-size:12px;min-width:40px;text-align:right;">${['无', '轻度', '中度', '重度'][form.freckles]}</span>
        </div>
      </div>
    `;
  }

  // ===== 属性 =====
  function secAttrs() {
    const attrNames = { con: '体质', int: '智力', per: '感知', cha: '魅力', luk: '运气' };
    return `
      <div class="form-row" style="flex-direction:column;align-items:stretch;gap:10px;">
        <label>五维属性（1-10）</label>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm ${form.attrMode === 'random' ? 'btn-primary' : ''}" id="attr-random">随机（总分25-35）</button>
          <button class="btn btn-sm ${form.attrMode === 'custom' ? 'btn-primary' : ''}" id="attr-custom">自定义（总分≤40）</button>
        </div>
        <div style="display:flex;justify-content:space-between;font-size:12px;color:var(--text-secondary);">
          <span>总分：<b id="attr-total">${Object.values(form.attrs).reduce((a, b) => a + b, 0)}</b></span>
          <span id="attr-tip" style="color:var(--accent-deep);"></span>
        </div>
        ${Object.keys(attrNames).map((k) => `
          <div style="display:flex;align-items:center;gap:10px;">
            <span style="font-size:13px;width:36px;">${attrNames[k]}</span>
            <input type="range" min="1" max="10" step="1" value="${form.attrs[k]}" class="attr-slider" data-k="${k}" style="flex:1;" ${form.attrMode === 'random' ? 'disabled' : ''}>
            <span class="attr-val" data-k="${k}" style="font-size:13px;min-width:20px;text-align:right;">${form.attrs[k]}</span>
          </div>`).join('')}
      </div>
    `;
  }

  // ===== 天赋 =====
  function secTalents() {
    const has = (id) => form.talents.includes(id);
    return `
      <div class="form-row" style="flex-direction:column;align-items:stretch;gap:10px;">
        <label>天赋（永久被动，随机2-4项 / 自定义≤5项）</label>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm btn-primary" id="tal-random">随机抽取</button>
          <button class="btn btn-sm" id="tal-custom">自定义选择</button>
        </div>
        <div id="tal-selected" style="display:flex;flex-direction:column;gap:6px;">
          ${form.talents.length ? form.talents.map((id) => {
            const t = TALENTS.find((x) => x.id === id);
            return `<div class="talent-chip">${t ? t.name : id}<span style="color:var(--text-faint);font-size:11px;margin-left:8px;font-weight:400;">${t ? t.desc : ''}</span></div>`;
          }).join('') : '<div style="font-size:13px;color:var(--text-faint);padding:8px;">尚未选择天赋</div>'}
        </div>
      </div>
    `;
  }

  addSection('基础信息', secBasic());
  addSection('外貌', secAppearance());
  addSection('属性状态', secAttrs());
  addSection('天赋', secTalents());
  renderForm();

  function bindSectionEvents() {
    // 基础
    const inName = formEl.querySelector('#in-name');
    const inNick = formEl.querySelector('#in-nick');
    inName.addEventListener('input', () => { form.name = inName.value.trim() || '蒋华'; });
    inNick.addEventListener('input', () => { form.nick = inNick.value.trim() || '小华'; });

    bindOpt(formEl, '#opt-gender', (v) => { form.gender = v; });
    bindOpt(formEl, '#opt-orient', (v) => { form.orientation = v; });

    formEl.querySelectorAll('#skin-swatches .swatch').forEach((el) => {
      el.addEventListener('click', () => {
        formEl.querySelectorAll('#skin-swatches .swatch').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        form.skin = el.dataset.n;
        const label = formEl.querySelector('#skin-swatches span');
        if (label) label.textContent = form.skin;
      });
    });

    const heightEl = formEl.querySelector('#in-height');
    heightEl.addEventListener('input', () => {
      form.height = parseInt(heightEl.value, 10);
      formEl.querySelector('#height-val').textContent = form.height + 'cm';
    });

    renderOptBlock('figure');
    renderOptBlock('aura');

    // 外貌
    renderOptBlock('bangs');
    renderOptBlock('back');
    renderOptBlock('banglen');
    renderOptBlock('backlen');
    bindCustomAdds();

    formEl.querySelectorAll('#hair-swatches .swatch').forEach((el) => {
      el.addEventListener('click', () => {
        formEl.querySelectorAll('#hair-swatches .swatch').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        form.hair.color = el.dataset.c;
        formEl.querySelector('#hair-picker').value = form.hair.color;
        formEl.querySelector('#hair-hex').value = form.hair.color;
      });
    });
    const hairPicker = formEl.querySelector('#hair-picker');
    hairPicker.addEventListener('input', () => { form.hair.color = hairPicker.value; formEl.querySelector('#hair-hex').value = hairPicker.value; });
    const hairHex = formEl.querySelector('#hair-hex');
    hairHex.addEventListener('input', () => { if (/^#[0-9a-fA-F]{6}$/.test(hairHex.value)) { form.hair.color = hairHex.value; hairPicker.value = hairHex.value; } });
    const gradToggle = formEl.querySelector('#hair-grad-toggle');
    const gradPicker = formEl.querySelector('#hair-grad-picker');
    gradToggle.addEventListener('change', () => { if (!gradToggle.checked) form.hair.gradient = null; else form.hair.gradient = gradPicker.value; });
    gradPicker.addEventListener('input', () => { if (gradToggle.checked) form.hair.gradient = gradPicker.value; });

    formEl.querySelectorAll('#eye-swatches .swatch').forEach((el) => {
      el.addEventListener('click', () => {
        formEl.querySelectorAll('#eye-swatches .swatch').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        form.eyes = el.dataset.c;
        formEl.querySelector('#eye-picker').value = form.eyes;
      });
    });
    const eyePicker = formEl.querySelector('#eye-picker');
    eyePicker.addEventListener('input', () => { form.eyes = eyePicker.value; });

    formEl.querySelectorAll('#opt-marks .opt').forEach((el) => {
      el.addEventListener('click', () => {
        const v = el.dataset.v;
        if (form.marks.includes(v)) { form.marks = form.marks.filter((x) => x !== v); el.classList.remove('selected'); }
        else { form.marks.push(v); el.classList.add('selected'); }
      });
    });
    const freck = formEl.querySelector('#in-freckles');
    freck.addEventListener('input', () => {
      form.freckles = parseInt(freck.value, 10);
      formEl.querySelector('#freckles-val').textContent = ['无', '轻度', '中度', '重度'][form.freckles];
    });

    // 属性
    const randBtn = formEl.querySelector('#attr-random');
    const custBtn = formEl.querySelector('#attr-custom');
    const sliders = formEl.querySelectorAll('.attr-slider');
    randBtn.addEventListener('click', () => {
      form.attrMode = 'random';
      randBtn.classList.add('btn-primary'); custBtn.classList.remove('btn-primary');
      let total = rand(25, 35);
      let vals = [1, 1, 1, 1, 1];
      let rem = total - 5;
      for (let i = 0; i < rem; i++) vals[rand(0, 4)]++;
      form.attrs = { con: vals[0], int: vals[1], per: vals[2], cha: vals[3], luk: vals[4] };
      syncAttrs();
    });
    custBtn.addEventListener('click', () => {
      form.attrMode = 'custom';
      custBtn.classList.add('btn-primary'); randBtn.classList.remove('btn-primary');
      sliders.forEach((s) => { s.disabled = false; });
    });
    sliders.forEach((s) => {
      s.addEventListener('input', () => {
        form.attrs[s.dataset.k] = parseInt(s.value, 10);
        const total = Object.values(form.attrs).reduce((a, b) => a + b, 0);
        formEl.querySelector('#attr-total').textContent = total;
        formEl.querySelector('#attr-tip').textContent = total > 40 ? '超过40，请调低' : '';
        if (total > 40) s.value = 10 - (total - 40); // 简单纠偏
        form.attrs[s.dataset.k] = parseInt(s.value, 10);
        syncAttrs();
      });
    });

    // 天赋
    const talRandom = formEl.querySelector('#tal-random');
    talRandom.addEventListener('click', () => {
      const shuffled = [...TALENTS].sort(() => Math.random() - 0.5);
      const count = rand(2, 4);
      form.talents = shuffled.slice(0, count).map((t) => t.id);
      renderTalents();
    });
    const talCustom = formEl.querySelector('#tal-custom');
    talCustom.addEventListener('click', () => {
      openTalentPicker(form);
    });
  }

  function syncAttrs() {
    const total = Object.values(form.attrs).reduce((a, b) => a + b, 0);
    const totalEl = formEl.querySelector('#attr-total');
    const tipEl = formEl.querySelector('#attr-tip');
    if (totalEl) totalEl.textContent = total;
    if (tipEl) tipEl.textContent = form.attrMode === 'random' ? `已随机（${total}分）` : total > 40 ? '总分超过40，请调低' : '';
    formEl.querySelectorAll('.attr-slider').forEach((s) => {
      s.value = form.attrs[s.dataset.k];
      const v = formEl.querySelector(`.attr-val[data-k="${s.dataset.k}"]`);
      if (v) v.textContent = form.attrs[s.dataset.k];
    });
  }

  function renderTalents() {
    const wrap = formEl.querySelector('#tal-selected');
    if (!wrap) return;
    if (!form.talents.length) { wrap.innerHTML = '<div style="font-size:13px;color:var(--text-faint);padding:8px;">尚未选择天赋</div>'; return; }
    wrap.innerHTML = form.talents.map((id) => {
      const t = TALENTS.find((x) => x.id === id);
      return `<div class="talent-chip">${t ? t.name : id}<span style="color:var(--text-faint);font-size:11px;margin-left:8px;font-weight:400;">${t ? t.desc : ''}</span></div>`;
    }).join('');
  }

  scroll.appendChild(inner);
  screen.appendChild(scroll);
  mount(screen);

  // 底部固定按钮栏
  const bottomBar = document.createElement('div');
  bottomBar.style.cssText = 'position:fixed;bottom:0;left:0;right:0;display:flex;justify-content:center;padding:12px 20px 22px;background:linear-gradient(180deg,transparent,rgba(240,235,226,0.9) 40%);z-index:50;';
  const btn = document.createElement('button');
  btn.className = 'btn btn-primary btn-lg';
  btn.style.cssText = 'max-width:540px;letter-spacing:8px;font-size:17px;';
  btn.textContent = '进入游戏';
  btn.addEventListener('click', finish);
  bottomBar.appendChild(btn);
  screen.appendChild(bottomBar);

  function finish() {
    p.name = form.name;
    p.nickname = form.nick;
    p.gender = form.gender;
    p.orientation = form.orientation;
    p.skin = form.skin;
    p.height = form.height;
    p.figure = form.figure;
    p.aura = form.aura;
    p.hair = { ...form.hair };
    p.eyes = form.eyes;
    p.marks = [...form.marks];
    p.freckles = form.freckles;
    p.attributes = { ...form.attrs };
    p.talents = [...form.talents];
    if (!p.talents.length) p.talents = ['lucky'];

    // 根据玩家性别与性取向，动态分配所有内置角色的性别
    import('../core/gender.js').then(({ assignCharacterGenders }) => {
      assignCharacterGenders(s);
    });

    startGame(s);
    saveState(s);
    navigate('game');
  }
}

function bindOpt(root, sel, cb) {
  const wrap = root.querySelector(sel);
  if (!wrap) return;
  wrap.querySelectorAll('.opt').forEach((el) => {
    el.addEventListener('click', () => {
      wrap.querySelectorAll('.opt').forEach((x) => x.classList.remove('selected'));
      el.classList.add('selected');
      cb(el.dataset.v);
    });
  });
}

function openTalentPicker(form) {
  const body = document.createElement('div');
  body.className = 'modal-body';
  const list = TALENTS.map((t) => `
    <div class="talent-pick ${form.talents.includes(t.id) ? 'selected' : ''}" data-id="${t.id}">
      <div style="font-weight:600;font-size:14px;color:var(--accent-deep);">${t.name}</div>
      <div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${t.desc}</div>
    </div>`).join('');
  body.innerHTML = `
    <div style="font-size:13px;color:var(--text-secondary);margin-bottom:10px;">选择天赋（上限5项）：<b id="tal-count">${form.talents.length}</b>/5</div>
    <div style="display:flex;flex-direction:column;gap:8px;" id="tal-list">${list}</div>`;
  const { card } = openModal(body, {});
  card.style.maxWidth = '420px';
  body.querySelectorAll('.talent-pick').forEach((el) => {
    el.addEventListener('click', () => {
      const id = el.dataset.id;
      if (form.talents.includes(id)) {
        form.talents = form.talents.filter((x) => x !== id);
        el.classList.remove('selected');
      } else if (form.talents.length < 5) {
        form.talents.push(id);
        el.classList.add('selected');
      } else {
        import('../main.js').then(({ toast }) => toast('最多选择5项天赋'));
      }
      body.querySelector('#tal-count').textContent = form.talents.length;
    });
  });
  import('../main.js').then(({ closeModal }) => {
    const doneBtn = document.createElement('button');
    doneBtn.className = 'btn btn-primary btn-sm';
    doneBtn.textContent = '完成';
    doneBtn.addEventListener('click', closeModal);
    card.querySelector('.modal-body').appendChild(doneBtn);
  });
}

export const SKIN_NAMES = ['极白', '白皙', '中性', '暖黄', '橄榄', '小麦', '棕色'];

function creationStyle() {
  return `
    .create-section { margin-bottom: 18px; }
    .creation-back {
      position: fixed; left: 12px; top: 14px; z-index: 60;
      width: 44px; height: 44px; border-radius: 50%;
      background: var(--card-strong); backdrop-filter: blur(16px);
      border: 1px solid var(--card-border); box-shadow: var(--shadow);
      font-size: 20px; color: var(--accent-deep);
      display: flex; align-items: center; justify-content: center;
      transition: var(--transition);
    }
    .creation-back:active { transform: scale(0.92); }
    .create-sec-title { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid rgba(127,168,201,0.2); }
    .create-sec-title span:first-child { font-size: 15px; font-weight: 600; letter-spacing: 3px; color: var(--accent-deep); }
    .create-sec-index { font-size: 12px; color: var(--text-faint); letter-spacing: 1px; }
    .create-sec-body { display: flex; flex-direction: column; gap: 14px; }
    .form-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
    .form-row > label { font-size: 13px; color: var(--text-secondary); min-width: 56px; flex-shrink: 0; }
    .form-row > input[type="text"] { flex: 1; min-width: 120px; }
    .talent-chip { background: rgba(127,168,201,0.1); border: 1px solid rgba(127,168,201,0.25); border-radius: 10px; padding: 8px 12px; font-size: 13px; font-weight: 600; color: var(--accent-deep); }
    .talent-pick { border: 1px solid rgba(150,170,190,0.4); border-radius: 12px; padding: 10px 14px; cursor: pointer; transition: var(--transition); }
    .talent-pick.selected { background: rgba(127,168,201,0.12); border-color: var(--accent); }
    .age-lock { display: inline-flex; }
    .custom-add { display: flex; gap: 8px; margin-top: -2px; }
    .custom-add-input { flex: 1; min-width: 120px; font-size: 13px; padding: 8px 12px; }
  `;
}
