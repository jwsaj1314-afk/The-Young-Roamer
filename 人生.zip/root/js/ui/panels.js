import { Game, mount, navigate, openModal, closeModal, toast, injectStyle, BG_PALETTE } from '../main.js';
import { saveState, saveToSlot, loadFromSlot, deleteSlot, exportSaveJSON, importSaveJSON, downloadSave, hasAutoSave, loadAutoSave } from '../core/storage.js';
import { getPlayer, changeRelation, addMoney, addItem, removeItem, getRelation, getCreatedChars, addCreatedChar } from '../core/state.js';
import { clamp } from '../core/utils.js';
import { charGender, gendText, pronoun } from '../core/gender.js';
import { CHARACTERS } from '../data/characters.js';
import { ACHIEVEMENTS, ACHIEVEMENT_CATEGORIES } from '../data/achievements.js';
import { ITEMS, SHOPS } from '../data/items.js';
import { PLACES, STREETS, WORLD, SCHOOLS, WORLD_ENCYCLOPEDIA } from '../data/world.js';
import { TALENTS, SKILLS, SCHEDULES } from '../data/misc.js';
import { JOBS } from '../data/jobs.js';
import { advanceTime } from '../core/time.js';
import { setAPIConfig, getAPIConfig, testConnection, fetchModels, isAIReady } from '../core/ai.js';

let panelsInjected = false;
function ensureStyle() {
  if (panelsInjected) return;
  panelsInjected = true;
  injectStyle(panelStyle(), 'panels');
}

function panelShell(title, bodyHtml, opts = {}) {
  ensureStyle();
  const content = document.createElement('div');
  content.className = 'modal-body panel-body';
  content.style.cssText = 'padding:0;';
  content.innerHTML = `
    <div class="panel-head">
      <div class="panel-title font-kai">${title}</div>
      ${opts.actions || ''}
      <button class="panel-x" id="panelCloseX" aria-label="关闭">×</button>
    </div>
    <div class="panel-content">${bodyHtml}</div>`;
  const { overlay, card } = openModal(content, {});
  card.style.width = opts.width || 'min(94vw, 540px)';
  card.style.maxWidth = opts.maxWidth || '540px';
  card.style.maxHeight = '88vh';
  content.querySelector('#panelCloseX').addEventListener('click', () => closeModal());
  return { overlay, card, content };
}

function tabBar(tabs, active, onTab) {
  const bar = document.createElement('div');
  bar.className = 'panel-tabs';
  tabs.forEach((t) => {
    const el = document.createElement('div');
    el.className = 'panel-tab' + (t.id === active ? ' active' : '');
    el.textContent = t.label;
    el.addEventListener('click', () => onTab(t.id));
    bar.appendChild(el);
  });
  return bar;
}

// ============ 属性面板 ============
export function openAttrPanel(s) {
  const p = getPlayer(s);
  const tabs = [
    { id: 'base', label: '基础属性' },
    { id: 'core', label: '核心属性' },
    { id: 'skills', label: '技能' },
  ];
  const { card, content } = panelShell('属性', '<div class="panel-inner" id="attrBody"></div>', { width: 'min(92vw, 480px)' });
  card.querySelector('.modal-header')?.remove();
  const body = content.querySelector('#attrBody');
  const bar = tabBar(tabs, 'base', (id) => render(id));
  body.appendChild(bar);
  const area = document.createElement('div');
  body.appendChild(area);

  function render(id) {
    if (id === 'base') renderBase();
    else if (id === 'core') renderCore();
    else renderSkillPage();
  }

  function hairDesc() {
    const h = p.hair || {};
    const bangs = h.bangs && h.bangs !== '无刘海' ? `，${h.bangs}${h.bangsLen || ''}` : '';
    const back = h.back ? `${h.back}${h.backLen || ''}` : '';
    return `${back}${bangs}的发型`.replace(/^，/, '');
  }
  function appearanceText() {
    const parts = [];
    parts.push(`${p.height || 165}cm、身形${p.figure}${p.aura ? `、气质${p.aura}` : ''}`);
    parts.push(hairDesc());
    parts.push('眼眸清澈');
    if (p.marks && p.marks.length) {
      const names = MARKS_FILTERED(p.marks);
      if (names.length) parts.push(`${names.join('、')}`);
    }
    if (p.freckles > 0) parts.push(p.freckles >= 2 ? '面上点缀着明显雀斑' : '鼻翼有淡淡雀斑');
    return parts.join('，') + '。';
  }

  function renderBase() {
    const moodVal = Math.round(p.mood);
    const moodColor = p.mood >= 70 ? 'var(--good)' : p.mood >= 40 ? 'var(--warn)' : 'var(--danger)';
    const healthColor = p.health === '健康' ? 'var(--good)' : p.health === '一般' ? 'var(--warn)' : 'var(--danger)';
    const moralityColor = p.morality >= 70 ? 'var(--good)' : p.morality >= 40 ? 'var(--warn)' : 'var(--danger)';
    const dot = (c) => `<span class="base-dot" style="background:${c};"></span>`;
    area.innerHTML = `
      <div class="attr-hero">
        <div class="attr-hero-name">${p.name}</div>
        <div class="attr-hero-sub">${p.age}岁 · ${p.gender} · ${p.figure} · ${p.aura}</div>
      </div>
      <div class="base-card">
        <div class="base-card-ico">👤</div>
        <div class="base-card-txt">${appearanceText()}</div>
      </div>
      <div class="base-list">
        <div class="base-line">${dot(moodColor)}<span class="base-line-name">心情</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${moodVal}%;background:${moodColor};"></div></div><b class="base-line-val">${moodVal}</b></div>
        <div class="base-line">${dot(healthColor)}<span class="base-line-name">健康</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${p.health === '健康' ? 100 : p.health === '一般' ? 55 : 20}%;background:${healthColor};"></div></div><b class="base-line-val">${p.health}</b></div>
        <div class="base-line">${dot(moralityColor)}<span class="base-line-name">道德观</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${Math.round(p.morality)}%;background:${moralityColor};"></div></div><b class="base-line-val">${Math.round(p.morality)}</b></div>
      </div>
      <div class="panel-sec">天赋</div>
      ${(p.talents || []).length ? (p.talents || []).map((tid) => {
        const t = TALENTS.find((x) => x.id === tid);
        return t ? `<div class="talent-item"><div class="talent-item-name">${t.name}</div><div class="talent-item-desc">${t.desc}</div></div>` : '';
      }).join('') : '<div class="empty-hint">暂无天赋</div>'}
      <div class="panel-tip">外貌、心情、健康、道德观与天赋共同构成了你的基础形象。</div>`;
  }

  function renderCore() {
    const coreNames = [
      { k: 'con', name: '体质', icon: 'con', txt: '身体强度与耐力，影响HP上限、体力恢复与抗疲劳能力。', pros: ['体能充沛', '不易疲惫', '身体强健'], cons: ['过度训练易受伤', '冲动行事风险'] },
      { k: 'int', name: '智力', icon: 'int', txt: '学习与思维能力，影响EP上限、学习效率与解题判断。', pros: ['学习事半功倍', '逻辑清晰', '擅长规划'], cons: ['想得太多反而犹豫', '沉浸思考忽略社交'] },
      { k: 'per', name: '感知', icon: 'per', txt: '观察与直觉能力，影响发现线索、识破谎言与危险预警。', pros: ['洞察细微', '避开危险', '读懂人心'], cons: ['过度敏感', '容易想多'] },
      { k: 'cha', name: '魅力', icon: 'cha', txt: '吸引与感染他人的能力，影响社交、好感与恋爱情缘。', pros: ['广受欢迎', '容易获得信任', '桃花旺盛'], cons: ['招惹是非', '被过度期待'] },
      { k: 'luk', name: '运气', icon: 'luk', txt: '命运眷顾程度，影响随机事件、概率判定与意外收获。', pros: ['逢凶化吉', '常有意外惊喜', '抽卡欧皇'], cons: ['依赖运气', '低估风险'] },
    ];
    const socialVals = [
      { k: 'school', name: '学校声望', icon: 'school', v: p.rep.school || 0, txt: '你在校园里的名气与人缘，来自学业表现与校园活动。' },
      { k: 'community', name: '社区声望', icon: 'community', v: p.rep.community || 0, txt: '你在云栖市街坊邻里间的口碑，来自打工、助人与社区往来。' },
      { k: 'crime', name: '犯罪值', icon: 'crime', v: p.crime || 0, txt: '你与灰色地带的纠葛程度，越高越容易被危险与麻烦缠上。' },
      { k: 'faith', name: '信仰值', icon: 'faith', v: p.faith || 0, txt: '你对晨光教义的信仰程度，来自礼拜、晨省与教义相关的选择。' },
    ];
    area.innerHTML = `<div class="panel-tip" style="margin-bottom:10px;">点击等级条查看该核心属性的详细说明。</div>`;
    coreNames.forEach((c) => {
      const v = p.attributes[c.k];
      const item = document.createElement('div');
      item.className = 'core-item';
      item.innerHTML = `
        <div class="core-head">
          <span class="core-icon">${solidIcon(c.icon, 'var(--accent-deep)')}</span>
          <span class="core-name">${c.name}</span>
          <span class="core-lv">${v}<i>/10</i></span>
        </div>
        <div class="core-bar" data-k="${c.k}">
          ${Array.from({ length: 10 }, (_, i) => `<span class="core-seg ${i < v ? 'on' : ''}"></span>`).join('')}
        </div>
        <div class="core-detail" id="core-detail-${c.k}" hidden>
          <div class="core-detail-txt">${c.txt}</div>
          <div class="core-detail-row"><b>等级越高：</b>${c.pros.map((x) => `<span class="chip chip-ok">${x}</span>`).join('')}</div>
          <div class="core-detail-row"><b>潜在不足：</b>${c.cons.map((x) => `<span class="chip chip-warn">${x}</span>`).join('')}</div>
        </div>`;
      const bar = item.querySelector('.core-bar');
      bar.addEventListener('click', () => {
        const det = item.querySelector('.core-detail');
        const open = !det.hidden;
        det.hidden = open;
      });
      area.appendChild(item);
    });
    area.innerHTML += `<div class="panel-sec">社会属性</div>`;
    socialVals.forEach((c) => {
      const max = c.k === 'crime' ? 100 : 100;
      const pct = Math.max(0, Math.min(100, (c.v / max) * 100));
      const color = c.k === 'crime' ? (c.v > 60 ? 'var(--danger)' : c.v > 25 ? 'var(--warn)' : 'var(--good)') : 'linear-gradient(90deg,var(--accent-soft),var(--accent))';
      const row = document.createElement('div');
      row.className = 'core-item social-core';
      row.innerHTML = `
        <div class="core-head">
          <span class="core-icon">${solidIcon(c.icon, 'var(--accent-deep)')}</span>
          <span class="core-name">${c.name}</span>
          <span class="core-lv">${c.v}<i>/100</i></span>
        </div>
        <div class="bar" style="margin-top:6px;"><div class="bar-fill" style="width:${pct}%;background:${color};"></div></div>
        <div class="core-detail-txt" style="font-size:12px;color:var(--text-secondary);margin-top:6px;">${c.txt}</div>`;
      area.appendChild(row);
    });
  }

  function renderSkillPage() {
    area.innerHTML = `
      <div class="panel-tip" style="margin-bottom:10px;">技能分类已全部展开，点击分类标题可收起。</div>
      <div class="skill-cats" id="skillCats"></div>`;
    const catsEl = area.querySelector('#skillCats');
    Object.entries(SKILLS || {}).forEach(([cat, list]) => {
      const catDiv = document.createElement('div');
      catDiv.className = 'skill-cat';
      catDiv.innerHTML = `
        <div class="skill-cat-name">
          <span class="skill-cat-arrow">▼</span> ${catName(cat)}
          <span class="skill-cat-count">${list.length}</span>
        </div>
        <div class="skill-cat-body"></div>`;
      const body = catDiv.querySelector('.skill-cat-body');
      list.forEach((sk) => {
        const val = p.skills[sk.id] || 0;
        const lv = Math.floor(val / 25) + 1;
        const pct = val % 25;
        const row = document.createElement('div');
        row.className = 'skill-item';
        row.innerHTML = `
          <div class="attr-line">
            <span class="attr-name">${sk.name}</span>
            <span class="skill-lv">Lv.${lv}</span>
            <span class="attr-val">${val}</span>
          </div>
          <div class="bar"><div class="bar-fill" style="width:${clamp(val, 0, 100)}%;background:linear-gradient(90deg,var(--mist-soft),var(--mist));"></div></div>
          <div class="skill-progress">升级进度 ${pct}/100</div>`;
        body.appendChild(row);
      });
      catDiv.querySelector('.skill-cat-name').addEventListener('click', () => {
        catDiv.classList.toggle('skill-cat-collapsed');
      });
      catsEl.appendChild(catDiv);
    });
  }

  render('base');
}

function MARKS_FILTERED(ids) {
  const all = {
    eyebrow: '眉心痣', 'eye-l-left': '左眼角痣', 'eye-l-down': '左眼睑痣',
    'eye-r-left': '右眼角痣', 'eye-r-down': '右眼睑痣', 'mouth-l': '左侧嘴角痣',
    'mouth-r': '右侧嘴角痣', nose: '鼻翼痣', collarbone: '锁骨痣',
  };
  return ids.map((id) => all[id]).filter(Boolean);
}

// 纯色 SVG 图标（代替 emoji，统一单色风格）
const SOLID_ICON = {
  con: 'M5 8v8M19 8v8M5 10h2v4H5zM17 10h2v4h-2zM7 12h10M10 5h4v14h-4z',
  int: 'M12 3a6 6 0 0 1 6 6c0 2.2-1.2 4-3 5 .3 2.6 2.4 4.5 5 5v2c-4-.4-7-2.8-7.4-6.3L12 14.8l-.6.9C11 19.2 8 21.6 4 22v-2c2.6-.5 4.7-2.4 5-5-1.8-1-3-2.8-3-5a6 6 0 0 1 6-6z',
  per: 'M12 5C6.5 5 2.5 12 2.5 12s4 7 9.5 7 9.5-7 9.5-7S17.5 5 12 5zm0 5a2 2 0 1 1 0 4 2 2 0 0 1 0-4z',
  cha: 'M12 17.3l-6.2 4 1.8-7.2L2 9.5l7.3-.6L12 2l2.7 6.9 7.3.6-5.6 4.6 1.8 7.2z',
  luk: 'M12 2l3 6.5L22 9l-5.5 5 1.4 7.4L12 18l-5.9 3.4 1.4-7.4L2 9l7-0.5zM12 5.4L10.4 8.6 7 9l2.6 2.4-.7 3.4L12 13l3.1 1.8-.7-3.4L17 9l-3.4-.4z',
  school: 'M12 3L1 8l11 5 11-5zM5 10.5V17c0 1.5 3 3 7 3s7-1.5 7-3v-6.5L12 14z',
  community: 'M4 11h3v9H4zM10 8h4v12h-4zM16 5h4v15h-4zM2 21h20v2H2z',
  crime: 'M6 8h12v2H6zM6 12h12v2H6zM6 16h12v2H6zM12 2c-2 0-3 1.5-3 3v1h2V5c0-.6.4-1 1-1s1 .4 1 1v1h2V5c0-1.5-1-3-3-3z',
  faith: 'M12 3L2 14h6l4-6 4 6h6zM6 18h12v2H6zM12 12l-2 2h4z',
};
function solidIcon(name, color) {
  const d = SOLID_ICON[name];
  if (!d) return name;
  return `<svg viewBox="0 0 24 24" width="17" height="17" aria-hidden="true" style="fill:${color};flex-shrink:0;display:block;"><path d="${d}"/></svg>`;
}
function catName(cat) {
  return { academic: '学科', art: '艺术', practical: '实用', social: '职业' }[cat] || cat;
}
function maxHP(p) {
  return Math.round(50 + p.attributes.con * 5 + p.stats.sta * 0.2);
}

// ============ 社交面板 ============
export function openSocialPanel(s) {
  const tabs = [
    { id: 'relations', label: '关系' },
    { id: 'thoughts', label: '想法' },
  ];
  const { content } = panelShell('社交', '<div class="panel-inner" id="socialBody"></div>');
  const body = content.querySelector('#socialBody');
  const bar = tabBar(tabs, 'relations', (id) => render(id));
  body.appendChild(bar);
  const area = document.createElement('div');
  body.appendChild(area);

  function render(id) {
    if (id === 'relations') renderRelations();
    else renderThoughts();
  }

  function knownChars() {
    const builtin = CHARACTERS.filter((c) => s.relations[c.id] && s.relations[c.id].met);
    const custom = (s.createdChars || []).filter((c) => s.relations[c.id] && s.relations[c.id].met);
    return [...builtin, ...custom];
  }

  function renderRelations() {
    const list = knownChars();
    area.innerHTML = list.length ? '' : '<div class="empty-hint">还没有认识任何人<br>去外面走走吧</div>';
    list.forEach((c) => {
      const r = s.relations[c.id];
      const fav = favLabel(r);
      const rel = document.createElement('div');
      rel.className = 'social-item';
      rel.innerHTML = `
        <div class="social-ava" style="background:${charColor(c.id)};">${c.name.slice(0, 1)}</div>
        <div class="social-info">
          <div class="social-name">${c.name} <span class="tag">${fav}</span></div>
          <div class="social-sub">${c.age}岁 · ${c.identity}</div>
          <div class="social-bars">
            <div class="mini-bar"><span class="mini-label">好感</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${r.f}%;background:linear-gradient(90deg,var(--accent-soft),var(--accent));"></div></div><b class="mini-val">${Math.round(r.f)}</b></div>
            <div class="mini-bar"><span class="mini-label">爱意</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${r.l}%;background:linear-gradient(90deg,#E8B4C8,#D976A0);"></div></div><b class="mini-val">${Math.round(r.l)}</b></div>
            <div class="mini-bar"><span class="mini-label">恨意</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${r.h}%;background:linear-gradient(90deg,#D8C4B8,#8A7A6A);"></div></div><b class="mini-val">${Math.round(r.h)}</b></div>
          </div>
        </div>
        <button class="btn btn-sm social-detail">详情</button>`;
      rel.querySelector('.social-detail').addEventListener('click', () => showCharDetail(c, area, () => renderRelations()));
      area.appendChild(rel);
    });
  }

  function favLabel(r) {
    if (r.isGuardian) return '亲人';
    if (r.l >= 80) return '挚爱';
    if (r.l >= 50) return '爱慕';
    if (r.h >= 80) return '宿敌';
    if (r.f >= 70) return '挚友';
    if (r.f >= 40) return '熟识';
    if (r.f >= 20) return '相识';
    return '初识';
  }

  function renderThoughts() {
    const custom = s.createdChars || [];
    const metIds = new Set(Object.entries(s.relations).filter(([, r]) => r.met).map(([id]) => id));
    const metBuiltin = CHARACTERS.filter((c) => metIds.has(c.id));
    const metCustom = custom.filter((c) => metIds.has(c.id));
    // AI 生成等其他角色：既不在内置角色库、也不在用户创建的角色库中，但已遇到
    const metOther = [...metIds]
      .filter((id) => !CHARACTERS.some((c) => c.id === id) && !custom.some((c) => c.id === id))
      .map((id) => {
        const r = s.relations[id];
        return { id, name: (r && r.name) || id, r };
      });
    const metAll = [...metBuiltin, ...metCustom, ...metOther];
    area.innerHTML = `
      <div class="thought-stats">
        <div class="thought-cell"><b>${metAll.length}</b><span>已遇到角色</span></div>
      </div>
      <div class="panel-sec">剧情中遇到的角色（${metAll.length}）</div>
      <div class="thought-char-list">
        ${metAll.length ? metAll.map((c) => {
          const isOther = c.r && !CHARACTERS.some((x) => x.id === c.id) && !custom.some((x) => x.id === c.id);
          return `
          <div class="thought-char">
            <div class="thought-char-ava">${c.name.slice(0, 1)}</div>
            <div class="thought-char-name">${c.name}</div>
            <span class="tag">已遇到</span>
            ${isOther ? `<button class="btn btn-sm btn-primary" data-add="${c.id}" style="padding:2px 8px;height:26px;font-size:11px;">加入角色库</button>` : ''}
          </div>`;
        }).join('')
          : '<div class="empty-hint">还没有遇到过任何人<br>多推进剧情，遇到的人会出现在这里</div>'}
      </div>
      <div class="panel-tip">这里只记录你在剧情中遇见过的角色。AI 生成的角色也可以一键加入角色库。</div>`;
    area.querySelectorAll('[data-add]').forEach((el) => {
      el.addEventListener('click', () => {
        const id = el.dataset.add;
        const r = s.relations[id];
        addCreatedChar(s, { id, name: (r && r.name) || id, age: 16, identity: 'AI 生成角色', gender: '未知', personality: '神秘', type: 'npc' });
        toast('已加入角色库');
        renderThoughts();
      });
    });
  }

  render('relations');
}

function charColor(id) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) % 360;
  return `hsl(${hash}, 40%, 62%)`;
}

function charTags(c) {
  const tags = [];
  const typeTag = {
    guardian: '家人', school: '同学', student: '同学', teacher: '老师', shop: '店主', work: '同事',
  }[c.type] || '';
  if (typeTag) tags.push(typeTag);
  const kw = ['病娇', '高傲', '傲娇', '温柔', '冷淡', '腹黑', '毒舌', '害羞', '活泼', '安静', '神秘', '成熟', '可靠', '开朗', '内向', '外冷内热', '认真', '随性', '优雅', '元气'];
  kw.forEach((k) => {
    if (tags.length >= 5) return;
    if (c.personality && c.personality.includes(k)) tags.push(k);
  });
  if (!tags.length) tags.push('路人');
  return tags;
}

// 角色对用户的第一感官 / 想法（基于性格与当前关系动态生成）
function firstImpression(c, r) {
  const per = c.personality || '';
  const feel = r.f >= 70 ? '你在TA心里已经是很重要的存在。'
    : r.f >= 40 ? 'TA待你亲近，愿意把心事分你一些。'
    : r.f >= 20 ? 'TA对你印象不错，正在慢慢把你放进日常里。'
    : '你们还谈不上熟悉，但TA记住了你的样子。';
  if (c.type === 'guardian') return 'TA把你当作家人。初见时只觉得你安静拘谨，如今慢慢习惯了这个家里多了一个你。';
  if (/冷漠|冷淡|外冷内热|高傲/.test(per)) {
    return `初见时TA只是淡淡扫了你一眼，话不多，客气而疏离。${feel}`;
  }
  if (/温柔|可靠|成熟|认真/.test(per)) {
    return `初见时TA语气温和，处处照顾着你的感受。${feel}`;
  }
  if (/活泼|开朗|元气/.test(per)) {
    return `初见时TA笑容明亮，主动和你搭话，没让你冷场。${feel}`;
  }
  if (/害羞|内向|安静/.test(per)) {
    return `初见时TA话不多，偶尔对上你的目光会别开脸。${feel}`;
  }
  if (/病娇|腹黑|神秘/.test(per)) {
    return `初见时TA笑着靠近，语气里却藏着打量，让你一时看不透。${feel}`;
  }
  return `初见时TA打量着出现在面前的你。${feel}`;
}

function showCharDetail(c, container, backFn) {
  const s = Game.state;
  const r = s.relations[c.id];
  const g = charGender(s, c.id) || c.gender;
  const cname = gendText(s, c.id, c.name);
  const cid = gendText(s, c.id, c.identity);
  const cap = gendText(s, c.id, c.appearance);
  const cper = gendText(s, c.id, c.personality);
  const cgender = (g === '男' || g === '女') ? g : (g || c.gender);
  container.innerHTML = `
    <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
      <button class="btn btn-sm social-back" id="sdBack">‹ 返回</button>
      <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">角色详情</span>
    </div>
    <div class="sd-head">
      <div class="social-ava" style="width:56px;height:56px;font-size:24px;background:${charColor(c.id)};">${cname.slice(0, 1)}</div>
      <div class="sd-head-info">
        <div class="sd-name">${cname}</div>
        <div class="sd-meta">${cgender} · ${c.age}岁</div>
        <div class="sd-tags">${charTags(c).map((t) => `<span class="tag">${t}</span>`).join('')}</div>
      </div>
    </div>
    <div class="sd-relation">
      <div class="sd-rel-label">与你的关系</div>
      <div class="sd-bars">
        <div class="mini-bar"><span class="mini-label">友谊</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${r.f}%;background:linear-gradient(90deg,var(--accent-soft),var(--accent));"></div></div><b class="mini-val">${Math.round(r.f)}</b></div>
        <div class="mini-bar"><span class="mini-label">恋爱</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${r.l}%;background:linear-gradient(90deg,#E8B4C8,#D976A0);"></div></div><b class="mini-val">${Math.round(r.l)}</b></div>
        <div class="mini-bar"><span class="mini-label">恨意</span><div class="bar" style="flex:1;"><div class="bar-fill" style="width:${r.h}%;background:linear-gradient(90deg,#D8C4B8,#8A7A6A);"></div></div><b class="mini-val">${Math.round(r.h)}</b></div>
      </div>
    </div>
    <div class="sd-block"><div class="sd-block-title">身份职业</div><div class="sd-block-txt">${cid}</div></div>
    <div class="sd-block"><div class="sd-block-title">外貌描述</div><div class="sd-block-txt">${cap || '还未仔细观察过TA的容貌。'}</div></div>
    <div class="sd-block"><div class="sd-block-title">性格描述</div><div class="sd-block-txt">${cper}</div></div>
    <div class="sd-block"><div class="sd-block-title">TA对你的想法</div><div class="sd-block-txt">${firstImpression(c, r)}</div></div>`;
  container.querySelector('#sdBack').addEventListener('click', backFn);
}

// ============ 日志面板 ============
export function openJournalPanel(s, initialTab = 'map') {
  const tabs = [
    { id: 'map', label: '地图' },
    { id: 'record', label: '记录' },
    { id: 'tasks', label: '任务' },
    { id: 'world', label: '世界观' },
    { id: 'memory', label: '记忆库' },
  ];
  const { content } = panelShell('日志', '<div class="panel-inner" id="journalBody"></div>');
  const body = content.querySelector('#journalBody');
  const bar = tabBar(tabs, initialTab, (id) => render(id));
  body.appendChild(bar);
  const area = document.createElement('div');
  body.appendChild(area);

  function render(id) {
    if (id === 'map') renderMap();
    else if (id === 'record') renderRecord();
    else if (id === 'tasks') renderTasks();
    else if (id === 'world') renderWorld();
    else renderMemory();
  }

  function renderMap() {
    const visited = new Set(s.journal.visitedPlaces || []);
    area.innerHTML = `
      <div class="panel-sec">街道探索</div>
      <div class="street-grid">
        ${STREETS.map((st) => {
          const explored = (s.journal.exploredStreets || []).includes(st.id);
          return `<div class="street-cell ${explored ? 'done' : ''}" data-id="${st.id}">
            <div class="street-name">${st.name}</div>
            <div class="street-desc">${st.dir} · ${st.pos}</div>
          </div>`;
        }).join('')}
      </div>
      <div class="panel-sec">地点</div>
      ${PLACES.map((pl) => {
        const isVisited = visited.has(pl.id);
        return `
        <div class="place-row ${isVisited ? '' : 'unvisited'}">
          <div class="place-zone">${pl.zone}</div>
          <div class="place-name">${pl.name} ${isVisited ? '' : '<span class="tag">未探索</span>'}</div>
          <div class="place-desc">${pl.desc}</div>
        </div>`;
      }).join('')}
      <div class="panel-tip">通过「外出」探索新地点，解锁更多剧情。</div>`;
  }

  function renderRecord() {
    const history = [...(s.narrative.history || [])].reverse();
    area.innerHTML = history.length ? '' : '<div class="empty-hint">还没有记录</div>';
    history.forEach((h) => {
      if (h.type === 'system') {
        const row = document.createElement('div');
        row.className = 'record-row system';
        row.innerHTML = `<div class="record-day">第${h.day || '?'}天</div><div class="record-text">${h.text}</div>`;
        area.appendChild(row);
      } else {
        const row = document.createElement('div');
        row.className = 'record-row';
        row.innerHTML = `<div class="record-day">第${h.day || '?'}天</div><div class="record-main"><div class="record-title">${h.title}</div><div class="record-text">${h.text}</div></div>`;
        area.appendChild(row);
      }
    });
  }

  function renderTasks() {
    const tasks = s.journal.tasks || [];
    const completed = s.journal.completedTasks || [];
    area.innerHTML = `
      <div class="panel-sec">进行中（${tasks.length}）</div>
      ${tasks.length ? tasks.map((t, i) => `
        <div class="task-item">
          <div class="task-text">${t}</div>
          <button class="btn btn-sm" data-i="${i}">完成</button>
        </div>`).join('') : '<div class="empty-hint">暂无进行中的任务</div>'}
      <div class="panel-sec">已完成（${completed.length}）</div>
      ${completed.length ? completed.map((t) => `<div class="task-item done"><div class="task-text">${t}</div></div>`).join('') : '<div class="empty-hint">暂无已完成任务</div>'}`;
    area.querySelectorAll('.task-item button').forEach((btn) => {
      btn.addEventListener('click', () => {
        const i = parseInt(btn.dataset.i, 10);
        s.journal.completedTasks.push(s.journal.tasks.splice(i, 1)[0]);
        saveState(s);
        renderTasks();
        toast('任务完成');
      });
    });
  }

  function renderWorld() {
    area.innerHTML = `
      <div class="world-hero">
        <div class="world-name font-kai">${WORLD.name}</div>
        <div class="world-motto">${WORLD.motto}</div>
        <div class="world-intro">${WORLD.intro}</div>
      </div>
      <div class="panel-sec">城市布局</div>
      <div class="world-layout">${WORLD.layout}</div>
      <div class="panel-sec">学校</div>
      ${Object.entries(SCHOOLS).map(([k, sc]) => `
        <div class="world-school">
          <div class="school-name">${sc.name}</div>
          <div class="school-sub">${sc.location}</div>
          <div class="school-motto">"${sc.motto}"</div>
        </div>`).join('')}
      ${Object.entries(WORLD_ENCYCLOPEDIA).map(([k, txt]) => `
        <div class="panel-sec">${encyName(k)}</div>
        <div class="world-text">${txt}</div>`).join('')}`;
  }

  function encyName(k) {
    return { history: '云栖历史', doctrine: '晨光教义', festivals: '城市节日', society: '社会百态', gray: '灰色地带' }[k] || k;
  }

  function renderMemory() {
    const mem = s.journal.memory || [];
    area.innerHTML = `
      <div class="panel-sec">记忆库（${mem.length}）</div>
      <div class="panel-tip" style="margin-bottom:8px;">每当做出选择后，都会将大致剧情记录于此。点击条目可展开查看。</div>
      ${mem.length ? mem.map((m, i) => `
        <div class="memory-item" data-i="${i}">
          <div class="memory-head">
            <span class="memory-day">${m.day}天 · ${m.timeText}</span>
            <span class="memory-arrow">▸</span>
          </div>
          <div class="memory-text" style="display:none;">${m.text}</div>
        </div>`).join('') : '<div class="empty-hint">记忆库为空</div>'}
      <div class="panel-sec">导入 / 导出</div>
      <div style="display:flex;gap:10px;">
        <button class="btn btn-sm" id="memExport">导出JSON</button>
        <button class="btn btn-sm" id="memImport">导入JSON</button>
      </div>`;
    area.querySelectorAll('.memory-item').forEach((el) => {
      el.addEventListener('click', () => {
        const body = el.querySelector('.memory-text');
        const open = body.style.display !== 'none';
        body.style.display = open ? 'none' : 'block';
        el.querySelector('.memory-arrow').textContent = open ? '▸' : '▾';
        el.classList.toggle('open', !open);
      });
    });
    area.querySelector('#memExport').addEventListener('click', () => downloadSave(s));
    area.querySelector('#memImport').addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.onchange = () => {
        const file = input.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          const data = importSaveJSON(reader.result);
          if (!data) return toast('导入失败：文件格式不正确');
          Object.assign(s, data);
          s.flags.opened = true;
          saveState(s);
          setAPIConfig(s.settings.api);
          closeModal();
          navigate('game');
          toast('存档已导入');
        };
        reader.readAsText(file);
      };
      input.click();
    });
  }

  render(initialTab);
}

// ============ 成就面板 ============
export function openAchievePanel(s) {
  const cats = ACHIEVEMENT_CATEGORIES.map((c) => ({ id: c.id, label: c.name }));
  const { content } = panelShell('成就', '<div class="panel-inner" id="achBody"></div>');
  const body = content.querySelector('#achBody');
  const bar = tabBar(cats, cats[0].id, (id) => render(id));
  body.appendChild(bar);
  const area = document.createElement('div');
  body.appendChild(area);

  function unlocked() {
    return new Set(s.journal.unlockedAch || []);
  }

  function render(catId) {
    const list = ACHIEVEMENTS.filter((a) => a.cat === catId);
    const un = unlocked();
    const done = list.filter((a) => un.has(a.id));
    area.innerHTML = `
      <div class="ach-progress">
        <div class="ach-progress-text">${done.length} / ${list.length}</div>
        <div class="bar"><div class="bar-fill" style="width:${list.length ? (done.length / list.length) * 100 : 0}%;background:linear-gradient(90deg,var(--butter-soft),var(--butter));"></div></div>
      </div>
      ${list.map((a) => {
        const isUnlocked = un.has(a.id);
        if (a.hidden && !isUnlocked) return '';
        const progVal = s.journal.achProgress && s.journal.achProgress[a.id] != null ? s.journal.achProgress[a.id] : (a.progress || 0);
        const pt = a.progressTarget ? a.progressTarget.target : 0;
        return `
        <div class="ach-item ${isUnlocked ? 'unlocked' : ''}">
          <div class="ach-ico">${isUnlocked ? '✦' : '✧'}</div>
          <div class="ach-info">
            <div class="ach-name">${a.name}</div>
            <div class="ach-desc">${isUnlocked ? a.cond : '？？？'}</div>
          </div>
          ${pt ? `<div class="ach-prog">${Math.min(pt, progVal)}/${pt}</div>` : ''}
        </div>`;
      }).join('')}`;
  }

  render(cats[0].id);
}

// ============ 背包面板 ============
export function openBagPanel(s, onUse = () => {}) {
  const { content } = panelShell('背包', '<div class="panel-inner" id="bagBody"></div>');
  const body = content.querySelector('#bagBody');
  const area = document.createElement('div');
  body.appendChild(area);
  render();

  function render() {
    const inv = s.inventory || [];
    const gridCells = 30;
    area.innerHTML = `
      <div class="bag-meta">
        <span>物品 <b>${inv.length}</b> / ${gridCells}</span>
        <span>金币 <b>¥${s.player.money}</b></span>
      </div>
      <div class="bag-grid">
        ${Array.from({ length: gridCells }, (_, i) => {
          const item = inv[i];
          if (!item) return `<div class="bag-cell empty"></div>`;
          const def = ITEMS.find((x) => x.id === item.id);
          const isStory = def && def.special === 'story';
          return `
          <div class="bag-cell ${isStory ? 'bag-cell-story' : ''}" data-i="${i}" title="${def ? def.name : item.id}">
            <div class="bag-ico">${itemIcon(def ? def.cat : '')}</div>
            ${item.qty > 1 ? `<div class="bag-qty">×${item.qty}</div>` : ''}
          </div>`;
        }).join('')}
      </div>`;
    area.querySelectorAll('.bag-cell:not(.empty)').forEach((cell) => {
      cell.addEventListener('click', () => {
        const i = parseInt(cell.dataset.i, 10);
        const item = inv[i];
        const def = ITEMS.find((x) => x.id === item.id);
        if (!def) return;
        showItemMenu(def, () => {
          render();
          onUse();
        });
      });
    });
  }
}

export function openModPanel(s) {
  const { content } = panelShell('模组', '<div class="panel-inner" id="modBody"></div>');
  const body = content.querySelector('#modBody');
  const area = document.createElement('div');
  body.appendChild(area);
  render();

  function render() {
    const mods = s.mods || [];
    area.innerHTML = `
      <div class="mod-meta">
        <span>已导入 <b>${mods.length}</b> 个模组</span>
        <button class="btn btn-sm btn-primary" id="modImport">📥 导入模组</button>
      </div>
      <div style="font-size:12px;color:var(--text-faint);margin:8px 2px 10px;line-height:1.6;">
        支持导入 .json 模组文件（自定义角色 / 剧情 / 世界观扩展）。导入后即可在游戏中使用。
      </div>
      ${mods.length ? '' : '<div class="empty-hint">还没有导入任何模组<br>点击上方「导入模组」添加</div>'}
      <div id="modList">
        ${mods.map((m, i) => `
          <div class="mod-item" data-i="${i}">
            <div class="mod-ico">📦</div>
            <div class="mod-info">
              <div class="mod-name">${m.name || '未命名模组'}</div>
              <div class="mod-desc">${m.desc || '无描述'} · ${m.time || ''}</div>
              <div class="mod-tags">${(m.tags || ['扩展']).map((t) => `<span class="tag">${t}</span>`).join('')}</div>
            </div>
            <button class="btn btn-sm btn-danger" data-del="${i}">删除</button>
          </div>`).join('')}
      </div>`;
    area.querySelector('#modImport').addEventListener('click', importMod);
    area.querySelectorAll('[data-del]').forEach((el) => {
      el.addEventListener('click', () => {
        const i = parseInt(el.dataset.del, 10);
        if (window.confirm(`删除模组「${mods[i].name || '未命名'}」？`)) {
          s.mods.splice(i, 1);
          saveState(s);
          toast('模组已删除');
          render();
        }
      });
    });
  }

  function importMod() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json,application/json';
    input.addEventListener('change', () => {
      const f = input.files && input.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        try {
          const data = JSON.parse(reader.result);
          if (!s.mods) s.mods = [];
          s.mods.push({
            id: 'mod' + Date.now(),
            name: data.name || f.name.replace(/\.json$/i, ''),
            desc: data.desc || '',
            tags: data.tags || ['扩展'],
            time: new Date().toLocaleDateString(),
            data,
          });
          saveState(s);
          toast('模组已导入');
          render();
        } catch (e) {
          toast('导入失败：不是有效的 JSON 文件');
        }
      };
      reader.readAsText(f);
    });
    input.click();
  }
}

function showItemMenu(def, after) {
  const isStory = def.special === 'story';
  const body = document.createElement('div');
  body.className = 'modal-body';
  body.innerHTML = `
    <div style="display:flex;gap:14px;align-items:center;margin-bottom:10px;">
      <div class="bag-ico" style="font-size:34px;${isStory ? 'border:2px solid var(--warn);border-radius:14px;padding:6px;' : ''}">${itemIcon(def.cat)}</div>
      <div>
        <div style="font-size:17px;font-weight:600;color:var(--accent-deep);">${def.name}</div>
        <div class="tag" style="margin-top:4px;">${catNameItem(def.cat)}${isStory ? ' · 剧情关键道具' : ''}</div>
      </div>
    </div>
    <div style="font-size:13px;line-height:1.8;color:var(--text-secondary);margin-bottom:8px;">${def.desc}</div>
    ${def.effect ? `<div style="font-size:12px;color:var(--good);margin-bottom:8px;">效果：${JSON.stringify(def.effect)}</div>` : ''}
    <div style="font-size:12px;color:var(--text-faint);">售价：¥${def.price}</div>`;
  const { card } = openModal(body, {});
  card.style.maxWidth = '420px';
  card.querySelector('.modal-header')?.remove();
  const footer = document.createElement('div');
  footer.className = 'modal-footer';
  footer.style.flexWrap = 'wrap';
  const detailBtn = document.createElement('button');
  detailBtn.className = 'btn btn-sm';
  detailBtn.textContent = '查看详情';
  detailBtn.addEventListener('click', () => {
    closeModal();
    showItemDetail(def, after);
  });
  const useBtn = document.createElement('button');
  useBtn.className = 'btn btn-primary btn-sm';
  useBtn.textContent = '使用';
  useBtn.addEventListener('click', () => {
    const s = Game.state;
    if (def.effect && !(def.cat === 'collectible')) {
      Object.entries(def.effect).forEach(([k, v]) => {
        if (k in s.player.stats) s.player.stats[k] = clamp(s.player.stats[k] + v, 0, 100);
        if (k === 'mood') s.player.mood = clamp(s.player.mood + v, 0, 100);
        if (k === 'hp') s.player.stats.hp = clamp(s.player.stats.hp + v, 0, maxHP(s.player));
      });
      removeItem(s, def.id, 1);
      saveState(s);
      toast(`使用了 ${def.name}`);
      closeModal();
      after && after();
    } else {
      toast(isStory ? '剧情关键道具，请妥善保管' : '该物品无法直接使用');
    }
  });
  const giftBtn = document.createElement('button');
  giftBtn.className = 'btn btn-sm';
  giftBtn.textContent = '赠予';
  giftBtn.addEventListener('click', () => {
    closeModal();
    giftItemTo(def, after);
  });
  const dropBtn = document.createElement('button');
  dropBtn.className = 'btn btn-sm btn-danger';
  dropBtn.textContent = isStory ? '不可丢弃' : '丢弃';
  dropBtn.disabled = isStory;
  dropBtn.addEventListener('click', () => {
    removeItem(Game.state, def.id, 1);
    saveState(Game.state);
    toast(`已丢弃 ${def.name}`);
    after && after();
  });
  footer.appendChild(detailBtn);
  if (!(def.cat === 'collectible' && !def.effect)) footer.appendChild(useBtn);
  footer.appendChild(giftBtn);
  footer.appendChild(dropBtn);
  card.appendChild(footer);
}

function giftItemTo(def, after) {
  const s = Game.state;
  const chars = CHARACTERS.filter((c) => s.relations[c.id] && s.relations[c.id].met);
  if (!chars.length) return toast('还没有认识任何人，无法赠予');
  const body = document.createElement('div');
  body.className = 'modal-body';
  body.innerHTML = `
    <div style="font-size:14px;font-weight:600;color:var(--accent-deep);margin-bottom:10px;">将「${def.name}」赠予谁？</div>
    <div class="gift-char-list">
      ${chars.map((c) => {
        const r = s.relations[c.id];
        return `
        <button class="gift-char" data-id="${c.id}">
          <div class="social-ava" style="width:36px;height:36px;font-size:15px;background:${charColor(c.id)};">${c.name.slice(0, 1)}</div>
          <span>${c.name}</span>
          <span class="tag">好感${Math.round(r.f)}</span>
        </button>`;
      }).join('')}
    </div>`;
  const { card } = openModal(body, {});
  card.style.maxWidth = '460px';
  card.querySelector('.modal-header')?.remove();
  body.querySelectorAll('.gift-char').forEach((btn) => {
    btn.addEventListener('click', () => {
      const cid = btn.dataset.id;
      const char = CHARACTERS.find((c) => c.id === cid) || (s.createdChars || []).find((c) => c.id === cid);
      const r = s.relations[cid];
      removeItem(s, def.id, 1);
      const gain = def.cat === 'gift' ? 12 : 6;
      const fav = def.likedGifts && def.likedGifts.some((x) => def.name.includes(x)) ? 1.5 : 1;
      changeRelation(s, cid, Math.round(gain * fav), 'f');
      r.talkCount = (r.talkCount || 0) + 1;
      saveState(s);
      closeModal();
      toast(`你将「${def.name}」送给了${char ? char.name : ''}，好感提升`);
      after && after();
    });
  });
}

function itemIcon(cat) {
  return { food: '🍙', drink: '🥤', equipment: '👕', book: '📖', gift: '🎁', tool: '🔧', medical: '💊', other: '📦' }[cat] || '📦';
}

function showItemDetail(def, after) {
  const content = document.createElement('div');
  content.className = 'modal-body';
  content.innerHTML = `
    <div style="display:flex;gap:14px;align-items:center;margin-bottom:10px;">
      <div style="font-size:34px;">${itemIcon(def.cat)}</div>
      <div>
        <div style="font-size:17px;font-weight:600;color:var(--accent-deep);">${def.name}</div>
        <div class="tag" style="margin-top:4px;">${catNameItem(def.cat)}</div>
      </div>
    </div>
    <div style="font-size:13px;line-height:1.8;color:var(--text-secondary);margin-bottom:8px;">${def.desc}</div>
    ${def.effect ? `<div style="font-size:12px;color:var(--good);margin-bottom:8px;">效果：${JSON.stringify(def.effect)}</div>` : ''}
    <div style="font-size:12px;color:var(--text-faint);">售价：¥${def.price}</div>
  `;
  const { card } = openModal(content, {});
  card.style.maxWidth = '420px';
  card.querySelector('.modal-header')?.remove();
  const footer = document.createElement('div');
  footer.className = 'modal-footer';
  const useBtn = document.createElement('button');
  useBtn.className = 'btn btn-primary btn-sm';
  useBtn.textContent = '使用';
  useBtn.addEventListener('click', () => {
    const s = Game.state;
    if (def.effect) {
      Object.entries(def.effect).forEach(([k, v]) => {
        if (k in s.player.stats) s.player.stats[k] = clamp(s.player.stats[k] + v, 0, 100);
        if (k === 'mood') s.player.mood = clamp(s.player.mood + v, 0, 100);
        if (k === 'hp') s.player.stats.hp = clamp(s.player.stats.hp + v, 0, maxHP(s.player));
      });
      removeItem(s, def.id, 1);
      saveState(s);
      toast(`使用了 ${def.name}`);
      closeModal();
      after && after();
    } else {
      toast('该物品无法直接使用');
    }
  });
  const dropBtn = document.createElement('button');
  dropBtn.className = 'btn btn-sm';
  dropBtn.textContent = '丢弃';
  dropBtn.addEventListener('click', () => {
    removeItem(Game.state, def.id, 1);
    saveState(Game.state);
    closeModal();
    after && after();
  });
  footer.appendChild(dropBtn);
  footer.appendChild(useBtn);
  card.appendChild(footer);
}

function catNameItem(cat) {
  return { food: '食物', drink: '饮品', equipment: '衣物', book: '书籍', gift: '礼物', tool: '工具', medical: '药品', other: '其他' }[cat] || '其他';
}

// ============ 存档面板 ============
export function openSavePanel(s, fromLobby = false) {
  const { content } = panelShell('存档', '<div class="panel-inner" id="saveBody"></div>');
  const body = content.querySelector('#saveBody');
  const area = document.createElement('div');
  body.appendChild(area);
  let page = 1;
  const perPage = 5;
  const pages = 4;

  render();

  function allSlots() {
    const slots = [];
    for (let i = 1; i <= 20; i++) slots.push({ num: i, data: getSlotData(i) });
    return slots;
  }

  function getSlotData(num) {
    try {
      const raw = localStorage.getItem(`cijian_slot_${num}`);
      return raw ? JSON.parse(raw) : null;
    } catch (e) { return null; }
  }

  function render() {
    const slots = allSlots();
    const pageSlots = slots.slice((page - 1) * perPage, page * perPage);
    area.innerHTML = `
      <div class="save-meta">
        <span>第 ${page} / ${pages} 页</span>
        <div class="save-pages">
          ${Array.from({ length: pages }, (_, i) => `
            <button class="page-dot ${i + 1 === page ? 'active' : ''}" data-p="${i + 1}"></button>`).join('')}
        </div>
        <button class="btn btn-sm" id="saveExport">导出</button>
        <button class="btn btn-sm" id="saveImport">导入</button>
      </div>
      ${pageSlots.map((slot) => {
        const d = slot.data;
        return `
        <div class="slot-item ${d ? '' : 'empty'}">
          <div class="slot-num">${String(slot.num).padStart(2, '0')}</div>
          <div class="slot-main">
            ${d ? `
              <div class="slot-title">${d.meta ? d.meta.summary : summarizeState(d)}</div>
              <div class="slot-sub">${d.meta ? new Date(d.meta.ts).toLocaleString() : '未知时间'}</div>` : '<div class="slot-empty">空存档位</div>'}
          </div>
          ${d ? `
            <div style="display:flex;gap:6px;">
              <button class="btn btn-sm slot-load" data-n="${slot.num}">读取</button>
              <button class="btn btn-sm slot-cover" data-n="${slot.num}">覆盖</button>
              <button class="btn btn-sm btn-danger slot-del" data-n="${slot.num}">删除</button>
            </div>` : `
            <button class="btn btn-sm btn-primary slot-save" data-n="${slot.num}">保存</button>`}
        </div>`;
      }).join('')}
      <div class="panel-tip">每两天游戏会自动存档一次。</div>`;

    area.querySelectorAll('.page-dot').forEach((el) => {
      el.addEventListener('click', () => { page = parseInt(el.dataset.p, 10); render(); });
    });
    area.querySelector('#saveExport').addEventListener('click', () => downloadSave(s));
    area.querySelector('#saveImport').addEventListener('click', () => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.onchange = () => {
        const file = input.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = () => {
          const data = importSaveJSON(reader.result);
          if (!data) return toast('导入失败：文件格式不正确');
          Object.assign(s, data);
          s.flags.opened = true;
          saveState(s);
          closeModal();
          navigate('game');
          toast('存档已导入');
        };
        reader.readAsText(file);
      };
      input.click();
    });
    area.querySelectorAll('.slot-save').forEach((el) => {
      el.addEventListener('click', () => {
        saveToSlot(s, parseInt(el.dataset.n, 10));
        toast(`已保存到第 ${el.dataset.n} 号槽位`);
        render();
      });
    });
    area.querySelectorAll('.slot-load').forEach((el) => {
      el.addEventListener('click', () => {
        const data = loadFromSlot(parseInt(el.dataset.n, 10));
        if (!data) return toast('读取失败');
        Object.assign(s, data);
        s.flags.opened = true;
        saveState(s);
        closeModal();
        navigate('game');
        toast('已读取存档');
      });
    });
    area.querySelectorAll('.slot-cover').forEach((el) => {
      el.addEventListener('click', () => {
        saveToSlot(s, parseInt(el.dataset.n, 10));
        toast(`已覆盖第 ${el.dataset.n} 号槽位`);
        render();
      });
    });
    area.querySelectorAll('.slot-del').forEach((el) => {
      el.addEventListener('click', () => {
        deleteSlot(parseInt(el.dataset.n, 10));
        toast(`已删除第 ${el.dataset.n} 号槽位`);
        render();
      });
    });
  }
}

function summarizeState(s) {
  return `${s.player.name} · 第${s.time.day}天 · ¥${s.player.money}`;
}

// ============ 作弊面板 ============
export function openCheatPanel(s) {
  const { content } = panelShell('作弊面板', '<div class="panel-inner" id="cheatBody"></div>');
  const body = content.querySelector('#cheatBody');
  const area = document.createElement('div');
  body.appendChild(area);
  render();

  function render() {
    const p = getPlayer(s);
    area.innerHTML = `
      <div class="cheat-switch-row">
        <span>开启作弊模式</span>
        <label class="switch"><input type="checkbox" id="cheatOn" ${s.settings.cheat ? 'checked' : ''}><span class="slider"></span></label>
      </div>
      ${s.settings.cheat ? `
      <div class="panel-sec">数值调整</div>
      <div class="cheat-grid">
        ${[['mood', '心情', Math.round(p.mood)], ['health', '健康', p.health === '健康' ? 100 : p.health === '一般' ? 50 : 20], ['morality', '道德', Math.round(p.morality)]].map(([k, label, v]) => `
          <div class="cheat-row">
            <span>${label}</span>
            <input type="number" class="cheat-input" data-k="${k}" value="${v}" min="0" max="100000">
            <button class="btn btn-sm cheat-set" data-k="${k}">设置</button>
          </div>`).join('')}
        ${['con', 'int', 'per', 'cha', 'luk'].map((k) => `
          <div class="cheat-row">
            <span>${attrShort(k)}</span>
            <input type="number" class="cheat-input" data-k="${k}" value="${p.attributes[k]}" min="1" max="10">
            <button class="btn btn-sm cheat-set" data-k="${k}">设置</button>
          </div>`).join('')}
      </div>
      <div class="panel-sec">更改声望</div>
      <div class="cheat-row">
        <span>学校声望</span><input type="number" class="cheat-input" data-k="rep_school" value="${p.rep.school || 0}" min="0" max="100000">
        <button class="btn btn-sm cheat-set" data-k="rep_school">设置</button>
      </div>
      <div class="cheat-row">
        <span>社区声望</span><input type="number" class="cheat-input" data-k="rep_community" value="${p.rep.community || 0}" min="0" max="100000">
        <button class="btn btn-sm cheat-set" data-k="rep_community">设置</button>
      </div>
      <div class="cheat-row">
        <span>犯罪值</span><input type="number" class="cheat-input" data-k="crime" value="${p.crime || 0}" min="0" max="100000">
        <button class="btn btn-sm cheat-set" data-k="crime">设置</button>
      </div>
      <div class="cheat-row">
        <span>信仰值</span><input type="number" class="cheat-input" data-k="faith" value="${p.faith || 0}" min="0" max="100000">
        <button class="btn btn-sm cheat-set" data-k="faith">设置</button>
      </div>
      <div class="panel-sec">添加天赋</div>
      <div class="cheat-row">
        <select id="cheatTalent" class="cheat-input" style="flex:1;">
          ${TALENTS.map((t) => `<option value="${t.id}">${t.name}</option>`).join('')}
        </select>
        <button class="btn btn-sm" id="cheatAddTalent">添加</button>
      </div>
      <div class="panel-sec">成就</div>
      <div class="cheat-row">
        <button class="btn btn-sm btn-primary" id="cheatAchAll">成就全获得</button>
        <button class="btn btn-sm" id="cheatAchList">单独获得成就</button>
      </div>
      <div class="panel-sec">角色创建</div>
      <div class="cheat-row">
        <button class="btn btn-sm btn-primary" id="cheatCreateChar">创造新 NPC</button>
        <button class="btn btn-sm" id="cheatShowCustom">查看自创角色</button>
      </div>
      <div id="customCharList" style="display:none;"></div>
      <div class="panel-sec">状态填充</div>
      <div class="cheat-row">
        <button class="btn btn-sm btn-primary" id="cheatFill">回满所有状态</button>
        <button class="btn btn-sm" id="cheatGiveItems">发放所有物品×1</button>
      </div>
      <div class="panel-sec">金钱/时间操控</div>
      <div class="cheat-row">
        <span>金钱</span>
        <input type="number" class="cheat-input" data-k="money" id="cheatMoney" value="${p.money}" min="0">
        <button class="btn btn-sm cheat-set" data-k="money">设置</button>
      </div>
      <div class="cheat-row">
        <span>当前天数</span>
        <input type="number" class="cheat-input" id="cheatDay" value="${s.time.day}" min="1">
        <button class="btn btn-sm" id="cheatSetDay">设置</button>
      </div>
      <div class="cheat-row">
        <span>时段(小时)</span>
        <input type="number" class="cheat-input" id="cheatHour" value="${s.time.hour}" min="0" max="23">
        <button class="btn btn-sm" id="cheatSetHour">设置</button>
      </div>
      <div class="cheat-row">
        <span>传送到</span>
        <select id="cheatPlace" class="cheat-input" style="flex:1;">
          ${PLACES.map((pl) => `<option value="${pl.id}" ${s.location === pl.id ? 'selected' : ''}>${pl.name}</option>`).join('')}
        </select>
        <button class="btn btn-sm" id="cheatTeleport">传送</button>
      </div>
      <div class="panel-sec">技能修改</div>
      <div class="cheat-row">
        <select id="cheatSkill" class="cheat-input" style="flex:1;">
          ${Object.values(SKILLS).flat().map((sk) => `<option value="${sk.id}">${sk.name}</option>`).join('')}
        </select>
        <input type="number" class="cheat-input" id="cheatSkillVal" value="1" min="0" max="8" style="width:64px;">
        <button class="btn btn-sm" id="cheatSetSkill">设置</button>
      </div>
      <div class="panel-sec">关系修改</div>
      <div class="cheat-row">
        <select id="cheatChar" class="cheat-input" style="flex:1;">
          ${CHARACTERS.map((c) => `<option value="${c.id}">${c.name}</option>`).join('')}
        </select>
      </div>
      <div class="cheat-row">
        <span>好感</span><input type="number" class="cheat-input" id="cheatF" value="0" min="0" max="100" style="width:70px;">
        <span>爱意</span><input type="number" class="cheat-input" id="cheatL" value="0" min="0" max="100" style="width:70px;">
        <span>恨意</span><input type="number" class="cheat-input" id="cheatH" value="0" min="0" max="100" style="width:70px;">
        <button class="btn btn-sm" id="cheatSetRel">设置</button>
      </div>
      <div class="panel-sec">物品添加</div>
      <div class="cheat-row">
        <select id="cheatItem" class="cheat-input" style="flex:1;">
          ${ITEMS.map((it) => `<option value="${it.id}">${it.name}</option>`).join('')}
        </select>
        <button class="btn btn-sm" id="cheatAddItem">添加×1</button>
      </div>
      <div class="panel-sec">角色管理</div>
      <div class="cheat-row">
        <button class="btn btn-sm" id="cheatMetAll">全部认识</button>
        <button class="btn btn-sm" id="cheatFavAll">好感全满</button>
      </div>
      <div class="panel-sec">单独认识角色</div>
      <div style="font-size:12px;color:var(--text-faint);margin-bottom:8px;line-height:1.6;">勾选你想认识的角色，点击"认识所选"即可只与他们建立关系。已认识的会标记出来。</div>
      <div class="cheat-char-list" id="cheatCharList">
        ${CHARACTERS.map((c) => {
          const met = s.relations[c.id] && s.relations[c.id].met;
          return `
          <label class="cheat-char-item ${met ? 'met' : ''}" data-id="${c.id}">
            <input type="checkbox" class="cheat-char-check" data-id="${c.id}" ${met ? 'checked disabled' : ''}>
            <span class="cheat-char-ava" style="background:${charColor(c.id)};">${c.name.slice(0, 1)}</span>
            <span class="cheat-char-name">${c.name}</span>
            ${met ? '<span class="cheat-char-badge">已认识</span>' : ''}
          </label>`;
        }).join('')}
      </div>
      <div class="cheat-row" style="margin-top:10px;">
        <button class="btn btn-sm btn-primary" id="cheatMetSel">认识所选角色</button>
        <button class="btn btn-sm" id="cheatMetClear">清空选择</button>
      </div>` : ''}`;
    area.querySelector('#cheatOn').addEventListener('change', (e) => {
      s.settings.cheat = e.target.checked;
      saveState(s);
      render();
    });
    if (!s.settings.cheat) return;
    area.querySelectorAll('.cheat-set').forEach((btn) => {
      btn.addEventListener('click', () => {
        const k = btn.dataset.k;
        const input = area.querySelector(`.cheat-input[data-k="${k}"]`);
        const v = parseInt(input.value, 10);
        if (['con', 'int', 'per', 'cha', 'luk'].includes(k)) {
          p.attributes[k] = clamp(v, 1, 10);
        } else if (k === 'money') {
          p.money = Math.max(0, v);
        } else if (k === 'mood') {
          p.mood = clamp(v, 0, 100);
        } else if (k === 'morality') {
          p.morality = clamp(v, 0, 100);
        } else if (k === 'health') {
          p.health = v >= 80 ? '健康' : v >= 40 ? '一般' : '虚弱';
        } else if (k === 'rep_school') {
          p.rep.school = Math.max(0, v);
          p.rep.total = Math.max(0, (p.rep.total || 0) + Math.max(0, v) - (p.rep.schoolBefore || 0));
          p.rep.schoolBefore = Math.max(0, v);
        } else if (k === 'rep_community') {
          p.rep.community = Math.max(0, v);
          p.rep.total = Math.max(0, (p.rep.total || 0) + Math.max(0, v) - (p.rep.communityBefore || 0));
          p.rep.communityBefore = Math.max(0, v);
        } else if (k === 'crime') {
          p.crime = Math.max(0, v);
        } else if (k === 'faith') {
          p.faith = Math.max(0, v);
        }
        saveState(s);
        toast('已设置');
      });
    });
    area.querySelector('#cheatAddTalent').addEventListener('click', () => {
      const tid = area.querySelector('#cheatTalent').value;
      if (!p.talents) p.talents = [];
      if (p.talents.includes(tid)) return toast('已拥有该天赋');
      p.talents.push(tid);
      saveState(s);
      const t = TALENTS.find((x) => x.id === tid);
      toast(`已添加天赋：${t ? t.name : tid}`);
      render();
    });
    area.querySelector('#cheatAchAll').addEventListener('click', () => {
      if (!s.journal.unlockedAch) s.journal.unlockedAch = [];
      ACHIEVEMENTS.forEach((a) => {
        if (!s.journal.unlockedAch.includes(a.id)) s.journal.unlockedAch.push(a.id);
      });
      saveState(s);
      toast(`已获得全部 ${ACHIEVEMENTS.length} 个成就`);
      render();
    });
    area.querySelector('#cheatAchList').addEventListener('click', () => {
      const body = document.createElement('div');
      body.className = 'modal-body';
      body.style.maxHeight = '60vh';
      body.style.overflowY = 'auto';
      body.innerHTML = `
        <div style="font-size:14px;font-weight:600;color:var(--accent-deep);margin-bottom:10px;">选择要获得的成就</div>
        <div class="cheat-ach-list">
          ${ACHIEVEMENTS.map((a) => {
            const has = (s.journal.unlockedAch || []).includes(a.id);
            return `
            <label class="cheat-ach-item ${has ? 'owned' : ''}">
              <input type="checkbox" class="cheat-ach-check" data-id="${a.id}" ${has ? 'checked disabled' : ''}>
              <span>${a.name}</span>
            </label>`;
          }).join('')}
        </div>`;
      const { card } = openModal(body, {});
      card.style.maxWidth = '480px';
      card.querySelector('.modal-header')?.remove();
      const footer = document.createElement('div');
      footer.className = 'modal-footer';
      const ok = document.createElement('button');
      ok.className = 'btn btn-primary btn-sm';
      ok.textContent = '获得所选成就';
      ok.addEventListener('click', () => {
        const picked = [...body.querySelectorAll('.cheat-ach-check:checked')].map((c) => parseInt(c.dataset.id, 10));
        if (!picked.length) return toast('请先勾选成就');
        if (!s.journal.unlockedAch) s.journal.unlockedAch = [];
        picked.forEach((id) => { if (!s.journal.unlockedAch.includes(id)) s.journal.unlockedAch.push(id); });
        saveState(s);
        toast(`已获得 ${picked.length} 个成就`);
        closeModal();
        render();
      });
      footer.appendChild(ok);
      card.appendChild(footer);
    });
    area.querySelector('#cheatCreateChar').addEventListener('click', () => openCharCreate(s, () => render()));
    area.querySelector('#cheatShowCustom').addEventListener('click', () => {
      const box = area.querySelector('#customCharList');
      const custom = s.createdChars || [];
      box.style.display = box.style.display === 'none' ? 'block' : 'none';
      if (box.style.display !== 'none') {
        box.innerHTML = custom.length ? custom.map((c, i) => `
          <div class="cheat-row" style="justify-content:flex-start;">
            <span style="flex:1;">${c.name} · ${c.age}岁 · ${c.identity}</span>
            <button class="btn btn-sm" data-del="${i}">删除</button>
          </div>`).join('') : '<div class="empty-hint">暂无自创角色</div>';
        box.querySelectorAll('[data-del]').forEach((b) => {
          b.addEventListener('click', () => {
            s.createdChars.splice(parseInt(b.dataset.del, 10), 1);
            saveState(s);
            area.querySelector('#cheatShowCustom').click();
          });
        });
      }
    });
    area.querySelector('#cheatFill').addEventListener('click', () => {
      p.stats.hp = maxHP(p);
      p.stats.ep = 200;
      p.stats.sat = 100;
      p.stats.cln = 100;
      p.stats.sta = 200;
      p.stats.stress = 0;
      p.mood = 100;
      p.health = '健康';
      saveState(s);
      toast('状态已回满');
    });
    area.querySelector('#cheatGiveItems').addEventListener('click', () => {
      ITEMS.forEach((it) => addItem(s, it.id, 1));
      saveState(s);
      toast(`已发放 ${ITEMS.length} 种物品`);
    });
    area.querySelector('#cheatMetAll').addEventListener('click', () => {
      CHARACTERS.forEach((c) => {
        const r = getRelation(s, c.id);
        r.met = true;
        r.dayMet = s.time.day;
      });
      saveState(s);
      toast('已认识全部角色');
    });
    area.querySelector('#cheatFavAll').addEventListener('click', () => {
      CHARACTERS.forEach((c) => {
        const r = getRelation(s, c.id);
        r.f = 100;
      });
      saveState(s);
      toast('全部好感已满');
    });
    area.querySelector('#cheatSetDay').addEventListener('click', () => {
      const v = parseInt(area.querySelector('#cheatDay').value, 10);
      if (v < 1) return toast('天数至少为1');
      s.time.day = v;
      saveState(s);
      toast(`已将天数设为第${v}天`);
    });
    area.querySelector('#cheatSetHour').addEventListener('click', () => {
      const v = parseInt(area.querySelector('#cheatHour').value, 10);
      if (v < 0 || v > 23) return toast('小时需在0-23之间');
      s.time.hour = v;
      saveState(s);
      toast(`已将时段设为${v}点`);
    });
    area.querySelector('#cheatTeleport').addEventListener('click', () => {
      const pid = area.querySelector('#cheatPlace').value;
      s.location = pid;
      saveState(s);
      toast('已传送');
    });
    area.querySelector('#cheatSetSkill').addEventListener('click', () => {
      const sk = area.querySelector('#cheatSkill').value;
      const v = clamp(parseInt(area.querySelector('#cheatSkillVal').value, 10) || 0, 0, 8);
      p.skills[sk] = v;
      saveState(s);
      toast('技能已设置');
    });
    area.querySelector('#cheatSetRel').addEventListener('click', () => {
      const cid = area.querySelector('#cheatChar').value;
      const r = getRelation(s, cid);
      r.f = clamp(parseInt(area.querySelector('#cheatF').value, 10) || 0, 0, 100);
      r.l = clamp(parseInt(area.querySelector('#cheatL').value, 10) || 0, 0, 100);
      r.h = clamp(parseInt(area.querySelector('#cheatH').value, 10) || 0, 0, 100);
      r.met = true;
      saveState(s);
      toast('关系已设置');
    });
    area.querySelector('#cheatAddItem').addEventListener('click', () => {
      const iid = area.querySelector('#cheatItem').value;
      addItem(s, iid, 1);
      saveState(s);
      const it = ITEMS.find((x) => x.id === iid);
      toast(`已添加 ${it ? it.name : iid} ×1`);
    });
    const list = area.querySelector('#cheatCharList');
    if (list) {
      list.querySelectorAll('.cheat-char-item').forEach((el) => {
        el.addEventListener('click', (e) => {
          if (e.target.tagName === 'INPUT') return;
          const check = el.querySelector('input');
          if (check.disabled) return;
          check.checked = !check.checked;
        });
      });
      area.querySelector('#cheatMetClear').addEventListener('click', () => {
        list.querySelectorAll('.cheat-char-check:not(:disabled)').forEach((ch) => { ch.checked = false; });
        toast('已清空选择');
      });
      area.querySelector('#cheatMetSel').addEventListener('click', () => {
        const selected = [...list.querySelectorAll('.cheat-char-check:checked')].map((ch) => ch.dataset.id);
        if (!selected.length) return toast('请先勾选角色');
        selected.forEach((cid) => {
          const r = getRelation(s, cid);
          r.met = true;
          r.dayMet = s.time.day;
        });
        saveState(s);
        toast(`已认识 ${selected.length} 位角色`);
        render();
      });
    }
  }
}

function attrShort(k) {
  return { con: '体质', int: '智力', per: '感知', cha: '魅力', luk: '运气' }[k];
}

// 角色创建：创造新 NPC
function openCharCreate(s, after) {
  const body = document.createElement('div');
  body.className = 'modal-body';
  body.innerHTML = `
    <div style="font-size:14px;font-weight:600;color:var(--accent-deep);margin-bottom:12px;">创造新 NPC</div>
    <div class="create-cform">
      <div class="form-row"><label>姓名</label><input type="text" id="ccName" maxlength="6" placeholder="如：陆晚舟"></div>
      <div class="form-row"><label>年龄</label><input type="number" id="ccAge" value="16" min="10" max="99"></div>
      <div class="form-row"><label>性别</label><div class="opt-list" id="ccGender">${['男', '女', '双性偏男', '双性偏女', '无性'].map((g) => `<div class="opt ${g === '女' ? 'selected' : ''}" data-v="${g}">${g}</div>`).join('')}</div></div>
      <div class="form-row"><label>外貌</label><input type="text" id="ccApper" maxlength="60" placeholder="如：黑发，琥珀色眼睛，左眼角有颗小痣"></div>
      <div class="form-row"><label>性格</label><input type="text" id="ccPerson" maxlength="60" placeholder="如：温柔慢热，喜欢安静地看书"></div>
      <div class="form-row"><label>身份</label><input type="text" id="ccId" maxlength="40" placeholder="如：转校生 / 街角书店的店长"></div>
      <div class="form-row"><label>初始关系</label><select id="ccRel" class="cc-select">
        <option value="0">陌生</option><option value="20">初识</option><option value="40">朋友</option>
        <option value="60">挚友</option><option value="30">暧昧</option><option value="20">敌对</option>
      </select></div>
      <div class="form-row"><label>出场时间</label><select id="ccStage" class="cc-select">
        <option value="立即">立即</option><option value="前期">前期</option>
        <option value="中期">中期</option><option value="后期">后期</option>
      </select></div>
    </div>`;
  const { card } = openModal(body, {});
  card.style.maxWidth = '520px';
  card.querySelector('.modal-header')?.remove();
  body.querySelectorAll('#ccGender .opt').forEach((el) => {
    el.addEventListener('click', () => {
      body.querySelectorAll('#ccGender .opt').forEach((o) => o.classList.remove('selected'));
      el.classList.add('selected');
    });
  });
  const footer = document.createElement('div');
  footer.className = 'modal-footer';
  const cancel = document.createElement('button');
  cancel.className = 'btn btn-sm';
  cancel.textContent = '取消';
  cancel.addEventListener('click', closeModal);
  const ok = document.createElement('button');
  ok.className = 'btn btn-primary btn-sm';
  ok.textContent = '创造';
  ok.addEventListener('click', () => {
    const name = body.querySelector('#ccName').value.trim();
    if (!name) return toast('请填写姓名');
    const id = 'cc_' + name + '_' + Date.now().toString(36).slice(-4);
    const relVal = parseInt(body.querySelector('#ccRel').value, 10);
    const char = {
      id,
      name,
      gender: body.querySelector('#ccGender .selected')?.dataset.v || '女',
      age: parseInt(body.querySelector('#ccAge').value, 10) || 16,
      identity: body.querySelector('#ccId').value.trim() || '新来的居民',
      type: 'custom',
      location: 'community',
      appearance: body.querySelector('#ccApper').value.trim() || '还未详细描述，模样清秀。',
      personality: body.querySelector('#ccPerson').value.trim() || '温和友善，容易相处。',
      meet: {
        way: `${body.querySelector('#ccStage').value}出场，你与${name}相识。`,
        firstProb: 100,
        laterProb: 80,
        req: '自创角色，按要求出场',
        special: '由玩家创造的自定义角色。',
      },
      createdStage: body.querySelector('#ccStage').value,
    };
    addCreatedChar(s, char);
    const stage = body.querySelector('#ccStage').value;
    if (stage === '立即') {
      const r = getRelation(s, id);
      r.met = true;
      r.dayMet = s.time.day;
      r.f = relVal;
      if (relVal >= 30) r.l = relVal >= 60 ? 40 : relVal >= 40 ? 25 : 15;
    }
    saveState(s);
    closeModal();
    toast(`已创造角色「${name}」`);
    after && after();
  });
  footer.appendChild(cancel);
  footer.appendChild(ok);
  card.appendChild(footer);
}

// ============ 设置面板 ============
export function openSettingsPanel(s, onChanged = () => {}) {
  const { content } = panelShell('设置', '<div class="panel-inner" id="settingsBody"></div>');
  const body = content.querySelector('#settingsBody');
  const area = document.createElement('div');
  body.appendChild(area);
  render();

  function render() {
    const api = getAPIConfig();
    area.innerHTML = `
      <div class="panel-sec">背景</div>
      <div class="opt-list" id="bgOpts">
        ${BG_PALETTE.map(([key, name, hex]) => `
          <div class="bg-card ${s.settings.bg === key ? 'selected' : ''}" data-bg="${key}" title="${name}" style="--swatch:${hex};">
            <span class="bg-swatch"></span>
            <span class="bg-name">${name}</span>
          </div>`).join('')}
      </div>
      <div class="panel-sec">字体大小</div>
      <div style="display:flex;align-items:center;gap:12px;">
        <input type="range" id="fontSize" min="14" max="20" step="1" value="${s.settings.fontSize || 16}" style="flex:1;">
        <span style="font-size:13px;min-width:50px;">${s.settings.fontSize || 16}px</span>
      </div>
      <div class="panel-sec">剧情回溯</div>
      <div class="cheat-switch-row">
        <span>开启回溯（对话时显示重播按钮）</span>
        <label class="switch"><input type="checkbox" id="rewindOn" ${s.settings.rewind ? 'checked' : ''}><span class="slider"></span></label>
      </div>
      <div class="panel-sec">AI 配置</div>
      <div class="ai-row">
        <label>API 地址</label>
        <input type="text" id="apiUrl" value="${api.url}" placeholder="https://api.openai.com/v1">
      </div>
      <div class="ai-row">
        <label>API Key</label>
        <input type="password" id="apiKey" value="${api.key}" placeholder="sk-...">
      </div>
      <div class="ai-row">
        <label>模型</label>
        <div style="flex:1;">
          <div style="display:flex;gap:8px;">
            <input type="text" id="apiModel" value="${api.model}" placeholder="点击「拉取」从列表选择，也可直接输入" style="flex:1;">
            <button class="btn btn-sm" id="fetchModels">拉取</button>
          </div>
          <div class="model-list" id="modelList" style="display:none;"></div>
        </div>
      </div>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-sm btn-primary" id="apiTest">测试连接</button>
        <button class="btn btn-sm" id="apiSave">保存</button>
        <span id="apiStatus" style="font-size:12px;align-self:center;color:var(--text-secondary);">${isAIReady() ? '已连接' : '未配置'}</span>
      </div>
      <div class="panel-sec">作者</div>
      <div class="author-box">
        <div class="author-line">《此间少年行》v3.0</div>
        <div class="author-line">作者：清姈</div>
        <div class="author-long">这是一个关于「长大」的故事。你十四岁来到云栖市，在许临安家拥有了一个属于自己的房间。从这里开始，你会认识很多人，经历很多事——有人走进你的生活，也有人从你身边离开。愿你在这座城市里，找到属于自己的那束光。</div>
        <div class="author-long" style="color:var(--text-secondary);">希望这个游戏能给大家带来一段温暖的时光，让你在游戏里找到自己的快乐，在生活中拥抱真正的幸福。</div>
        <div class="author-thanks">感谢小谭的助力，感谢格子的助力，感谢清柠的助力，感谢 monkey code 的助力，也感谢一直陪伴着我的大家们。</div>
      </div>
      <div class="panel-sec">关于</div>
      <div class="opt-list">
        <button class="btn btn-sm" id="aboutGame">游戏介绍</button>
        <button class="btn btn-sm btn-danger" id="hardReset">重置游戏</button>
      </div>`;

    area.querySelectorAll('#bgOpts .bg-card').forEach((el) => {
      el.addEventListener('click', () => {
        area.querySelectorAll('#bgOpts .bg-card').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        s.settings.bg = el.dataset.bg;
        applyBg(s);
        saveState(s);
        onChanged();
      });
    });
    area.querySelector('#fontSize').addEventListener('input', (e) => {
      const v = e.target.value;
      area.querySelector('span').textContent = v + 'px';
      s.settings.fontSize = parseInt(v, 10);
      document.documentElement.style.setProperty('--font-size', v + 'px');
      saveState(s);
    });
    area.querySelector('#rewindOn').addEventListener('change', (e) => {
      s.settings.rewind = e.target.checked;
      saveState(s);
    });
    area.querySelector('#apiTest').addEventListener('click', async () => {
      const status = area.querySelector('#apiStatus');
      status.textContent = '测试中…';
      const cfg = {
        url: area.querySelector('#apiUrl').value.trim(),
        key: area.querySelector('#apiKey').value.trim(),
        model: area.querySelector('#apiModel').value.trim(),
        connected: false,
      };
      setAPIConfig(cfg);
      const res = await testConnection();
      if (res.ok) {
        cfg.connected = true;
        s.settings.api = cfg;
        saveState(s);
        setAPIConfig(cfg);
        status.textContent = '✓ 连接成功';
        status.style.color = 'var(--good)';
      } else {
        status.textContent = '✗ ' + res.msg;
        status.style.color = 'var(--danger)';
      }
    });
    area.querySelector('#fetchModels').addEventListener('click', async () => {
      const cfg = {
        url: area.querySelector('#apiUrl').value.trim(),
        key: area.querySelector('#apiKey').value.trim(),
        model: area.querySelector('#apiModel').value.trim(),
        connected: false,
      };
      setAPIConfig(cfg);
      const btn = area.querySelector('#fetchModels');
      btn.disabled = true;
      btn.textContent = '刷新中…';
      const listEl = area.querySelector('#modelList');
      listEl.innerHTML = '';
      const models = await fetchModels();
      btn.disabled = false;
      btn.textContent = '拉取';
      if (!models.length) { listEl.style.display = 'none'; return toast('无法获取模型列表，请检查 API 地址与 Key'); }
      const current = area.querySelector('#apiModel').value.trim();
      listEl.style.display = 'block';
      models.slice(0, 50).forEach((m) => {
        const item = document.createElement('button');
        item.type = 'button';
        item.className = 'model-item' + (m === current ? ' selected' : '');
        item.textContent = m;
        item.addEventListener('click', () => {
          area.querySelector('#apiModel').value = m;
          listEl.querySelectorAll('.model-item').forEach((x) => x.classList.remove('selected'));
          item.classList.add('selected');
          listEl.style.display = 'none';
          toast(`已选择 ${m}，点击「保存」生效`);
        });
        listEl.appendChild(item);
      });
      toast(`拉取到 ${models.length} 个模型`);
    });
    area.querySelector('#apiSave').addEventListener('click', () => {
      const cfg = {
        url: area.querySelector('#apiUrl').value.trim(),
        key: area.querySelector('#apiKey').value.trim(),
        model: area.querySelector('#apiModel').value.trim(),
        connected: false,
      };
      if (!cfg.url || !cfg.key) return toast('请先填写 API 地址与 Key');
      s.settings.api = cfg;
      setAPIConfig(cfg);
      saveState(s);
      toast('已保存');
    });
    area.querySelector('#aboutGame').addEventListener('click', () => {
      showAbout();
    });
    area.querySelector('#hardReset').addEventListener('click', () => {
      if (confirm('确定要重置所有游戏数据吗？此操作不可恢复。')) {
        Object.keys(localStorage).filter((k) => k.startsWith('cijian_')).forEach((k) => localStorage.removeItem(k));
        location.reload();
      }
    });
  }
}

function applyBg(s) {
  const key = s.settings.bg || 'default';
  const found = BG_PALETTE.find(([k]) => k === key);
  const [top, bottom] = found
    ? [found[2], shadeHex(found[2], -12)]
    : [BG_PALETTE[0][2], shadeHex(BG_PALETTE[0][2], -12)];
  document.documentElement.style.setProperty('--bg-top', top);
  document.documentElement.style.setProperty('--bg-bottom', bottom);
  document.documentElement.style.setProperty('--bg-gradient', `linear-gradient(180deg, ${top} 0%, ${bottom} 100%)`);
}

function shadeHex(hex, pct) {
  const h = hex.replace('#', '');
  const n = parseInt(h, 16);
  let r = (n >> 16) & 255;
  let g = (n >> 8) & 255;
  let b = n & 255;
  r = Math.max(0, Math.min(255, Math.round(r + (pct / 100) * 255)));
  g = Math.max(0, Math.min(255, Math.round(g + (pct / 100) * 255)));
  b = Math.max(0, Math.min(255, Math.round(b + (pct / 100) * 255)));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

function showAbout() {
  const content = document.createElement('div');
  content.className = 'modal-body';
  content.innerHTML = `
    <div style="text-align:center;margin-bottom:16px;">
      <div class="font-kai" style="font-size:24px;letter-spacing:6px;color:var(--accent-deep);">此间少年行</div>
      <div style="font-size:12px;color:var(--text-faint);margin-top:6px;">v3.0 · 清姈工作室</div>
    </div>
    <div style="font-size:14px;line-height:1.9;color:var(--text-secondary);">
      <p>你十四岁，被许临安收养，来到了云栖市。</p>
      <p>这是一座温和的沿海城市，有教堂的钟声、街角的面包店，也有藏在巷子深处的灰色地带。</p>
      <p>事业、恋爱、亲情、友情——四段人生，由你书写。</p>
    </div>
  `;
  const { card } = openModal(content, {});
  card.style.maxWidth = '460px';
  card.querySelector('.modal-header')?.remove();
}

// ============ 地点详情面板（商店/打工/行动） ============
const JOB_PLACE_TOKEN = {
  mall: '购物中心', convenience: '全天便利', stationery: '纸墨时光',
  flower: '朝露花坊', bakery: '麦香晨光', coffee: '街角咖啡',
  bookstore: '纸上云栖', supermarket: '大润发', foodstreet: '云栖食集',
  library: '市立图书馆', museum: '云栖历史博物馆', centralpark: '中央公园',
  school: '第一中学', factory: '云栖精密制造', techpark: '云栖科技谷',
  hospital: '云栖市第一人民医院', theater: '大剧院', stadium: '云栖体育中心',
  church: '圣心大教堂', yeyouchuan: '夜航船', port: '云栖港',
};

function jobsForPlace(placeId) {
  const token = JOB_PLACE_TOKEN[placeId];
  if (!token) return [];
  return JOBS.filter((j) => j.place && j.place.includes(token) && !j.special);
}

function kebabSkill(k) {
  return k.replace(/[A-Z]/g, (c) => '-' + c.toLowerCase());
}

function jobReqValue(s, key) {
  const p = s.player;
  if (key === 'age') return p.age;
  if (key === 'cha') return p.attributes.cha;
  if (key === 'int') return p.attributes.int;
  if (key === 'per' || key === 'perception') return p.attributes.per;
  if (key === 'luk') return p.attributes.luk;
  if (key === 'con') return p.attributes.con;
  if (key === 'phy') return p.attributes.con;
  if (key === 'sta') return p.stats.sta;
  if (key === 'faith') return p.faith || 0;
  return p.skills[kebabSkill(key)] || 0;
}

function jobReqLabel(key) {
  const map = {
    age: '年龄', con: '体质', int: '智力', per: '感知', perception: '感知',
    cha: '魅力', luk: '运气', phy: '体质', sta: '体力', faith: '信仰',
    friendliness: '亲和力', persuasion: '说服力', science: '理科素养',
    cooking: '烹饪', liberalArts: '文科素养', medicine: '医学知识',
    instrument: '乐器', acting: '表演', insight: '洞察力', fight: '格斗',
  };
  return map[key] || key;
}

function jobMet(s, job) {
  if (job.minAge && s.player.age < job.minAge) return `需${job.minAge}岁以上`;
  if (job.maxAge && s.player.age > job.maxAge) return `限${job.maxAge}岁以下`;
  for (const [k, v] of Object.entries(job.req || {})) {
    if (jobReqValue(s, k) < v) return `需${jobReqLabel(k)}≥${v}`;
  }
  return '';
}

function addSkillExp(s, id, n) {
  const p = s.player;
  p.skills[id] = Math.max(0, (p.skills[id] || 0) + n);
}

function doWork(s, job) {
  const p = s.player;
  const c = job.consume || {};
  p.stats.ep = clamp(p.stats.ep - (c.ep || 0), 0, 200);
  p.stats.sta = clamp(p.stats.sta - (c.sta || 0), 0, 200);
  p.stats.cln = clamp(p.stats.cln - (c.clean || 0), 0, 100);
  p.stats.stress = clamp(p.stats.stress + (c.stress || 0), 0, 100);
  Object.entries(job.skillExp || {}).forEach(([k, v]) => addSkillExp(s, kebabSkill(k), v));
  if (job.gray) {
    p.crime = Math.max(0, (p.crime || 0) + (job.crime || 2));
    p.morality = clamp(p.morality - 2, 0, 100);
    s.journal.grayTrades = (s.journal.grayTrades || 0) + 1;
  }
  addMoney(s, job.salary, `${job.name}工资`);
  s.journal.workCount = (s.journal.workCount || 0) + 1;
  s.journal.earned = (s.journal.earned || 0) + job.salary;
  if (!s.journal.workTypes.includes(job.id)) s.journal.workTypes.push(job.id);
  s.narrative.history.push({ type: 'system', text: `你完成了「${job.name}」的工作，收入 ¥${job.salary}。` });
  advanceTime(s, 60);
  saveState(s);
}

const LOCATION_ACTIONS = {
  '睡觉': (s) => {
    const t = s.time;
    const cur = t.hour * 60 + t.minute;
    let target = 7 * 60;
    if (cur >= target) target += 24 * 60;
    advanceTime(s, target - cur);
    s.player.stats.ep = 200;
    s.player.stats.sta = 200;
    s.player.stats.hp = Math.min(200, s.player.stats.hp + 30);
    s.player.stats.stress = clamp(s.player.stats.stress - 25, 0, 100);
    s.player.mood = clamp(s.player.mood + 5, 0, 100);
    s.player.health = '健康';
    s.narrative.history.push({ type: 'system', text: '你美美地睡了一觉，醒来神清气爽。' });
    saveState(s);
    toast('睡了一觉，状态完全恢复');
  },
  '吃饭': (s) => {
    const food = s.inventory.find((i) => {
      const d = ITEMS.find((x) => x.id === i.id);
      return d && (d.cat === 'food' || d.cat === 'drink');
    });
    if (food) {
      const d = ITEMS.find((x) => x.id === food.id);
      removeItem(s, food.id, 1);
      if (d.effect) {
        if (d.effect.sat) s.player.stats.sat = clamp(s.player.stats.sat + d.effect.sat, 0, 100);
        if (d.effect.mood) s.player.mood = clamp(s.player.mood + d.effect.mood, 0, 100);
        if (d.effect.ep) s.player.stats.ep = clamp(s.player.stats.ep + d.effect.ep, 0, 200);
      }
      saveState(s);
      toast(`吃了${d.name}，饱腹+${d.effect.sat || 0}`);
    } else {
      s.player.stats.sat = clamp(s.player.stats.sat + 30, 0, 100);
      s.player.stats.ep = clamp(s.player.stats.ep + 10, 0, 200);
      s.player.mood = clamp(s.player.mood + 2, 0, 100);
      saveState(s);
      toast('吃了点家里的便饭，饱腹+30');
    }
  },
  '洗漱': (s) => {
    s.player.stats.cln = clamp(s.player.stats.cln + 30, 0, 100);
    saveState(s);
    toast('洗漱完毕，清洁度+30');
  },
  '休息': (s) => {
    s.player.stats.ep = clamp(s.player.stats.ep + 20, 0, 200);
    s.player.mood = clamp(s.player.mood + 2, 0, 100);
    advanceTime(s, 30);
    saveState(s);
    toast('休息了30分钟，精力+20');
  },
  '自习': (s) => {
    addSkillExp(s, 'liberal-arts', 3);
    addSkillExp(s, 'science', 3);
    s.player.stats.ep = clamp(s.player.stats.ep - 10, 0, 200);
    s.player.stats.stress = clamp(s.player.stats.stress + 1, 0, 100);
    advanceTime(s, 60);
    saveState(s);
    toast('自习1小时，文理素养经验+3');
  },
  '上课': (s) => {
    addSkillExp(s, 'liberal-arts', 3);
    addSkillExp(s, 'science', 3);
    s.player.stats.ep = clamp(s.player.stats.ep - 12, 0, 200);
    advanceTime(s, 45);
    saveState(s);
    toast('认真听了一节课，经验+3');
  },
  '图书馆学习': (s) => {
    addSkillExp(s, 'liberal-arts', 4);
    addSkillExp(s, 'science', 2);
    s.player.stats.ep = clamp(s.player.stats.ep - 8, 0, 200);
    advanceTime(s, 60);
    saveState(s);
    toast('在图书馆学习1小时');
  },
  '食堂用餐': (s) => {
    s.player.stats.sat = clamp(s.player.stats.sat + 45, 0, 100);
    s.player.stats.ep = clamp(s.player.stats.ep + 10, 0, 200);
    advanceTime(s, 30);
    saveState(s);
    toast('在食堂饱餐一顿，饱腹+45');
  },
  '操场活动': (s) => {
    addSkillExp(s, 'fight', 1);
    s.player.stats.sta = clamp(s.player.stats.sta + 15, 0, 200);
    s.player.stats.ep = clamp(s.player.stats.ep - 10, 0, 200);
    s.player.mood = clamp(s.player.mood + 3, 0, 100);
    advanceTime(s, 60);
    saveState(s);
    toast('在操场活动了一阵，心情+3');
  },
  '天台': (s) => {
    s.player.mood = clamp(s.player.mood + 8, 0, 100);
    s.player.stats.stress = clamp(s.player.stats.stress - 5, 0, 100);
    advanceTime(s, 20);
    saveState(s);
    toast('在天台吹了会儿风，心情+8');
  },
  '阅读': (s) => {
    addSkillExp(s, 'liberal-arts', 3);
    s.player.mood = clamp(s.player.mood + 2, 0, 100);
    advanceTime(s, 45);
    saveState(s);
    toast('静心阅读了一小时');
  },
  '借书': (s) => {
    const books = ITEMS.filter((i) => i.cat === 'book');
    const b = books[Math.floor(Math.random() * books.length)];
    addItem(s, b.id, 1);
    saveState(s);
    toast(`借到了《${b.name}》`);
  },
  '礼拜': (s) => {
    s.player.faith = clamp((s.player.faith || 0) + 2, 0, 100);
    s.player.mood = clamp(s.player.mood + 3, 0, 100);
    advanceTime(s, 40);
    saveState(s);
    toast('参加礼拜，信仰+2，心情+3');
  },
  '晨省': (s) => {
    s.player.faith = clamp((s.player.faith || 0) + 1, 0, 100);
    s.player.mood = clamp(s.player.mood + 2, 0, 100);
    advanceTime(s, 30);
    saveState(s);
    toast('静默晨省，心灵澄澈');
  },
  '静默沉思': (s) => {
    s.player.faith = clamp((s.player.faith || 0) + 1, 0, 100);
    s.player.stats.stress = clamp(s.player.stats.stress - 8, 0, 100);
    advanceTime(s, 30);
    saveState(s);
    toast('静默沉思，压力-8');
  },
  '社团': (s) => {
    addSkillExp(s, 'friendliness', 3);
    s.player.mood = clamp(s.player.mood + 3, 0, 100);
    advanceTime(s, 60);
    saveState(s);
    toast('参加了社团活动');
  },
  '栖湖散步': (s) => {
    s.player.mood = clamp(s.player.mood + 6, 0, 100);
    s.player.stats.stress = clamp(s.player.stats.stress - 4, 0, 100);
    advanceTime(s, 40);
    saveState(s);
    toast('沿着栖湖散步，心情+6');
  },
};

export function openLocationPanel(s, placeId) {
  const pl = PLACES.find((x) => x.id === placeId) || PLACES.find((x) => x.id === s.location);
  if (!pl) return;
  const { content } = panelShell('地点详情', '<div class="panel-inner" id="locBody"></div>', { width: 'min(92vw, 500px)' });
  const body = content.querySelector('#locBody');
  const area = document.createElement('div');
  body.appendChild(area);
  render();

  function render() {
    const p = s.player;
    const shopIds = pl.shop ? [pl.shop] : (pl.shops || []);
    const jobs = jobsForPlace(pl.id);
    area.innerHTML = `
      <div class="loc-head">
        <div class="loc-name">${pl.name}</div>
        <div class="loc-zone">${pl.zone}</div>
        <div class="loc-desc">${pl.desc}</div>
      </div>
      ${(pl.actions || []).length ? `
        <div class="panel-sec">在此可做的事</div>
        <div class="loc-actions">
          ${pl.actions.map((a) => `<button class="btn btn-sm loc-act" data-a="${a}">${a}</button>`).join('')}
        </div>` : ''}
      ${shopIds.length ? `
        <div class="panel-sec">逛商店（余额 ¥${p.money}）</div>
        ${shopIds.map((sid) => {
          const sh = SHOPS.find((x) => x.id === sid);
          const items = ITEMS.filter((i) => i.shop === sid);
          return `
          <div class="shop-block">
            <div class="shop-title">${sh ? sh.name : sid}</div>
            ${items.map((it) => `
              <div class="shop-item">
                <div class="shop-info">
                  <div class="shop-name2">${it.name}</div>
                  <div class="shop-desc">${it.desc}</div>
                </div>
                <div class="shop-price">¥${it.price}</div>
                <button class="btn btn-sm btn-primary shop-buy" data-id="${it.id}" data-price="${it.price}">购买</button>
              </div>`).join('')}
          </div>`;
        }).join('')}` : ''}
      ${jobs.length ? `
        <div class="panel-sec">打工</div>
        ${jobs.map((j) => {
          const miss = jobMet(s, j);
          return `
          <div class="job-item">
            <div class="job-info">
              <div class="job-name2">${j.name} <span class="tag">时薪 ¥${j.salary}</span></div>
              <div class="job-desc">${j.bonus || ''}${j.gray ? '（灰色地带）' : ''}</div>
              ${miss ? `<div class="job-lock">条件未满足：${miss}</div>` : ''}
            </div>
            ${miss ? '' : `<button class="btn btn-sm btn-primary job-work" data-id="${j.id}">工作1小时</button>`}
          </div>`;
        }).join('')}` : ''}
      <div class="panel-tip">在这里探索，会发现商店、工作与更多可能。</div>`;

    area.querySelectorAll('.loc-act').forEach((el) => {
      el.addEventListener('click', () => {
        const fn = LOCATION_ACTIONS[el.dataset.a];
        if (!fn) return toast(`「${el.dataset.a}」暂未开放`);
        fn(s);
        render();
      });
    });
    area.querySelectorAll('.shop-buy').forEach((el) => {
      el.addEventListener('click', () => {
        const price = parseInt(el.dataset.price, 10);
        if (s.player.money < price) return toast('余额不足');
        addMoney(s, -price, '购物');
        addItem(s, el.dataset.id, 1);
        saveState(s);
        toast('购买成功，已放入背包');
        render();
      });
    });
    area.querySelectorAll('.job-work').forEach((el) => {
      el.addEventListener('click', () => {
        const job = jobs.find((x) => x.id === el.dataset.id);
        if (!job) return;
        const miss = jobMet(s, job);
        if (miss) return toast(miss);
        doWork(s, job);
        toast(`完成1小时工作，收入 ¥${job.salary}`);
        render();
      });
    });
  }
}

// ============ 地图面板（外出） ============
export function openMapPanel(s) {
  const { content } = panelShell('外出', '<div class="panel-inner" id="mapBody"></div>');
  const body = content.querySelector('#mapBody');
  const area = document.createElement('div');
  body.appendChild(area);
  render();

  function render() {
    const visited = new Set(s.journal.visitedPlaces || []);
    const current = s.location;
    area.innerHTML = `
      <div class="map-current">
        <span class="tag">当前位置</span>
        <span style="font-size:15px;font-weight:600;margin-left:8px;flex:1;">${placeName(current)}</span>
        <button class="btn btn-sm btn-primary map-view" id="mapViewHere">查看此地</button>
      </div>
      <div class="panel-sec">选择目的地</div>
      ${PLACES.map((pl) => {
        const isCur = pl.id === current;
        const isVisited = visited.has(pl.id);
        return `
        <div class="map-row">
          <div class="map-zone">${pl.zone}</div>
          <div class="map-main">
            <div class="map-name">${pl.name} ${isCur ? '<span class="tag">当前</span>' : ''}</div>
            <div class="map-desc">${pl.desc}</div>
            <div class="map-cost">${pl.exploreCost && pl.exploreCost.time ? `耗时 ${pl.exploreCost.time} 分钟 · 精力 -${pl.exploreCost.ep || 0}` : ''}</div>
          </div>
          ${isCur ? '' : `<button class="btn btn-sm btn-primary map-go" data-id="${pl.id}">前往</button>`}
        </div>`;
      }).join('')}`;
    area.querySelector('#mapViewHere').addEventListener('click', () => {
      openLocationPanel(s, current);
    });
    area.querySelectorAll('.map-go').forEach((btn) => {
      btn.addEventListener('click', () => goTo(btn.dataset.id));
    });
  }

  function goTo(id) {
    const pl = PLACES.find((x) => x.id === id);
    if (!pl) return;
    const cost = pl.exploreCost || { ep: 5, time: 15 };
    if (s.player.stats.ep < (cost.ep || 5)) return toast('精力不足，先休息一下吧');
    s.location = id;
    s.player.stats.ep = clamp(s.player.stats.ep - (cost.ep || 5), 0, 200);
    import('../core/time.js').then(({ advanceTime }) => {
      advanceTime(s, (cost.time || 15));
      if (!s.journal.visitedPlaces.includes(id)) s.journal.visitedPlaces.push(id);
      if (id === 'convenience' && s.time.hour >= 22) s.journal.convenienceNight = true;
      if (!s.journal.exploredStreets.includes(pl.street)) s.journal.exploredStreets.push(pl.street);
      saveState(s);
      toast(`已到达「${pl.name}」`);
      render();
      openLocationPanel(s, id);
    });
  }
}

function placeName(id) {
  const pl = PLACES.find((x) => x.id === id);
  return pl ? pl.name : id;
}

function panelStyle() {
  return `
    .panel-body { display: flex; flex-direction: column; overflow: hidden; }
    .panel-head {
      display: flex; align-items: center; justify-content: space-between;
      padding: 16px 20px; border-bottom: 1px solid rgba(127,168,201,0.2);
    }
    .panel-title { font-size: 20px; letter-spacing: 4px; color: var(--accent-deep); }
    .panel-x {
      width: 30px; height: 30px; border-radius: 50%; border: none; flex-shrink: 0;
      background: rgba(0,0,0,0.05); color: var(--text-secondary); font-size: 16px; line-height: 1;
      cursor: pointer; display: flex; align-items: center; justify-content: center;
    }
    .panel-x:hover { background: rgba(0,0,0,0.12); color: var(--text-primary); }
    .panel-content { flex: 1; overflow-y: auto; overflow-x: hidden; min-height: 0; padding: 16px 20px; }
    .panel-inner { display: flex; flex-direction: column; min-height: 100%; }
    .panel-tabs { display: flex; gap: 0; border-bottom: 1px solid rgba(127,168,201,0.16); margin-bottom: 14px; }
    .panel-tab {
      flex: 1; padding: 9px 0 11px; font-size: 13px; text-align: center;
      color: var(--text-secondary); cursor: pointer; transition: var(--transition);
    }
    .panel-tab.active { color: var(--accent-deep); font-weight: 600; }
    .panel-tab:hover { color: var(--accent-deep); }
    .panel-tab:active { filter: brightness(0.8); }
    .panel-sec { font-size: 14px; font-weight: 600; color: var(--text-primary); margin: 18px 0 10px; letter-spacing: 1px; }
    .panel-sec:first-child { margin-top: 0; }
    .panel-tip { font-size: 12px; color: var(--text-faint); margin-top: 16px; line-height: 1.6; }

    .attr-hero { text-align: center; padding: 12px 0 18px; border-bottom: 1px solid rgba(127,168,201,0.2); margin-bottom: 14px; }
    .attr-hero-name { font-size: 20px; font-weight: 600; color: var(--accent-deep); letter-spacing: 3px; }
    .attr-hero-total { font-size: 14px; margin: 6px 0 2px; }
    .attr-hero-sub { font-size: 12px; color: var(--text-secondary); }
    .attr-item { margin-bottom: 12px; }
    .attr-line { display: flex; align-items: center; gap: 8px; margin-bottom: 5px; }
    .attr-name { font-size: 13px; font-weight: 600; min-width: 40px; }
    .attr-desc { font-size: 11px; color: var(--text-faint); flex: 1; }
    .attr-val { font-size: 13px; font-weight: 700; color: var(--accent-deep); min-width: 20px; text-align: right; }

    .stat-extra { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 14px; }
    .stat-extra-cell { background: rgba(255,255,255,0.5); border-radius: 12px; padding: 8px 12px; display: flex; justify-content: space-between; font-size: 12px; color: var(--text-secondary); }
    .stat-extra-cell b { color: var(--accent-deep); }

    .talent-item { background: rgba(127,168,201,0.08); border: 1px solid rgba(127,168,201,0.2); border-radius: 12px; padding: 10px 14px; margin-bottom: 8px; }
    .talent-item-name { font-size: 14px; font-weight: 600; color: var(--accent-deep); }
    .talent-item-desc { font-size: 12px; color: var(--text-secondary); margin-top: 3px; }
    .skill-cat { margin-bottom: 12px; }
    .skill-cat-name { font-size: 13px; font-weight: 600; color: var(--text-secondary); margin-bottom: 6px; cursor: pointer; user-select: none; display: flex; align-items: center; gap: 6px; }
    .skill-cat-count { font-size: 11px; color: var(--text-faint); font-weight: 400; }
    .skill-cat-arrow { font-size: 10px; color: var(--accent-deep); transition: transform 0.2s ease; }
    .skill-cat-collapsed .skill-cat-body { display: none; }
    .skill-cat-collapsed .skill-cat-arrow { transform: rotate(-90deg); }
    .skill-lv { font-size: 11px; color: var(--text-faint); background: rgba(127,168,201,0.12); border-radius: 6px; padding: 1px 6px; }
    .skill-progress { font-size: 11px; color: var(--text-faint); margin-top: 3px; text-align: right; }
    .skill-item { margin-bottom: 8px; }

    .base-card { display: flex; gap: 10px; background: rgba(255,255,255,0.5); border-radius: 14px; padding: 12px 14px; margin-bottom: 12px; border: 1px solid rgba(127,168,201,0.18); }
    .base-card-ico { font-size: 20px; flex-shrink: 0; }
    .base-card-txt { font-size: 13px; line-height: 1.8; color: var(--text-primary); }
    .base-grid { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; margin-bottom: 4px; }
    .base-cell { background: rgba(255,255,255,0.55); border: 1px solid rgba(127,168,201,0.18); border-radius: 14px; padding: 10px 6px; text-align: center; }
    .base-cell-ico { font-size: 20px; }
    .base-cell-name { font-size: 11px; color: var(--text-secondary); margin-top: 3px; }
    .base-cell-val { font-size: 14px; font-weight: 700; color: var(--accent-deep); margin-top: 2px; }

    .base-list { display: flex; flex-direction: column; gap: 8px; margin-bottom: 4px; background: rgba(255,255,255,0.5); border: 1px solid rgba(127,168,201,0.18); border-radius: 14px; padding: 12px 14px; }
    .base-line { display: flex; align-items: center; gap: 8px; }
    .base-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0; }
    .base-line-name { font-size: 12px; color: var(--text-secondary); width: 52px; flex-shrink: 0; }
    .base-line-val { font-size: 12px; min-width: 36px; text-align: right; color: var(--text-secondary); }
    .social-core .core-lv { font-size: 14px; }
    .thought-char-list { display: flex; flex-direction: column; gap: 6px; margin-bottom: 6px; }
    .thought-char { display: flex; align-items: center; gap: 8px; background: rgba(255,255,255,0.5); border: 1px solid rgba(127,168,201,0.18); border-radius: 12px; padding: 6px 10px; }
    .thought-char-ava { width: 30px; height: 30px; border-radius: 50%; background: linear-gradient(135deg, var(--accent-soft), var(--accent)); color: #fff; display: flex; align-items: center; justify-content: center; font-size: 13px; flex-shrink: 0; }
    .thought-char-name { font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 2px; flex: 1; }
    .cheat-ach-list { display: flex; flex-direction: column; gap: 4px; max-height: 44vh; overflow-y: auto; }
    .cheat-ach-item { display: flex; align-items: center; gap: 8px; font-size: 13px; padding: 6px 8px; border-radius: 8px; cursor: pointer; }
    .cheat-ach-item:hover { background: rgba(127,168,201,0.1); }
    .cheat-ach-item.owned { color: var(--text-faint); }
    .create-cform { display: flex; flex-direction: column; gap: 12px; }
    .create-cform .form-row { display: flex; align-items: center; gap: 12px; flex-wrap: wrap; }
    .create-cform .form-row > label { font-size: 13px; color: var(--text-secondary); min-width: 72px; flex-shrink: 0; }
    .create-cform .form-row > input[type="text"] { flex: 1; min-width: 160px; font-size: 13px; padding: 8px 10px; border-radius: 10px; border: 1px solid rgba(127,168,201,0.3); background: rgba(255,255,255,0.7); }
    .create-cform .form-row > input[type="number"] { width: 80px; font-size: 13px; padding: 8px 10px; border-radius: 10px; border: 1px solid rgba(127,168,201,0.3); background: rgba(255,255,255,0.7); }
    .cc-select { flex: 1; min-width: 160px; font-size: 13px; padding: 8px 10px; border-radius: 10px; border: 1px solid rgba(127,168,201,0.3); background: rgba(255,255,255,0.7); }
    .memory-item { background: rgba(255,255,255,0.5); border: 1px solid rgba(127,168,201,0.18); border-radius: 12px; padding: 8px 12px; margin-bottom: 6px; cursor: pointer; transition: var(--transition); }
    .memory-item:hover { background: rgba(255,255,255,0.75); }
    .memory-head { display: flex; align-items: center; justify-content: space-between; }
    .memory-day { font-size: 12px; font-weight: 600; color: var(--accent-deep); }
    .memory-arrow { font-size: 12px; color: var(--text-faint); transition: transform 0.2s ease; }
    .memory-item.open .memory-arrow { transform: rotate(90deg); }
    .memory-text { font-size: 13px; line-height: 1.7; color: var(--text-primary); margin-top: 6px; border-top: 1px dashed rgba(127,168,201,0.3); padding-top: 6px; white-space: pre-wrap; }

    .core-item { background: rgba(255,255,255,0.5); border: 1px solid rgba(127,168,201,0.18); border-radius: 14px; padding: 10px 14px; margin-bottom: 10px; }
    .core-head { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .core-icon { font-size: 16px; }
    .core-name { font-size: 14px; font-weight: 600; flex: 1; }
    .core-lv { font-size: 15px; font-weight: 700; color: var(--accent-deep); }
    .core-lv i { font-style: normal; font-size: 11px; color: var(--text-faint); }
    .core-bar { display: flex; gap: 3px; cursor: pointer; padding: 4px 0; }
    .core-seg { flex: 1; height: 8px; border-radius: 3px; background: rgba(100,120,140,0.15); transition: background 0.2s ease; }
    .core-seg.on { background: linear-gradient(90deg, var(--accent-soft), var(--accent)); }
    .core-detail { margin-top: 8px; padding-top: 8px; border-top: 1px dashed rgba(127,168,201,0.3); animation: fadeIn 0.3s ease; }
    .core-detail-txt { font-size: 12px; line-height: 1.7; color: var(--text-primary); margin-bottom: 6px; }
    .core-detail-row { display: flex; flex-wrap: wrap; align-items: center; gap: 5px; font-size: 11px; color: var(--text-secondary); margin-bottom: 4px; }
    .core-detail-row b { font-size: 11px; color: var(--text-primary); }
    .chip { font-size: 11px; border-radius: 20px; padding: 2px 8px; }
    .chip-ok { background: rgba(127,168,201,0.16); color: #3E6A8C; }
    .chip-warn { background: rgba(214,166,87,0.18); color: #9A7B2E; }

    .social-item { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.5); border-radius: 14px; padding: 10px; margin-bottom: 8px; }
    .social-ava { width: 44px; height: 44px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 18px; flex-shrink: 0; }
    .social-info { flex: 1; min-width: 0; }
    .social-name { font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px; }
    .social-sub { font-size: 11px; color: var(--text-faint); margin: 2px 0 6px; }
    .social-bars { display: flex; flex-direction: column; gap: 3px; }
    .mini-bar { display: flex; align-items: center; gap: 6px; }
    .mini-label { font-size: 10px; color: var(--text-faint); width: 28px; }
    .mini-val { font-size: 11px; min-width: 24px; text-align: right; color: var(--text-secondary); }
    .social-detail { flex-shrink: 0; }
    .sd-head { display: flex; gap: 12px; align-items: center; margin-bottom: 14px; }
    .sd-head-info { flex: 1; min-width: 0; }
    .sd-name { font-size: 17px; font-weight: 600; color: var(--accent-deep); }
    .sd-meta { font-size: 12px; color: var(--text-secondary); margin: 3px 0 6px; }
    .sd-tags { display: flex; flex-wrap: wrap; gap: 5px; }
    .tag { font-size: 11px; background: rgba(127,168,201,0.14); color: #3E6A8C; border-radius: 20px; padding: 2px 9px; }
    .sd-relation { background: rgba(255,255,255,0.55); border: 1px solid rgba(127,168,201,0.18); border-radius: 14px; padding: 12px 14px; margin-bottom: 12px; }
    .sd-rel-label { font-size: 12px; font-weight: 600; color: var(--text-primary); margin-bottom: 8px; }
    .sd-bars { display: flex; flex-direction: column; gap: 5px; }
    .sd-block { margin-bottom: 12px; }
    .sd-block-title { font-size: 12px; font-weight: 600; color: var(--text-primary); margin-bottom: 5px; letter-spacing: 1px; }
    .sd-block-txt { font-size: 13px; line-height: 1.8; color: var(--text-secondary); background: rgba(255,255,255,0.4); border-radius: 12px; padding: 10px 12px; }

    .thought-stats { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin-bottom: 14px; }
    .thought-cell { text-align: center; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 12px; }
    .thought-cell b { font-size: 20px; color: var(--accent-deep); display: block; }
    .thought-cell span { font-size: 12px; color: var(--text-secondary); }
    .thought-text { font-size: 14px; line-height: 1.8; color: var(--text-secondary); }

    .street-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
    .street-cell { background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px; border: 1px solid var(--card-border); }
    .street-cell.done { border-color: var(--sage); background: var(--sage-soft); }
    .street-name { font-size: 13px; font-weight: 600; }
    .street-desc { font-size: 11px; color: var(--text-faint); }
    .place-row { padding: 10px 0; border-bottom: 1px dashed rgba(150,170,190,0.3); }
    .place-row.unvisited { opacity: 0.65; }
    .place-zone { font-size: 11px; color: var(--text-faint); }
    .place-name { font-size: 14px; font-weight: 600; margin: 2px 0; display: flex; align-items: center; gap: 6px; }
    .place-desc { font-size: 12px; color: var(--text-secondary); line-height: 1.6; }

    .record-row { display: flex; gap: 10px; padding: 10px 0; border-bottom: 1px dashed rgba(150,170,190,0.3); }
    .record-row.system { background: rgba(255,255,255,0.4); border-radius: 10px; padding: 8px 12px; }
    .record-day { font-size: 11px; color: var(--text-faint); min-width: 44px; padding-top: 2px; }
    .record-main { flex: 1; }
    .record-title { font-size: 14px; font-weight: 600; color: var(--accent-deep); }
    .record-text { font-size: 12px; color: var(--text-secondary); line-height: 1.6; margin-top: 3px; }

    .task-item { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 6px; }
    .task-item.done { opacity: 0.6; }
    .task-text { flex: 1; font-size: 13px; }

    .world-hero { text-align: center; padding: 12px 0 16px; border-bottom: 1px solid rgba(127,168,201,0.2); margin-bottom: 8px; }
    .world-name { font-size: 26px; letter-spacing: 6px; color: var(--accent-deep); }
    .world-motto { font-size: 12px; color: var(--text-secondary); margin: 6px 0; }
    .world-intro { font-size: 13px; color: var(--text-secondary); line-height: 1.8; }
    .world-layout, .world-text { font-size: 13px; color: var(--text-secondary); line-height: 1.8; }
    .world-school { background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 6px; }
    .school-name { font-size: 14px; font-weight: 600; }
    .school-sub { font-size: 11px; color: var(--text-faint); }
    .school-motto { font-size: 12px; color: var(--accent-deep); margin-top: 4px; }

    .memory-item { background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 6px; }
    .memory-day { font-size: 11px; color: var(--text-faint); }
    .memory-text { font-size: 13px; line-height: 1.7; margin-top: 4px; }

    .ach-progress { display: flex; align-items: center; gap: 10px; margin-bottom: 14px; }
    .ach-progress-text { font-size: 13px; font-weight: 600; color: var(--butter); white-space: nowrap; }
    .ach-progress .bar { flex: 1; }
    .ach-item { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 6px; }
    .ach-item.unlocked { background: linear-gradient(135deg, rgba(217,178,107,0.15), rgba(240,226,196,0.3)); border: 1px solid rgba(217,178,107,0.3); }
    .ach-ico { font-size: 18px; width: 26px; text-align: center; color: var(--text-faint); }
    .ach-item.unlocked .ach-ico { color: var(--butter); }
    .ach-info { flex: 1; }
    .ach-name { font-size: 13px; font-weight: 600; }
    .ach-desc { font-size: 11px; color: var(--text-faint); margin-top: 2px; }
    .ach-prog { font-size: 12px; color: var(--butter); }

    .bag-meta { display: flex; justify-content: space-between; font-size: 13px; color: var(--text-secondary); margin-bottom: 10px; }
    .bag-meta b { color: var(--accent-deep); }
    .mod-meta { display: flex; justify-content: space-between; align-items: center; font-size: 13px; color: var(--text-secondary); margin-bottom: 10px; }
    .mod-meta b { color: var(--accent-deep); }
    .mod-item { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.55); border-radius: 14px; padding: 12px; margin-bottom: 8px; }
    .mod-ico { width: 42px; height: 42px; border-radius: 12px; background: linear-gradient(135deg, var(--accent-soft), var(--accent)); display: flex; align-items: center; justify-content: center; font-size: 20px; flex-shrink: 0; }
    .mod-info { flex: 1; min-width: 0; }
    .mod-name { font-size: 14px; font-weight: 600; color: var(--text-primary); }
    .mod-desc { font-size: 11px; color: var(--text-faint); margin-top: 3px; }
    .mod-tags { display: flex; gap: 4px; margin-top: 6px; flex-wrap: wrap; }
    .bag-grid { display: grid; grid-template-columns: repeat(5, 1fr); gap: 8px; }
    .bag-cell { aspect-ratio: 1; border-radius: 12px; background: rgba(255,255,255,0.5); border: 1px solid var(--card-border); display: flex; align-items: center; justify-content: center; font-size: 22px; position: relative; cursor: pointer; }
    .bag-cell.empty { opacity: 0.35; }
    .bag-cell-story { border: 2px solid var(--warn); box-shadow: inset 0 0 0 1px rgba(214,166,87,0.35); }
    .bag-qty { position: absolute; right: 4px; bottom: 2px; font-size: 10px; color: var(--text-secondary); background: rgba(255,255,255,0.8); padding: 1px 4px; border-radius: 6px; }
    .gift-char-list { display: flex; flex-direction: column; gap: 6px; max-height: 50vh; overflow-y: auto; }
    .gift-char { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.5); border: 1px solid var(--card-border); border-radius: 12px; padding: 8px 12px; font-size: 13px; cursor: pointer; transition: var(--transition); }
    .gift-char:hover { background: rgba(127,168,201,0.1); border-color: var(--accent); }
    .gift-char span:nth-child(2) { flex: 1; text-align: left; font-weight: 600; }

    .save-meta { display: flex; align-items: center; gap: 10px; margin-bottom: 12px; font-size: 13px; color: var(--text-secondary); }
    .save-pages { display: flex; gap: 6px; flex: 1; }
    .page-dot { width: 12px; height: 12px; border-radius: 50%; border: none; background: rgba(150,170,190,0.3); cursor: pointer; }
    .page-dot.active { background: var(--accent); }
    .slot-item { display: flex; align-items: center; gap: 12px; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 8px; }
    .slot-item.empty { opacity: 0.7; }
    .slot-num { font-size: 15px; font-weight: 700; color: var(--accent-deep); min-width: 30px; }
    .slot-main { flex: 1; min-width: 0; }
    .slot-title { font-size: 13px; font-weight: 600; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .slot-sub { font-size: 11px; color: var(--text-faint); margin-top: 2px; }
    .slot-empty { font-size: 13px; color: var(--text-faint); }

    .cheat-switch-row { display: flex; align-items: center; justify-content: space-between; padding: 10px 0; font-size: 14px; }
    .cheat-grid { display: flex; flex-direction: column; gap: 8px; }
    .cheat-row { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; }
    .cheat-char-list { display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 8px; max-height: 220px; overflow-y: auto; padding: 2px; }
    .cheat-char-item { display: flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.5); border: 1px solid rgba(127,168,201,0.2); border-radius: 12px; padding: 8px 8px; cursor: pointer; font-size: 12px; }
    .cheat-char-item.met { opacity: 0.55; }
    .cheat-char-check { accent-color: var(--accent); width: 14px; height: 14px; }
    .cheat-char-ava { width: 26px; height: 26px; border-radius: 50%; color: #fff; display: flex; align-items: center; justify-content: center; font-size: 12px; flex-shrink: 0; }
    .cheat-char-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .cheat-char-badge { font-size: 9px; color: var(--text-faint); flex-shrink: 0; }
    .cheat-row > span { font-size: 13px; min-width: 48px; }
    .cheat-input { width: 80px; }

    .switch { position: relative; display: inline-block; width: 46px; height: 26px; }
    .switch input { opacity: 0; width: 0; height: 0; }
    .slider {
      position: absolute; cursor: pointer; inset: 0;
      background: rgba(150,170,190,0.4); border-radius: 26px; transition: var(--transition);
    }
    .slider::before {
      content: ""; position: absolute; width: 20px; height: 20px; left: 3px; top: 3px;
      background: #fff; border-radius: 50%; transition: var(--transition); box-shadow: 0 2px 4px rgba(0,0,0,0.2);
    }
    .switch input:checked + .slider { background: var(--accent); }
    .switch input:checked + .slider::before { transform: translateX(20px); }

    .ai-row { margin-bottom: 10px; }
    .ai-row label { display: block; font-size: 12px; color: var(--text-secondary); margin-bottom: 4px; }
    .ai-row input { width: 100%; }
    .model-list {
      margin-top: 8px; max-height: 220px; overflow-y: auto;
      border: 1px solid var(--card-border); border-radius: 12px;
      background: rgba(255,255,255,0.72);
      padding: 6px; display: flex; flex-direction: column; gap: 4px;
    }
    .model-item {
      text-align: left; padding: 8px 12px; border-radius: 8px;
      font-size: 12px; color: var(--text-primary); background: transparent; border: none; cursor: pointer;
      word-break: break-all; white-space: normal;
    }
    .model-item:hover { background: rgba(127,168,201,0.12); color: var(--accent-deep); }
    .model-item.selected { background: linear-gradient(135deg, var(--accent-soft), var(--accent)); color: #fff; }

    .author-box { text-align: center; padding: 12px; background: rgba(255,255,255,0.5); border-radius: 12px; }
    .author-line { font-size: 13px; margin: 3px 0; color: var(--text-secondary); }
    .author-long { font-size: 12px; line-height: 1.8; color: var(--text-primary); margin-top: 8px; text-align: left; }
    .author-thanks { font-size: 12px; line-height: 1.8; color: var(--text-faint); margin-top: 8px; text-align: left; }

    .map-current { display: flex; align-items: center; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; }
    .map-row { display: flex; gap: 10px; align-items: flex-start; padding: 10px 0; border-bottom: 1px dashed rgba(150,170,190,0.3); }
    .map-zone { font-size: 11px; color: var(--text-faint); min-width: 52px; padding-top: 2px; }
    .map-main { flex: 1; }
    .map-name { font-size: 14px; font-weight: 600; display: flex; align-items: center; gap: 6px; }
    .map-desc { font-size: 12px; color: var(--text-secondary); line-height: 1.6; margin-top: 2px; }
    .map-cost { font-size: 11px; color: var(--text-faint); margin-top: 2px; }
    .map-go { flex-shrink: 0; }

    .loc-head { background: rgba(255,255,255,0.5); border-radius: 12px; padding: 12px; margin-bottom: 6px; }
    .loc-name { font-size: 16px; font-weight: 600; color: var(--accent-deep); }
    .loc-zone { font-size: 11px; color: var(--text-faint); margin: 2px 0 6px; }
    .loc-desc { font-size: 12px; color: var(--text-secondary); line-height: 1.7; }
    .loc-actions { display: flex; flex-wrap: wrap; gap: 8px; }
    .shop-block { margin-bottom: 12px; }
    .shop-title { font-size: 14px; font-weight: 600; color: var(--accent-deep); margin-bottom: 8px; }
    .shop-item { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 6px; }
    .shop-info { flex: 1; min-width: 0; }
    .shop-name2 { font-size: 13px; font-weight: 600; }
    .shop-desc { font-size: 11px; color: var(--text-faint); margin-top: 2px; }
    .shop-price { font-size: 14px; font-weight: 700; color: var(--butter); white-space: nowrap; }
    .job-item { display: flex; align-items: center; gap: 10px; background: rgba(255,255,255,0.5); border-radius: 12px; padding: 10px 12px; margin-bottom: 6px; }
    .job-info { flex: 1; min-width: 0; }
    .job-name2 { font-size: 13px; font-weight: 600; display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
    .job-desc { font-size: 11px; color: var(--text-faint); margin-top: 2px; line-height: 1.5; }
    .job-lock { font-size: 11px; color: var(--danger); margin-top: 4px; }
    .map-view { flex-shrink: 0; }
  `;
}
