export const WORLD = {
  name: '云栖市',
  motto: '亲切但独立，温柔而有边界',
  intro: '云栖市是一座位于温带沿海地区的现代化中等规模城市。整座城市被茂密的自然生态所环绕，形成了"城市—郊区—海洋"的三级地理格局。这里既有现代都市的便利，也有浓厚的小镇生活气息。',
  layout: '城市由六条主要街道呈"井"字型交叉排列，将城区划分为若干功能区块。',
};

export const STREETS = [
  { id: 'wutong', name: '梧桐大道', dir: '东西', pos: '北', desc: '北起城市边缘，沿线多为新建高层住宅与科技园区，绿化以梧桐树为主。' },
  { id: 'yunqizhongjie', name: '云栖中街', dir: '东西', pos: '中', desc: '城市最繁华的商业中轴线，穿过城市中心广场，购物中心、大型商超均坐落于此。' },
  { id: 'nanhe', name: '南河街', dir: '东西', pos: '南', desc: '南临穿城而过的河流，沿线多为改造后的老工业区与滨水休闲空间。' },
  { id: 'xishan', name: '西山道', dir: '南北', pos: '西', desc: '靠近西郊，沿线分布有别墅区、政务中心与教育园区。' },
  { id: 'zhongyang', name: '中央大道', dir: '南北', pos: '中', desc: '城市的主干道，贯穿政务中心、商业区和住宅区，是城市的中轴线。' },
  { id: 'donggang', name: '东港路', dir: '南北', pos: '东', desc: '通向东部沿海和工业物流园区，沿线多为制造业工厂和仓储中心。' },
];

export const PLACES = [
  // ===== 住所 =====
  { id: 'home', name: '家（许临安的宅邸）', street: 'zhongyang', zone: '住宅区', type: 'home', unlocked: true, exploreCost: { ep: 0, time: 0 }, desc: '独栋两层小楼，带一个小院，位于云栖市住宅区。二楼右手边是你的房间，书桌上摆着崭新的文具与课本。', actions: ['睡觉', '吃饭', '洗漱', '自习', '休息'] },
  // ===== 商业区 =====
  { id: 'mall', name: '云栖汇购物中心', street: 'yunqizhongjie', zone: '商业区', type: 'mall', unlocked: true, exploreCost: { ep: 6, time: 60 }, desc: '位于云栖中街与中央大道交汇处。内设服装区、美妆区、电子城、家具生活馆、宠物店。', shops: ['clothing', 'cosmetics', 'electronics', 'furniture', 'petshop'] },
  { id: 'convenience', name: '全天便利', street: 'zhongyang', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 15 }, desc: '24小时营业的便利店。店长顾清寡言但细心，夜里总在柜台后看书。', shop: 'convenience' },
  { id: 'stationery', name: '纸墨时光文具店', street: 'yunqizhongjie', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 15 }, desc: '店长苏念对文具和纸张有着近乎偏执的热爱，角落的留言本已经写满了顾客的随笔。', shop: 'stationery' },
  { id: 'flower', name: '朝露花坊', street: 'yunqizhongjie', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 15 }, desc: '花艺世家出身的陆晚打理的花店，每天早上五点半去花市选花，从不假手于人。', shop: 'flower' },
  { id: 'bakery', name: '麦香晨光面包房', street: 'yunqizhongjie', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 15 }, desc: '曾在法国学烘焙三年的何予安开的店，用料扎实，每天清晨四点就开始忙碌。', shop: 'bakery' },
  { id: 'coffee', name: '街角咖啡', street: 'yunqizhongjie', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 20 }, desc: '拿过拉花比赛奖项的程时开的咖啡店，店里有一整面他看过的书墙。', shop: 'coffee' },
  { id: 'bookstore', name: '纸上云栖书店', street: 'yunqizhongjie', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 20 }, desc: '哲学系毕业的言清开的书店，店里有一只名叫"句子"的黑猫。', shop: 'bookstore' },
  { id: 'pharmacy', name: '仁心药房', street: 'yunqizhongjie', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 3, time: 15 }, desc: '曾做过医生的许衍开的药店，偶尔会为买不起药的人赊账。', shop: 'pharmacy' },
  { id: 'foodstreet', name: '云栖食集', street: 'yunqizhongjie', zone: '商业区', type: 'restaurant', unlocked: true, exploreCost: { ep: 5, time: 30 }, desc: '骆闻在小吃街老店基础上扩展成的美食街区，外冷内热，记得每个老顾客的忌口。', shop: 'foodstreet' },
  { id: 'supermarket', name: '云栖大润发超市', street: 'zhongyang', zone: '商业区', type: 'shop', unlocked: true, exploreCost: { ep: 4, time: 20 }, desc: '大型连锁超市，日用品与食材一应俱全。', shop: 'supermarket' },
  // ===== 行政区 =====
  { id: 'gov', name: '政务中心', street: 'xishan', zone: '行政区', type: 'facility', unlocked: true, exploreCost: { ep: 4, time: 30 }, desc: '一站式服务大厅，办理证件与市政事务。' },
  { id: 'police', name: '派出所', street: 'xishan', zone: '行政区', type: 'facility', unlocked: true, exploreCost: { ep: 4, time: 30 }, desc: '维护云栖市治安的基层单位。' },
  // ===== 教育区 =====
  { id: 'school', name: '云栖市第一中学', street: 'xishan', zone: '教育区', type: 'school', unlocked: true, exploreCost: { ep: 0, time: 0 }, desc: '完全中学，含初中部与高中部。校训"明德、笃学、慎思、力行"。你的求学之旅将在此展开。', actions: ['上课', '图书馆学习', '食堂用餐', '操场活动', '天台'] },
  { id: 'library', name: '市立图书馆', street: 'xishan', zone: '教育区', type: 'facility', unlocked: true, exploreCost: { ep: 4, time: 60 }, desc: '安静的公共图书馆，是自习与阅读的好去处。', actions: ['自习', '阅读', '借书'] },
  { id: 'university', name: '云栖大学', street: 'xishan', zone: '教育区', type: 'school', unlocked: false, exploreCost: { ep: 6, time: 60 }, desc: '综合性省属重点大学，校训"博学、审问、慎思、明辨、笃行"。', actions: ['上课', '图书馆', '社团', '栖湖散步'] },
  // ===== 公共设施 =====
  { id: 'hospital', name: '云栖市第一人民医院', street: 'zhongyang', zone: '公共设施', type: 'facility', unlocked: true, exploreCost: { ep: 5, time: 40 }, desc: '综合医院，提供全面的医疗服务。' },
  { id: 'museum', name: '云栖历史博物馆', street: 'zhongyang', zone: '公共设施', type: 'facility', unlocked: true, exploreCost: { ep: 5, time: 50 }, desc: '展示云栖市百年历史的博物馆。' },
  { id: 'centralpark', name: '中央公园', street: 'zhongyang', zone: '公共设施', type: 'nature', unlocked: true, exploreCost: { ep: 4, time: 40 }, desc: '城市中心的绿地公园，适合散步、休息与放松心情。' },
  { id: 'xishanpark', name: '西山郊野公园', street: 'xishan', zone: '公共设施', type: 'nature', unlocked: true, exploreCost: { ep: 5, time: 60 }, desc: '依山而建的郊野公园，空气清新，适合远足。' },
  { id: 'riverside', name: '南河滨水步道', street: 'nanhe', zone: '公共设施', type: 'nature', unlocked: true, exploreCost: { ep: 3, time: 30 }, desc: '沿南河而建的滨水休闲空间，黄昏时分格外惬意。' },
  { id: 'church', name: '圣心大教堂', street: 'xishan', zone: '公共设施', type: 'faith', unlocked: true, exploreCost: { ep: 4, time: 40 }, desc: '建于拓荒时代晚期的地标建筑，信奉温和的"晨光教义"。神职人员白语在此侍奉。', actions: ['礼拜', '晨省', '静默沉思'] },
  // ===== 娱乐区 =====
  { id: 'theater', name: '大剧院', street: 'nanhe', zone: '娱乐区', type: 'entertain', unlocked: true, exploreCost: { ep: 5, time: 90 }, desc: '云栖市最高规格的演出场所，上演经典剧目与音乐会。' },
  { id: 'cinema', name: '云栖影城', street: 'nanhe', zone: '娱乐区', type: 'entertain', unlocked: true, exploreCost: { ep: 5, time: 110 }, desc: '现代化的电影院。' },
  { id: 'stadium', name: '云栖体育中心', street: 'nanhe', zone: '娱乐区', type: 'entertain', unlocked: true, exploreCost: { ep: 6, time: 90 }, desc: '大型体育场馆，可进行各类运动锻炼。' },
  // ===== 工业/科技区 =====
  { id: 'factory', name: '云栖精密制造', street: 'donggang', zone: '工业区', type: 'work', unlocked: true, exploreCost: { ep: 6, time: 60 }, desc: '以机械加工为代表的制造业工厂，负责人是周渡。' },
  { id: 'garmentfactory', name: '新潮服饰', street: 'donggang', zone: '工业区', type: 'work', unlocked: true, exploreCost: { ep: 5, time: 50 }, desc: '云栖市轻工业支柱之一的服装工厂。' },
  { id: 'logistics', name: '顺捷物流', street: 'donggang', zone: '工业区', type: 'work', unlocked: true, exploreCost: { ep: 5, time: 50 }, desc: '城市物流仓储中心。' },
  { id: 'techpark', name: '云栖科技谷', street: 'wutong', zone: '工业区', type: 'work', unlocked: true, exploreCost: { ep: 6, time: 60 }, desc: '科技园区，聚集众多软件与硬件研发公司。' },
  // ===== 住宅区 =====
  { id: 'feicuiwan', name: '翡翠湾别墅区', street: 'xishan', zone: '住宅区', type: 'residence', unlocked: false, exploreCost: { ep: 5, time: 40 }, desc: '西山脚下的别墅区，环境清幽，是富裕阶层的聚居地。' },
  { id: 'wutongyuan', name: '梧桐苑', street: 'zhongyang', zone: '住宅区', type: 'residence', unlocked: true, exploreCost: { ep: 3, time: 20 }, desc: '中央大道沿线的多层住宅，生活便利，密度适中。' },
  // ===== 自然与外界 =====
  { id: 'linhai', name: '云栖林海', street: 'wutong', zone: '自然', type: 'nature', unlocked: true, exploreCost: { ep: 8, time: 90 }, desc: '环绕城市的茂密原始森林，林中有蜿蜒河流与清澈湖泊。' },
  { id: 'jinghu', name: '镜湖', street: 'wutong', zone: '自然', type: 'nature', unlocked: true, exploreCost: { ep: 7, time: 80 }, desc: '云栖林海深处的清澈湖泊，湖面如镜。' },
  { id: 'goldbeach', name: '金沙滩', street: 'donggang', zone: '自然', type: 'nature', unlocked: true, exploreCost: { ep: 7, time: 90 }, desc: '城市东部的优质沙滩，是夏日游泳与观赏日出的胜地。' },
  { id: 'port', name: '云栖港', street: 'donggang', zone: '自然', type: 'nature', unlocked: true, exploreCost: { ep: 5, time: 50 }, desc: '承担部分货物运输与渔业功能的港口。' },
  // ===== 灰色地带 =====
  { id: 'yeyouchuan', name: '夜航船酒吧', street: 'nanhe', zone: '灰色地带', type: 'gray', unlocked: false, exploreCost: { ep: 8, time: 90 }, desc: '隐藏在酒吧街深处的酒吧，是灰色地带信息与交易的集散地。', risk: true },
  { id: 'heishi', name: '东港路黑市', street: 'donggang', zone: '灰色地带', type: 'gray', unlocked: false, exploreCost: { ep: 8, time: 90 }, desc: '废弃工厂内的地下交易市场，交易未经授权的电子产品与高仿奢侈品。', risk: true },
];

export const SCHOOLS = {
  middle: {
    name: '云栖市第一中学',
    location: '西山道北段',
    motto: '明德、笃学、慎思、力行',
    schedule: '周一至周五 8:00-16:00 上课',
  },
  university: {
    name: '云栖大学',
    location: '西山道北段与梧桐大道西段交汇处',
    motto: '博学、审问、慎思、明辨、笃行',
    schedule: '学分制',
  },
};

export const WORLD_ENCYCLOPEDIA = {
  history: '云栖市始建于一百二十余年前的拓荒时代。一批来自海外的建筑师与本地工匠共同修建了圣心大教堂，为沿海的渔民和异乡客提供心灵庇护所。城市由开港通商的"开市日"发展为如今的现代化都市，保留着浓厚的市井温情。',
  doctrine: '晨光教义是云栖市的主流信仰，融合了本土"务实主义"与"自然崇拜"。三大信条：①光在晨雾中——真理与善意如清晨雾气般弥漫在日常缝隙中，每日清晨6:00-8:00静默沉思即为"晨省"；②诚实的劳作即是最好的祈祷——提倡"时间捐献"，每月两小时社区服务；③守护界限的温柔——尊重他人隐私与选择。教义将死亡称为"归航"，教堂地下设有存放逝者珍爱之物的"记忆档案库"。',
  festivals: [
    { name: '元春节', date: '1月1日-3日', desc: '云栖市的新年，源自旧时开港通商的"开市日"，象征一年之始。' },
    { name: '灯火节', date: '12月20日-22日', desc: '冬至前后年末最大的节日，象征"长夜将尽，光明回归"。云栖中街挂满手工纸灯，南河上漂浮祈愿灯，家人围炉吃暖锅。' },
    { name: '云栖花朝节', date: '3月', desc: '春季伊始，全城举办花市、汉服巡游，评选"花神"。' },
    { name: '南河音乐节', date: '5月', desc: '在滨水空间举办，持续三天，汇集摇滚、民谣与古典音乐。' },
    { name: '金沙滩海洋节', date: '7月', desc: '夏季海洋主题狂欢，包括沙雕大赛、帆船赛和海鲜美食节。' },
    { name: '云栖文化周', date: '10月', desc: '大剧院上演经典剧目，博物馆举办特展，全市共享文化盛宴。' },
    { name: '感恩季', date: '12月', desc: '教堂和商业区氛围浓厚的慈善季，伴有募捐和亮灯仪式。' },
  ],
  society: '云栖市的社会结构呈稳定的橄榄型：富裕阶层（约10%）多为科技园区创始人、企业高管与知名医生，住在西山道别墅区；中产阶层（约70%）是城市中坚力量，重视子女教育与生活质量；工薪阶层（约20%）是城市烟火气的主要来源。城市以世俗文化为主，圣心大教堂是地标，郊区林海深处还有云栖禅寺与清微道观。',
  gray: '云栖市的灰色地带隐蔽于商业街旧写字楼、工业区废弃仓库与24小时便利店背后，涉及信息与数据犯罪、地下赌场、色情服务、高仿交易等。毒品零容忍是灰色地带默认的底线。',
};
