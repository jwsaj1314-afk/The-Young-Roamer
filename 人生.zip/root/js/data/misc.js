export const TALENTS = [
  { id: 'perfect-pitch', name: '绝对音感', desc: '乐器技能升级速度 +30%，编曲判定时获得额外加成', cat: 'art' },
  { id: 'photographic', name: '过目不忘', desc: '阅读/学习内容记忆效率 +50%，文科素养与外语升级加速', cat: 'study' },
  { id: 'social-master', name: '社交达人', desc: '初次社交时魅力临时 +2，友谊值获取速度 +20%', cat: 'social' },
  { id: 'stress-resistant', name: '抗压体质', desc: '压力值增长速度 -30%，压力上限临时提升至 120', cat: 'mental' },
  { id: 'born-affinity', name: '天生亲和力', desc: '亲和力技能初始等级 +1，NPC 初始好感度 +10', cat: 'social' },
  { id: 'lucky', name: '幸运儿', desc: '运气属性固定 +2，随机事件有利概率提升', cat: 'special' },
  { id: 'iron-stomach', name: '铁胃', desc: '饱腹度下降速度 -30%，食用不洁食物生病概率大幅降低', cat: 'physical' },
  { id: 'night-owl', name: '夜猫子', desc: '夜间（22:00-6:00）精力恢复速度 +20%，但白天精力消耗 +10%', cat: 'mental' },
  { id: 'nimble-fingers', name: '心灵手巧', desc: '绘画、调香、烹饪等精细操作类技能升级速度 +20%', cat: 'art' },
  { id: 'polyglot', name: '语言天才', desc: '可额外选择一门第二外语学习，且所有外语升级速度 +25%', cat: 'study' },
  { id: 'athletic', name: '强健体魄', desc: '体质 +2，体能值上限 +20，体能恢复速度 +15%', cat: 'physical' },
  { id: 'intuitive', name: '敏锐直觉', desc: '感知 +2，洞察力判定时获得额外优势', cat: 'mental' },
  { id: 'stage-presence', name: '舞台体质', desc: '表演、舞蹈类技能在公开演出时获得额外加成，怯场概率大幅降低', cat: 'art' },
  { id: 'money-smart', name: '理财头脑', desc: '获得收入时额外 +10%，购物时可触发折扣判定', cat: 'special' },
  { id: 'empath', name: '共情者', desc: '更容易理解他人情绪，亲和力与说服力升级速度 +15%', cat: 'social' },
  { id: 'tenacious', name: '坚韧意志', desc: '压力值超过 80 时，负面状态效果减半，且不易主动放弃', cat: 'mental' },
  { id: 'nature-friend', name: '自然之友', desc: '在郊区/森林/海边时心情恢复速度 +30%，动物类 NPC 友好', cat: 'special' },
  { id: 'mechanical', name: '机械直觉', desc: '驾驶技能升级速度 +25%，对电子设备/机械操作有天然悟性', cat: 'practical' },
  { id: 'perfectionist', name: '完美主义者', desc: '完成艺术/创作类作品时，品质判定 +1，但耗时 +20%', cat: 'art' },
  { id: 'humor', name: '幽默感', desc: '社交时缓和气氛能力 +30%，可降低他人敌意/恨意值', cat: 'social' },
];

export const SKILLS = {
  academic: [
    { id: 'liberal-arts', name: '文科素养', cat: 'academic', desc: '语文/历史/政治/地理的综合水平' },
    { id: 'science', name: '理科素养', cat: 'academic', desc: '数学/物理/化学/生物的综合水平' },
    { id: 'foreign-lang', name: '外语能力', cat: 'academic', desc: '所选外语（英/日/德/俄/法）的掌握程度' },
  ],
  art: [
    { id: 'painting', name: '绘画', cat: 'art', desc: '素描、油画、水彩等视觉艺术创作能力' },
    { id: 'instrument', name: '乐器', cat: 'art', desc: '钢琴/小提琴/吉他等乐器演奏水平' },
    { id: 'dance', name: '舞蹈', cat: 'art', desc: '现代舞/芭蕾/街舞等肢体表现能力' },
    { id: 'acting', name: '表演', cat: 'art', desc: '台词、表情、肢体控制等戏剧影视表演能力' },
    { id: 'photography', name: '摄影', cat: 'art', desc: '构图、光影、后期处理的专业水平' },
    { id: 'screenwriting', name: '编剧', cat: 'art', desc: '故事结构、人物塑造、剧本写作能力' },
    { id: 'composition', name: '编曲', cat: 'art', desc: '音乐创作、和声编排、混音制作能力' },
    { id: 'perfume', name: '调香', cat: 'art', desc: '香料辨识、香水调配、气味美学能力' },
  ],
  practical: [
    { id: 'cooking', name: '烹饪', cat: 'practical', desc: '中西餐、烘焙、饮品制作能力' },
    { id: 'fight', name: '格斗', cat: 'practical', desc: '拳击/柔道/防身术等实战对抗能力' },
    { id: 'driving', name: '驾驶', cat: 'practical', desc: '汽车/摩托车/船只的操控能力' },
    { id: 'law', name: '法律知识', cat: 'practical', desc: '对法律法规的了解程度' },
    { id: 'medicine', name: '医学知识', cat: 'practical', desc: '基础医疗、急救、健康管理的知识储备' },
    { id: 'new-media', name: '新媒体运营', cat: 'practical', desc: '内容策划、视频剪辑、平台引流的能力' },
  ],
  social: [
    { id: 'leadership', name: '领导力', cat: 'social', desc: '组织团队、分配任务、激励他人的能力' },
    { id: 'friendliness', name: '亲和力', cat: 'social', desc: '让人感到舒适、愿意接近的气质与技巧' },
    { id: 'persuasion', name: '说服力', cat: 'social', desc: '逻辑论证、情感共鸣、谈判妥协的综合能力' },
    { id: 'insight', name: '洞察力', cat: 'social', desc: '识别谎言、发现细节、读懂潜台词的能力' },
  ],
};

export const MUSIC_TRACKS = [
  { id: 'down4u', name: 'Down 4u (沦陷英文版)', url: 'http://music.163.com/song/media/outer/url?id=2613702117.mp3', artist: '' },
  { id: 'chun-jiao', name: '春娇与志明', url: 'http://music.163.com/song/media/outer/url?id=2690846376.mp3', artist: '街道办 GDC/欧阳耀莹' },
  { id: 'melodic', name: 'Melodic Minor（Phonk）', url: 'http://music.163.com/song/media/outer/url?id=2721110890.mp3', artist: '' },
  { id: 'things', name: 'Things You Said', url: 'http://music.163.com/song/media/outer/url?id=2065868022.mp3', artist: '' },
  { id: 'sweet-boy', name: 'Sweet Boy', url: 'http://music.163.com/song/media/outer/url?id=2047237457.mp3', artist: '' },
  { id: 'inside', name: 'inside', url: 'http://music.163.com/song/media/outer/url?id=517566417.mp3', artist: '' },
  { id: 'memories', name: 'Memories', url: 'http://music.163.com/song/media/outer/url?id=2699076342.mp3', artist: '' },
  { id: 'luvsic', name: 'Luv(sic.) (Instrumental)', url: 'http://music.163.com/song/media/outer/url?id=1789241.mp3', artist: '' },
  { id: 'lonely-beat', name: '孤独 beat (You And Me)', url: 'http://music.163.com/song/media/outer/url?id=3339853915.mp3', artist: '' },
  { id: 'dehors', name: 'Dehors (外面)', url: 'http://music.163.com/song/media/outer/url?id=1815725297.mp3', artist: '' },
  { id: 'dont-let-me-go', name: "Don't let me go", url: 'http://music.163.com/song/media/outer/url?id=2147764252.mp3', artist: '' },
  { id: 'moonlit', name: 'Moonlit Dream (月光梦)', url: 'http://music.163.com/song/media/outer/url?id=2613048732.mp3', artist: '' },
  { id: 'morning-sex', name: 'Morning Sex', url: 'http://music.163.com/song/media/outer/url?id=1455979025.mp3', artist: '' },
  { id: 'touch', name: 'TOUCH', url: 'http://music.163.com/song/media/outer/url?id=1954849598.mp3', artist: '' },
];

export const TAROT = {
  majorArcana: [
    { id: 0, name: '愚者', keywords: ['新的开始', '冒险', '天真', ' spontaneity'], reversed: ['鲁莽', '冒险', '愚蠢'] },
    { id: 1, name: '魔术师', keywords: ['创造力', '技能', '意志力', '显化'], reversed: ['欺骗', '缺乏技能', '操纵'] },
    { id: 2, name: '女祭司', keywords: ['直觉', '神秘', '潜意识', '智慧'], reversed: ['压抑直觉', '肤浅', '混乱'] },
    { id: 3, name: '皇后', keywords: ['丰饶', '养育', '自然', '感官'], reversed: ['依赖', '创造力受阻', '缺乏成长'] },
    { id: 4, name: '皇帝', keywords: ['权威', '结构', '控制', '父亲形象'], reversed: ['专制', '僵化', '缺乏纪律'] },
    { id: 5, name: '教皇', keywords: ['传统', '信仰', '指导', '精神智慧'], reversed: ['反叛', '新方式', '无知'] },
    { id: 6, name: '恋人', keywords: ['爱', '和谐', '关系', '价值观认同'], reversed: ['不和谐', '失衡', '错误选择'] },
    { id: 7, name: '战车', keywords: ['意志', '决心', '胜利', '自我控制'], reversed: ['失控', '侵略', '失败'] },
    { id: 8, name: '力量', keywords: ['勇气', '耐心', '控制', '同情'], reversed: ['自我怀疑', '软弱', '不安全感'] },
    { id: 9, name: '隐士', keywords: ['内省', '孤独', '寻找真理', '指导'], reversed: ['孤立', '退缩', '拒绝建议'] },
    { id: 10, name: '命运之轮', keywords: ['变化', '周期', '命运', '转折点'], reversed: ['坏运气', '抵抗变化', '打破循环'] },
    { id: 11, name: '正义', keywords: ['公平', '真理', '因果', '法律'], reversed: ['不公', '不诚实', '缺乏责任感'] },
    { id: 12, name: '倒吊人', keywords: ['牺牲', '等待', '新视角', '放手'], reversed: ['徒劳', '牺牲无果', '停滞'] },
    { id: 13, name: '死神', keywords: ['结束', '转变', '过渡', '放手'], reversed: ['抵抗改变', '恐惧', '停滞'] },
    { id: 14, name: '节制', keywords: ['平衡', '适度', '耐心', '和谐'], reversed: ['失衡', '过度', '冲突'] },
    { id: 15, name: '恶魔', keywords: ['束缚', '成瘾', '物质主义', '阴影'], reversed: ['解脱', '觉醒', '打破枷锁'] },
    { id: 16, name: '高塔', keywords: ['突变', '觉醒', '启示', '混乱'], reversed: ['避免灾难', '恐惧变化', '延迟'] },
    { id: 17, name: '星星', keywords: ['希望', '灵感', '宁静', '更新'], reversed: ['绝望', '缺乏信心', '沮丧'] },
    { id: 18, name: '月亮', keywords: ['幻象', '恐惧', '焦虑', '潜意识'], reversed: ['真相显露', '恐惧消散', '清晰'] },
    { id: 19, name: '太阳', keywords: ['快乐', '成功', '活力', '温暖'], reversed: ['暂时的沮丧', '缺乏成功', '悲伤'] },
    { id: 20, name: '审判', keywords: ['复活', '内在召唤', '宽恕', '觉醒'], reversed: ['自我怀疑', '拒绝改变', '忽视召唤'] },
    { id: 21, name: '世界', keywords: ['完成', '整合', '成就', '旅行'], reversed: ['未完成', '缺乏成就感', '延迟'] },
  ],
  minorArcanaSuits: [
    { id: 'wands', name: '权杖', element: '火', keywords: ['激情', '行动', '创造力', '能量'] },
    { id: 'cups', name: '圣杯', element: '水', keywords: ['情感', '关系', '直觉', '爱'] },
    { id: 'swords', name: '宝剑', element: '风', keywords: ['思想', '沟通', '冲突', '决定'] },
    { id: 'pentacles', name: '星币', element: '土', keywords: ['物质', '金钱', '工作', '安全'] },
  ],
};

export const SCHEDULES = {
  middleSchool: {
   初一初二: [
      { time: '早读 7:30-8:00', mon: '语文', tue: '英语', wed: '语文', thu: '英语', fri: '数学' },
      { time: '第 1 节 8:00-8:45', mon: '数学', tue: '数学', wed: '英语', thu: '语文', fri: '英语' },
      { time: '第 2 节 8:55-9:40', mon: '语文', tue: '语文', wed: '数学', thu: '数学', fri: '语文' },
      { time: '课间操 9:40-10:10', mon: '', tue: '', wed: '', thu: '', fri: '' },
      { time: '第 3 节 10:10-10:55', mon: '英语', tue: '历史', wed: '语文', thu: '英语', fri: '数学' },
      { time: '第 4 节 11:05-11:50', mon: '道德与法治', tue: '地理', wed: '生物', thu: '历史', fri: '道德与法治' },
      { time: '午休 11:50-13:20', mon: '', tue: '', wed: '', thu: '', fri: '' },
      { time: '第 5 节 13:30-14:15', mon: '历史', tue: '生物', wed: '地理', thu: '数学', fri: '体育' },
      { time: '第 6 节 14:25-15:10', mon: '体育', tue: '音乐/美术', wed: '道德与法治', thu: '生物', fri: '地理' },
      { time: '第 7 节 15:20-16:05', mon: '自习/班会', tue: '体育', wed: '信息技术', thu: '音乐/美术', fri: '历史' },
      { time: '第 8 节 16:15-17:00', mon: '社团活动', tue: '', wed: '', thu: '', fri: '' },
    ],
    初三: [
      { time: '早读 7:30-8:00', mon: '语文', tue: '英语', wed: '数学', thu: '语文', fri: '英语' },
      { time: '第 1 节 8:00-8:45', mon: '数学', tue: '数学', wed: '英语', thu: '物理', fri: '语文' },
      { time: '第 2 节 8:55-9:40', mon: '语文', tue: '语文', wed: '数学', thu: '化学', fri: '英语' },
      { time: '第 3 节 10:10-10:55', mon: '英语', tue: '物理', wed: '语文', thu: '数学', fri: '数学' },
      { time: '第 4 节 11:05-11:50', mon: '物理', tue: '化学', wed: '道德与法治', thu: '英语', fri: '物理' },
      { time: '午休 11:50-13:20', mon: '', tue: '', wed: '', thu: '', fri: '' },
      { time: '第 5 节 13:30-14:15', mon: '化学', tue: '道德与法治', wed: '物理', thu: '历史', fri: '化学' },
      { time: '第 6 节 14:25-15:10', mon: '历史', tue: '体育', wed: '化学', thu: '道德与法治', fri: '历史' },
      { time: '第 7 节 15:20-16:05', mon: '体育', tue: '历史', wed: '体育', thu: '自习', fri: '道德与法治' },
      { time: '第 8 节 16:15-17:00', mon: '自习', tue: '自习', wed: '自习', thu: '社团活动', fri: '班会' },
      { time: '晚自习 1 18:30-19:30', mon: '语文/英语', tue: '数学/物理', wed: '英语/化学', thu: '数学/历史', fri: '' },
      { time: '晚自习 2 19:45-20:30', mon: '自习', tue: '自习', wed: '自习', thu: '自习', fri: '' },
    ],
  },
  highSchool: {
    高一选科前: [
      { time: '早读 7:30-8:00', mon: '语文', tue: '外语', wed: '语文', thu: '外语', fri: '外语' },
      { time: '第 1 节 8:00-8:45', mon: '数学', tue: '数学', wed: '数学', thu: '数学', fri: '数学' },
      { time: '第 2 节 8:55-9:40', mon: '语文', tue: '语文', wed: '外语', thu: '语文', fri: '外语' },
      { time: '课间操 9:40-10:10', mon: '', tue: '', wed: '', thu: '', fri: '' },
      { time: '第 3 节 10:10-10:55', mon: '外语', tue: '物理', wed: '语文', thu: '外语', fri: '语文' },
      { time: '第 4 节 11:05-11:50', mon: '物理', tue: '化学', wed: '物理', thu: '历史', fri: '物理' },
      { time: '午休 11:50-13:20', mon: '', tue: '', wed: '', thu: '', fri: '' },
      { time: '第 5 节 13:30-14:15', mon: '化学', tue: '生物', wed: '化学', thu: '政治', fri: '化学' },
      { time: '第 6 节 14:25-15:10', mon: '历史', tue: '政治', wed: '生物', thu: '生物', fri: '历史' },
      { time: '第 7 节 15:20-16:05', mon: '政治', tue: '历史', wed: '地理', thu: '地理', fri: '政治' },
      { time: '第 8 节 16:15-17:00', mon: '地理', tue: '地理', wed: '体育', thu: '体育', fri: '地理' },
      { time: '第 9 节 17:00-17:45', mon: '体育', tue: '信息技术', wed: '自习', thu: '音乐/美术', fri: '体育' },
      { time: '晚自习 1 18:30-20:00', mon: '主科轮换', tue: '', wed: '', thu: '', fri: '' },
      { time: '晚自习 2 20:15-21:30', mon: '自习', tue: '', wed: '', thu: '', fri: '' },
    ],
  },
};

export const INITIAL_STORY = {
  title: '初来乍到',
  content: `大门是虚掩的。

福利院的陈院长把你送到门口，帮你拎着那只旧行李箱，在台阶下站了一会儿，欲言又止地拍了拍你的肩，转身走了。你听见车子发动的声音，然后是一阵轮胎碾过落叶的细碎响动，渐渐远了。

你一个人站在原地。

面前是一栋两层的小楼，带一个院子，院门没锁。你推门进去，石板路两侧种着叫不出名字的绿植，角落里有一把长椅，椅面上落了几片叶子。房子很安静，没有灯光，没有人声。

你想起前几天陈院长跟你说的话：有人愿意收养你，手续都办好了，是个靠谱的人，在云栖市有自己的住处，工作稳定，生活也规律。就是眼下人不在，临时有事出了趟差，明天才回来。

「你自己先去，钥匙我托人放在门口垫子底下了。」

「屋里都给你收拾好了，就当自己家。别怕。」

你蹲下身，掀起门口的垫子，果然摸到一把冰凉的钥匙。门锁转动的声响在安静的街道上显得格外清晰。屋里光线有些暗，窗帘半拉着，客厅收拾得整整齐齐，茶几上放着一盘洗好的水果，用保鲜膜罩着。

你站在玄关，没有立刻往里走。鞋柜上有一张纸条，字迹端正干净，笔画不重，看着像是做事利落的人写的：

【纸条】欢迎回家。临时出差，明天下午回来。厨房有吃的，冰箱里有牛奶。有事打这个电话。【/纸条】

下面写着一串号码。

你把纸条攥在手里，站了一会儿，换了鞋，提着行李上了二楼。楼梯口右手边就是你的房间，门开着，窗帘被风轻轻吹动。床铺好了，被褥是新的，衣柜空着，书桌上摆着一套崭新的文具，还有几本课本，码得整整齐齐。

你把行李箱靠墙放好，走到窗前。窗户朝南，能看见街道两旁的行道树，叶子在风里一晃一晃的。远处有公交车驶过的声音，隐约传来一两声鸟叫。

这座城市你还没怎么来过。这里的人、这里的路、这里的空气，都还不认识你。但你已经站在这里了，站在一间属于你的房间里。

明天是开学的日子。

那个叫许临安的人，说是收养你的人，会在这之前回来。你们会见面，会开始一段你完全无法预想的生活。而现在，这个傍晚，你有一整个夜晚可以独自度过。

风从窗外吹进来，带着一点草木的气味。你把手里的纸条又看了一遍，然后折好，放进口袋。`,
  options: [
    { text: '收拾房间', next: 'organize-room' },
    { text: '下楼看看有什么吃的', next: 'check-kitchen' },
    { text: '坐在床边发会儿呆', next: 'sit-and-think' },
  ],
};

export const INITIAL_QQ_MESSAGES = [
  {
    id: 'msg-xulinan-1',
    from: 'xulinan',
    content: '到家了吗？路上还顺利吗？',
    timestamp: Date.now() - 3600000,
    read: false,
  },
];
