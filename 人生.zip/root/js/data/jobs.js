// 由设计文档自动提取

export const JOBS = [
  // ===== 购物中心——云栖汇 =====
  { id: 'fashion-sales', name: '服装导购', place: '购物中心——云栖汇', salary: 35, minAge: 14, maxAge: 17, req: { cha: 4 }, consume: { ep: 6, sta: 4, clean: 0, stress: 0 }, skillExp: { friendliness: 3 }, bonus: '时尚感知提升，有机会结识富户', gray: false },
  { id: 'cosmetics-sales', name: '化妆品专柜销售', place: '购物中心——云栖汇', salary: 40, minAge: 14, maxAge: 17, req: { cha: 5, friendliness: 2 }, consume: { ep: 7, sta: 0, clean: 2, stress: 0 }, skillExp: { friendliness: 4, persuasion: 3 }, bonus: '可获化妆品小样，调香技能经验+2', gray: false },
  { id: 'electronics-sales', name: '电子产品导购', place: '购物中心——云栖汇', salary: 38, minAge: 14, maxAge: 17, req: { int: 4, science: 2 }, consume: { ep: 8, sta: 0, clean: 0, stress: 0 }, skillExp: { persuasion: 3, science: 2 }, bonus: '接触最新电子设备，科技园人脉', gray: false },
  { id: 'furniture-display', name: '家具区陈列员', place: '购物中心——云栖汇', salary: 42, minAge: 14, maxAge: 17, req: { sta: 5 }, consume: { ep: 5, sta: 10, clean: 5, stress: 0 }, skillExp: {}, bonus: '偶尔获赠小型家居用品', gray: false },
  { id: 'pet-shop-clerk', name: '宠物店店员', place: '购物中心——云栖汇', salary: 30, minAge: 14, maxAge: 17, req: { friendliness: 3 }, consume: { ep: 6, sta: 0, clean: 8, stress: 0 }, skillExp: { friendliness: 3 }, bonus: '与宠物互动心情+5，可领养特殊宠物', gray: false },

  // ===== 便利店——全天便利 =====
  { id: 'convenience-cashier', name: '收银员', place: '全天便利（全市多家分店）', salary: 28, minAge: 14, maxAge: 17, req: {}, consume: { ep: 6, sta: 3, clean: 0, stress: 0 }, skillExp: {}, bonus: '夜间班次可触发特殊事件', gray: false },
  { id: 'night-clerk', name: '夜班店员', place: '全天便利（全市多家分店）', salary: 40, minAge: 18, req: { age: 18 }, consume: { ep: 10, sta: 0, clean: 0, stress: 8 }, skillExp: {}, bonus: '高概率触发灰色地带事件', gray: false },

  // ===== 文具店——纸墨时光 =====
  { id: 'stationery-clerk', name: '店员', place: '纸墨时光文具店', salary: 26, minAge: 14, maxAge: 17, req: {}, consume: { ep: 5, sta: 3, clean: 0, stress: 0 }, skillExp: {}, bonus: '购买文具享受员工折扣（8折）', gray: false },

  // ===== 花店——朝露花坊 =====
  { id: 'florist-assistant', name: '花艺助理', place: '朝露花坊', salary: 32, minAge: 14, maxAge: 17, req: { perception: 3 }, consume: { ep: 6, sta: 4, clean: 0, stress: 0 }, skillExp: {}, bonus: '学习花艺知识，心情+3/小时', gray: false },

  // ===== 面包房——麦香晨光 =====
  { id: 'baker-apprentice', name: '烘焙学徒', place: '麦香晨光面包房', salary: 34, minAge: 14, maxAge: 17, req: { phy: 4, cooking: 1 }, consume: { ep: 8, sta: 8, clean: 6, stress: 0 }, skillExp: { cooking: 4 }, bonus: '每日获赠一个面包（恢复饱腹30）', gray: false },

  // ===== 咖啡店——街角咖啡 =====
  { id: 'barista-assistant', name: '咖啡师助理', place: '街角咖啡', salary: 36, minAge: 14, maxAge: 17, req: { perception: 4 }, consume: { ep: 8, sta: 0, clean: 4, stress: 0 }, skillExp: { cooking: 4 }, bonus: '学习拉花技巧，每日免费咖啡一杯（临时精力+10）', gray: false },

  // ===== 书店——纸上云栖 =====
  { id: 'bookstore-clerk', name: '店员', place: '纸上云栖书店', salary: 28, minAge: 14, maxAge: 17, req: { liberalArts: 2 }, consume: { ep: 6, sta: 0, clean: 0, stress: 0 }, skillExp: { liberalArts: 3 }, bonus: '可免费借阅店内书籍，阅读速度+10%', gray: false },

  // ===== 大型超市——云栖大润发 =====
  { id: 'supermarket-stocker', name: '理货员', place: '云栖大润发超市', salary: 30, minAge: 14, maxAge: 17, req: { sta: 4 }, consume: { ep: 6, sta: 8, clean: 4, stress: 0 }, skillExp: {}, bonus: '员工购物9.5折', gray: false },

  // ===== 餐厅/小吃街——云栖食集 =====
  { id: 'waiter', name: '服务员', place: '云栖食集', salary: 32, minAge: 14, maxAge: 17, req: { friendliness: 3 }, consume: { ep: 8, sta: 8, clean: 0, stress: 0 }, skillExp: { friendliness: 3 }, bonus: '每日免费工作餐（恢复饱腹40）', gray: false },
  { id: 'kitchen-helper', name: '帮厨', place: '云栖食集', salary: 30, minAge: 14, maxAge: 17, req: { cooking: 1 }, consume: { ep: 7, sta: 7, clean: 8, stress: 0 }, skillExp: { cooking: 3 }, bonus: '学习厨师手艺，有机会获得菜谱', gray: false },
  { id: 'foodstreet-cashier', name: '收银员', place: '云栖食集', salary: 28, minAge: 14, maxAge: 17, req: {}, consume: { ep: 6, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '结识餐饮业人脉', gray: false },

  // ===== 市立图书馆 =====
  { id: 'library-assistant', name: '图书管理员助理', place: '市立图书馆', salary: 26, minAge: 14, maxAge: 17, req: { liberalArts: 3 }, consume: { ep: 5, sta: 3, clean: 0, stress: 0 }, skillExp: { liberalArts: 4 }, bonus: '可优先借阅新书，安静环境压力-2/小时', gray: false },

  // ===== 博物馆——云栖历史博物馆 =====
  { id: 'museum-guide', name: '讲解员（兼职）', place: '云栖历史博物馆', salary: 35, minAge: 14, maxAge: 17, req: { liberalArts: 4, cha: 4 }, consume: { ep: 8, sta: 4, clean: 0, stress: 0 }, skillExp: { liberalArts: 3, persuasion: 3 }, bonus: '深入了解云栖市历史，触发隐藏剧情', gray: false },

  // ===== 城市公园——中央公园 =====
  { id: 'park-gardener', name: '绿化养护工', place: '中央公园', salary: 25, minAge: 14, maxAge: 17, req: { phy: 4 }, consume: { ep: 6, sta: 8, clean: 6, stress: 0 }, skillExp: {}, bonus: '自然环境中心情+2/小时', gray: false },
  { id: 'boat-rental', name: '游船租赁员', place: '中央公园', salary: 27, minAge: 14, maxAge: 17, req: {}, consume: { ep: 5, sta: 4, clean: 0, stress: 0 }, skillExp: {}, bonus: '认识各种游客，周末收入+20%', gray: false },

  // ===== 市立第一中学 / 云栖实验中学（校内兼职） =====
  { id: 'school-library-assistant', name: '图书馆学生助理', place: '市立第一中学/云栖实验中学', salary: 20, minAge: 14, maxAge: 17, req: {}, consume: { ep: 4, sta: 0, clean: 0, stress: 0 }, skillExp: { liberalArts: 2 }, bonus: '可自习（同时恢复精力）', gray: false },
  { id: 'lab-assistant', name: '实验室助理', place: '市立第一中学/云栖实验中学', salary: 22, minAge: 14, maxAge: 17, req: { science: 3 }, consume: { ep: 6, sta: 0, clean: 4, stress: 0 }, skillExp: { science: 3 }, bonus: '提前接触实验设备', gray: false },

  // ===== 制造业工厂——云栖精密制造 =====
  { id: 'assembly-worker', name: '流水线工人', place: '云栖精密制造', salary: 38, minAge: 18, req: { age: 18, phy: 5 }, consume: { ep: 8, sta: 10, clean: 8, stress: 0 }, skillExp: {}, bonus: '加班工资1.5倍', gray: false },
  { id: 'warehouse-keeper', name: '仓库管理员', place: '云栖精密制造', salary: 35, minAge: 14, maxAge: 17, req: { sta: 4 }, consume: { ep: 6, sta: 8, clean: 0, stress: 0 }, skillExp: {}, bonus: '偶尔可获瑕疵品（低价转卖）', gray: false },

  // ===== 科技园区——云栖科技谷 =====
  { id: 'data-annotator', name: '数据标注员', place: '云栖科技谷', salary: 42, minAge: 14, maxAge: 17, req: { int: 5, science: 3 }, consume: { ep: 10, sta: 0, clean: 0, stress: 0 }, skillExp: { science: 3 }, bonus: '接触AI行业，建立科技圈人脉', gray: false },
  { id: 'software-tester', name: '软件测试实习生', place: '云栖科技谷', salary: 45, minAge: 14, maxAge: 17, req: { int: 6, science: 4 }, consume: { ep: 10, sta: 0, clean: 0, stress: 0 }, skillExp: { science: 5 }, bonus: '可获得实习证明，对升大学有帮助', gray: false },

  // ===== 综合医院——云栖市第一人民医院 =====
  { id: 'hospital-volunteer', name: '志愿者/护工', place: '云栖市第一人民医院', salary: 28, minAge: 14, maxAge: 17, req: { medicine: 1 }, consume: { ep: 8, sta: 0, clean: 0, stress: 5 }, skillExp: { medicine: 4 }, bonus: '了解医疗行业，有机会获得医疗人脉', gray: false },
  { id: 'pharmacy-assistant', name: '药房助理', place: '云栖市第一人民医院', salary: 32, minAge: 14, maxAge: 17, req: { medicine: 3 }, consume: { ep: 7, sta: 0, clean: 0, stress: 0 }, skillExp: { medicine: 5 }, bonus: '学习药品知识，员工购药优惠', gray: false },

  // ===== 大剧院 =====
  { id: 'ticket-clerk', name: '票务员', place: '大剧院', salary: 30, minAge: 14, maxAge: 17, req: {}, consume: { ep: 6, sta: 4, clean: 0, stress: 0 }, skillExp: {}, bonus: '可免费观看演出', gray: false },
  { id: 'stage-assistant', name: '舞台助理（兼职）', place: '大剧院', salary: 38, minAge: 14, maxAge: 17, req: { sta: 4 }, consume: { ep: 8, sta: 8, clean: 4, stress: 0 }, skillExp: { acting: 2 }, bonus: '接触艺术圈，与演员/导演建立联系', gray: false },

  // ===== 体育场馆——云栖体育中心 =====
  { id: 'stadium-keeper', name: '场地维护员', place: '云栖体育中心', salary: 28, minAge: 14, maxAge: 17, req: { sta: 4 }, consume: { ep: 6, sta: 8, clean: 0, stress: 0 }, skillExp: {}, bonus: '免费使用场馆设施', gray: false },
  { id: 'fitness-assistant', name: '健身教练助理', place: '云栖体育中心', salary: 40, minAge: 14, maxAge: 17, req: { phy: 6 }, consume: { ep: 8, sta: 8, clean: 0, stress: 0 }, skillExp: { fight: 3 }, bonus: '可免费训练，提升体质经验', gray: false },

  // ===== 圣心大教堂 =====
  { id: 'church-volunteer', name: '志愿者（无薪）', place: '圣心大教堂', salary: 0, minAge: 14, maxAge: 17, req: { faith: 20 }, consume: { ep: 5, sta: 4, clean: 0, stress: 0 }, skillExp: { faith: 5 }, bonus: '心情+5/小时，触发晨光教义剧情', gray: false },
  { id: 'choir-member', name: '唱诗班成员（兼职）', place: '圣心大教堂', salary: 25, minAge: 14, maxAge: 17, req: { instrument: 3, faith: 30 }, consume: { ep: 6, sta: 0, clean: 0, stress: 0 }, skillExp: { instrument: 3, faith: 3 }, bonus: '获得教堂人脉，参与重要节庆', gray: false },

  // ===== 灰色地带——夜航船酒吧 / 废弃仓库（高风险） =====
  { id: 'bar-attendant', name: '酒吧招待', place: '夜航船酒吧/废弃仓库', salary: 60, minAge: 18, req: { age: 18, cha: 4 }, consume: { ep: 10, sta: 0, clean: 4, stress: 10 }, skillExp: { persuasion: 2 }, bonus: '获取灰色地带情报', gray: true, crime: 2 },
  { id: 'casino-dealer', name: '赌场荷官（地下）', place: '夜航船酒吧/废弃仓库', salary: 80, minAge: 18, req: { age: 18, cha: 5 }, consume: { ep: 12, sta: 0, clean: 0, stress: 15 }, skillExp: {}, bonus: '高概率触发危险事件', gray: true, crime: 5 },
  { id: 'info-broker', name: '信息倒卖中间人', place: '夜航船酒吧/废弃仓库', salary: 100, minAge: 18, req: { age: 18, perception: 5 }, consume: { ep: 8, sta: 0, clean: 0, stress: 20 }, skillExp: { insight: 3 }, bonus: '极高风险', gray: true, crime: 8 },

  // ===== 特殊工作与进阶岗位 =====
  { id: 'tutor', name: '家教', place: null, salary: 90, req: {}, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '为初中/小学生辅导，收入视科目难度（时薪60~120）', gray: false, special: true },
  { id: 'freelance-artist', name: '自由画师', place: null, salary: 140, req: {}, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '接稿创作，按单结算（时薪80~200）', gray: false, special: true },
  { id: 'music-tutor', name: '音乐私教', place: null, salary: 115, req: { instrument: 6 }, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '教授乐器，需拥有乐器（时薪80~150）', gray: false, special: true },
  { id: 'content-creator', name: '新媒体内容创作者', place: null, salary: 0, req: {}, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '发布内容获取流量收益（广告分成）', gray: false, special: true },
  { id: 'freelance-reporter', name: '兼职记者', place: null, salary: 50, req: { liberalArts: 5 }, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '投稿新闻/专栏（50/篇）', gray: false, special: true },
  { id: 'psych-assistant', name: '心理咨询助理', place: '心灵花园诊所', salary: 50, req: { friendliness: 5 }, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '在心灵花园诊所协助', gray: false, special: true },
  { id: 'dock-worker', name: '码头临时工', place: '云栖港', salary: 40, minAge: 18, req: { age: 18, sta: 6 }, consume: { ep: 0, sta: 0, clean: 0, stress: 0 }, skillExp: {}, bonus: '搬运货物，偶尔触发走私事件', gray: false, special: true },
];
