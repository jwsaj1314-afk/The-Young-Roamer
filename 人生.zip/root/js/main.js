import { loadState, saveState } from './core/storage.js';
import { initRelations } from './core/state.js';
import { setAPIConfig } from './core/ai.js';

const app = document.getElementById('app');

export const Game = {
  state: null,
  currentScreen: null,
  activeModal: null,
};

export function initApp() {
  const state = loadState();
  initRelations(state);
  // 内置角色性别：按玩家性别与性取向动态分配（已有存档沿用其固定分配）
  if (!state.characterGenders) {
    import('./core/gender.js').then((m) => m.assignCharacterGenders(state));
  }
  setAPIConfig(state.settings.api);
  Game.state = state;
  saveState(state);
  applySettings(state);
  bootstrap();
}

export function applySettings(state) {
  const s = state.settings;
  document.documentElement.style.setProperty('--font-size', (s.fontSize || 16) + 'px');
  const [top, bottom] = bgPair(s.bg);
  document.documentElement.style.setProperty('--bg-top', top);
  document.documentElement.style.setProperty('--bg-bottom', bottom);
  document.documentElement.style.setProperty('--bg-gradient', `linear-gradient(180deg, ${top} 0%, ${bottom} 100%)`);
}

export const BG_PALETTE = [
  ['default', '裸粉', '#FFE2E1'],
  ['lightPurple', '浅紫', '#B1B1E8'],
  ['mint', '薄荷奶油绿', '#F5FFFA'],
  ['pearlGray', '珍珠灰', '#E2E2E2'],
  ['starPurple', '星光紫', '#FFF0F5'],
  ['vanilla', '香草奶油白', '#DFF5E6'],
  ['cornelPink', '柔和茱萸粉', '#EDD1D8'],
  ['aliceBlue', '爱丽丝蓝', '#F0F8FF'],
  ['lilac', '丁香紫', '#E6E6FA'],
  ['peachPink', '蜜桃粉', '#FFDAB9'],
  ['mistRose', '迷雾玫瑰', '#FFE4E1'],
  ['powderBlue', '粉末蓝', '#B0E0E6'],
  ['melonGreen', '蜜瓜绿', '#F0FFF0'],
  ['cornsilk', '玉米丝黄', '#FFF8DC'],
  ['thistle', '蓟花灰紫', '#D8BFD8'],
  ['moonGray', '月白柔灰', '#F7F6F3'],
  ['oatWhite', '燕麦奶白', '#EDEAE3'],
  ['warmMilkTea', '暖灰奶茶', '#DCD8D0'],
  ['hazeGray', '雾霾淡灰', '#CECBC4'],
  ['smokeGray', '冷烟灰', '#BDBAB3'],
  ['minimalWhite', '极简灰白', '#FAFAF8'],
];

export function bgPair(key) {
  const found = BG_PALETTE.find(([k]) => k === key);
  const hex = found ? found[2] : BG_PALETTE[0][2];
  const top = hex;
  const bottom = shadeHex(hex, -12);
  return [top, bottom];
}

function shadeHex(hex, pct) {
  const n = parseInt(hex.replace('#', ''), 16);
  let r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
  r = Math.max(0, Math.min(255, Math.round(r + (pct / 100) * 255)));
  g = Math.max(0, Math.min(255, Math.round(g + (pct / 100) * 255)));
  b = Math.max(0, Math.min(255, Math.round(b + (pct / 100) * 255)));
  return `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1)}`;
}

export function render(html) {
  app.innerHTML = html;
  return app;
}

export function mount(el) {
  app.innerHTML = '';
  app.appendChild(el);
}

function bootstrap() {
  const state = Game.state;
  // 每次进入模拟器之后，都会播放开场动画，动画完毕进入大厅
  if (!state.flags.disclaimer) {
    import('./ui/screens.js').then((m) => m.showDisclaimer());
  } else {
    import('./ui/screens.js').then((m) => m.playOpening());
  }
}

export function navigate(screen, ...args) {
  Game.currentScreen = screen;
  closeModal();
  const mods = {
    lobby: () => import('./ui/lobby.js').then((m) => m.renderLobby(...args)),
    creation: () => import('./ui/creation.js').then((m) => m.renderCreation(...args)),
    game: () => import('./ui/gameUI.js').then((m) => m.renderGameUI(...args)),
  };
  if (mods[screen]) mods[screen]();
}

export function openModal(contentNode, opts = {}) {
  closeModal();
  const overlay = document.createElement('div');
  overlay.className = 'modal-overlay' + (opts.noClose ? ' no-close' : '');
  overlay.style.zIndex = opts.zIndex || 100;
  const card = document.createElement('div');
  card.className = 'modal-card';
  if (opts.width) card.style.width = opts.width;
  if (opts.onClose) overlay._onClose = opts.onClose;
  if (!opts.noClose) {
    overlay.addEventListener('click', (e) => {
      if (e.target === overlay) closeModal();
    });
  }
  if (typeof contentNode === 'string') card.innerHTML = contentNode;
  else card.appendChild(contentNode);
  if (!opts.noClose && !card.querySelector('.panel-x, .modal-close')) {
    const x = document.createElement('button');
    x.className = 'modal-close modal-x-float';
    x.textContent = '×';
    x.setAttribute('aria-label', '关闭');
    x.addEventListener('click', (e) => {
      e.stopPropagation();
      closeModal();
    });
    card.appendChild(x);
  }
  overlay.appendChild(card);
  document.body.appendChild(overlay);
  Game.activeModal = { overlay, card, opts };
  return { overlay, card };
}

export function closeModal() {
  if (Game.activeModal) {
    const m = Game.activeModal;
    if (m.opts && m.opts.onClose) m.opts.onClose();
    if (m.overlay && m.overlay.parentNode) m.overlay.parentNode.removeChild(m.overlay);
    Game.activeModal = null;
  }
}

const injectedStyles = new Set();
export function injectStyle(css, id) {
  if (injectedStyles.has(id)) return;
  injectedStyles.add(id);
  const el = document.createElement('style');
  el.id = 'inject-' + id;
  el.textContent = css;
  document.head.appendChild(el);
}

export function toast(msg, ms = 2200) {
  const el = document.createElement('div');
  el.className = 'toast';
  el.textContent = msg;
  document.body.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity 0.3s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 300);
  }, ms);
}

export function notify(title, msg) {
  const el = document.createElement('div');
  el.className = 'notif-banner';
  el.innerHTML = `<span class="tag">${title}</span><span>${msg}</span>`;
  document.body.appendChild(el);
  setTimeout(() => {
    el.style.transition = 'opacity 0.3s';
    el.style.opacity = '0';
    setTimeout(() => el.remove(), 400);
  }, 3000);
}

window.Game = Game;
window.addEventListener('DOMContentLoaded', initApp);
window.addEventListener('cijian-ach', (e) => {
  (e.detail || []).forEach((a) => notify('成就解锁', a.name));
});
