import { CHARACTERS } from '../data/characters.js';

export const SAVE_VERSION = 3;

export function createDefaultState() {
  return {
    version: SAVE_VERSION,
    createdAt: Date.now(),
    flags: {
      disclaimer: false,
      opened: false,
    },
    settings: {
      bg: 'default',
      sidebarBg: 'default',
      customBg: null,
      customSidebarBg: null,
      fontFamily: 'system',
      fontSize: 16,
      rewind: false,
      cheat: false,
      api: { url: '', key: '', model: '', connected: false },
    },
    player: {
      name: '蒋华',
      nickname: '小华',
      gender: '男',
      age: 14,
      orientation: '异性恋',
      skin: '中性',
      height: 165,
      figure: '纤细',
      aura: '清冷',
      hair: { bangs: '空气刘海', back: '直发', bangsLen: '中', backLen: '及肩', color: '#4A3B32', gradient: null },
      eyes: '#5B4A3F',
      marks: [],
      freckles: 0,
      attributes: { con: 5, int: 5, per: 5, cha: 5, luk: 5 },
      talents: [],
      skills: {},
      stats: { hp: 100, ep: 85, sat: 80, cln: 90, sta: 80, stress: 20 },
      mood: 60,
      health: '健康',
      morality: 60,
      money: 0,
      rep: { total: 0, school: 0, community: 0 },
      crime: 0,
      faith: 0,
    },
    time: {
      day: 1,
      date: { year: 2024, month: 9, day: 1 },
      hour: 18,
      minute: 30,
    },
    weather: '晴',
    location: 'home',
    relations: {},
    inventory: [],
    phone: {
      qq: { id: '13702149922', nick: '小华', chats: {}, unread: {} },
      forumNick: '云栖新芽',
      email: 'xiaohua@yunqimail.cn',
      contacts: [],
      forum: { rep: 0, posts: [], saved: [], comments: {} },
      diary: [],
      creations: [],
      tarot: { lastDate: '', history: [] },
      calendar: { events: [] },
      wallet: { balance: 0, records: [] },
      mailbox: { emails: [], unread: 0 },
      wallpaper: 'default',
      fontScale: 15,
      notifications: [],
      layout: [],
    },
    journal: {
      unlockedAch: [],      achProgress: {},
      visitedPlaces: [],
      exploredStreets: [],
      tasks: [],
      completedTasks: [],
      memory: [],
      dayLog: [],
      semesterProgress: { term: 1, total: 6 },
      workCount: 0,
      workTypes: [],
      earned: 0,
      crimePeak: 0,
      grayTrades: 0,
      convenienceNight: false,
    },
    mods: [],
    narrative: {
      sceneId: 'initial',
      step: 0,
      history: [],
      choices: [],
      flag: {},
      lastAutoSave: { day: 0 },
    },
    buffs: [],
    createdChars: [],
  };
}

export function initRelations(state) {
  const rels = state.relations;
  for (const c of CHARACTERS) {
    if (!rels[c.id]) {
      rels[c.id] = { f: 0, l: 0, h: 0, met: false, dayMet: 0, talkCount: 0, isGuardian: c.type === 'guardian' };
    }
  }
}

export function getPlayer(state) { return state.player; }
export function getSettings(state) { return state.settings; }
export function getTime(state) { return state.time; }
export function getRelation(state, charId) {
  if (!state.relations[charId]) {
    state.relations[charId] = { f: 0, l: 0, h: 0, met: false, dayMet: 0, talkCount: 0 };
  }
  return state.relations[charId];
}

export function changeRelation(state, charId, delta, type = 'f') {
  const r = getRelation(state, charId);
  if (type === 'f') r.f = Math.max(0, Math.min(100, r.f + delta));
  if (type === 'l') r.l = Math.max(0, Math.min(100, r.l + delta));
  if (type === 'h') r.h = Math.max(0, Math.min(100, r.h + delta));
  return r;
}

export function addMoney(state, amount, label = '') {
  state.player.money = Math.max(0, state.player.money + amount);
  if (amount !== 0) {
    state.phone.wallet.records.unshift({
      id: Date.now() + Math.random().toString(36).slice(2, 6),
      name: label || (amount > 0 ? '收入' : '支出'),
      amount,
      ts: Date.now(),
      gameTime: `${formatGameDate(state.time.date)} ${state.time.hour}:${String(state.time.minute).padStart(2, '0')}`,
    });
  }
  return state.player.money;
}

export function addItem(state, itemId, qty = 1) {
  const stack = state.inventory.find((i) => i.id === itemId);
  if (stack) stack.qty = (stack.qty || 1) + qty;
  else state.inventory.push({ id: itemId, qty });
}

export function removeItem(state, itemId, qty = 1) {
  const idx = state.inventory.findIndex((i) => i.id === itemId);
  if (idx === -1) return false;
  state.inventory[idx].qty -= qty;
  if (state.inventory[idx].qty <= 0) state.inventory.splice(idx, 1);
  return true;
}

export function getCreatedChars(state) {
  return state.createdChars || [];
}

export function addCreatedChar(state, char) {
  if (!state.createdChars) state.createdChars = [];
  const existing = state.createdChars.find((c) => c.id === char.id);
  if (existing) return false;
  state.createdChars.push(char);
  if (!state.relations[char.id]) {
    state.relations[char.id] = { f: 0, l: 0, h: 0, met: false, dayMet: 0, talkCount: 0 };
  }
  return true;
}

export function formatGameDate(date) {
  return `${date.year}年${date.month}月${date.day}日`;
}
