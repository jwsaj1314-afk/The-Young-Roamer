import { INITIAL_STORY } from '../data/misc.js';
import { getTime } from './state.js';
import { advanceTime } from './time.js';
import { isAIReady, chat, buildSystemPrompt } from './ai.js';

export const SCENES = {
  initial: {
    id: 'initial',
    title: '初来乍到',
    text: INITIAL_STORY.content,
    options: [
      { id: 'organize', text: '收拾行李，熟悉自己的房间' },
      { id: 'kitchen', text: '下楼看看厨房里有什么吃的' },
      { id: 'think', text: '坐在床边发一会儿呆' },
    ],
  },
  organize: {
    id: 'organize',
    title: '安顿',
    text: `你把行李箱靠墙放好，拉开衣柜，把仅有的几件衣服一件件挂好。书桌上摆着崭新的文具和课本，码得整整齐齐——是许临安提前给你准备的。

整理完房间，你在书桌前坐了一会儿。窗外天色渐渐暗下来，路灯亮了，把街道染成温暖的橘色。楼下传来冰箱运转的细微声响，整栋房子只有你一个人。

手机震了一下，是福利院的社工发来的消息："到了吗？住得还习惯吗？许先生明天下午回来，有什么事可以打他电话。"

你回了一句"到了，挺好的"，然后放下手机。明天就是开学的日子了。`,
    options: [
      { id: 'sleep', text: '洗漱后早点休息，明天还要上学' },
      { id: 'explore', text: '趁晚上在附近街道走一走' },
    ],
  },
  kitchen: {
    id: 'kitchen',
    title: '夜宵',
    text: `厨房收拾得很干净。冰箱里有牛奶、鸡蛋和几样蔬菜，柜子里有面条和调味料。你给自己煮了一碗面，坐在餐桌前慢慢吃完。

暖意从胃里蔓延开。这座陌生的城市，这栋安静的房子，忽然有了一点"家"的味道。你收拾好碗筷，在冰箱门上看到一张便利贴，字迹和玄关那张纸条一样：

【纸条】东西都可以用，别拘束。冰箱里那盒草莓是给你留的。——许【/纸条】

你愣了一下，打开冰箱，果然看到一盒红彤彤的草莓。你捏起一颗放进嘴里，酸酸甜甜的。`,
    options: [
      { id: 'sleep', text: '洗漱后早点休息，明天还要上学' },
      { id: 'explore', text: '趁晚上在附近街道走一走' },
    ],
  },
  think: {
    id: 'think',
    title: '静坐',
    text: `你坐在床边，望着窗外的路灯发呆。福利院的记忆像旧照片一样一帧帧翻过——那些孩子们的笑声、食堂的味道、陈院长总爱说"要争气"。

来到这里，一切都是新的。新的房间，新的学校，新的家人——虽然那个叫许临安的人还没有回来。

你把口袋里那张写着电话号码的纸条又拿出来看了一遍，想了想，还是把它折好，放回口袋。不着急，明天总会见面的。

夜风从窗缝里钻进来，带着一点草木的凉意。你拉上窗帘，准备休息。`,
    options: [
      { id: 'sleep', text: '洗漱后早点休息，明天还要上学' },
      { id: 'explore', text: '趁晚上在附近街道走一走' },
    ],
  },
  sleep: {
    id: 'sleep',
    title: '一夜',
    text: `你洗漱完毕，躺进新铺好的被子里。被子有阳光晒过的味道，软软的，带着一点陌生又安心的气息。

手机屏幕亮了一下，是福利院群里发的消息，你划掉，没有看。你望着天花板，听着窗外偶尔驶过的汽车声，慢慢睡着了。

第二天早上，是被闹钟叫醒的。窗外阳光正好，楼下隐约传来有人走动的声音，还有煎鸡蛋的香气飘上来。你想起来——今天，许临安应该回来了。`,
    options: [
      { id: 'morning', text: '起床下楼' },
    ],
  },
  explore: {
    id: 'explore',
    title: '夜游',
    text: `你披了件外套出门。云栖市的夜晚很安静，路灯把梧桐树叶的影子投在地上。你在门口站了一会儿，看到隔壁院子亮着灯，隐约传来电视声。

你沿着街道慢慢走，经过一家还没打烊的便利店，店员隔着玻璃冲你点了点头。再往前走，是一条种满香樟的小路，空气里有淡淡的花香。

你走了一圈回到门口，心情莫名平静了一些。这座城市好像没有想象中那么陌生。

你回屋洗漱，躺下时想：明天，就是新生活的开始了。`,
    options: [
      { id: 'morning', text: '第二天清晨，下楼看看' },
    ],
  },
  morning: {
    id: 'morning',
    title: '清晨',
    text: `你踩着拖鞋下楼，一个身影正站在厨房里，背对着你，往盘子里盛煎蛋。听到脚步声，他/她回过头，露出一个温和的笑容：

「醒了？正好，饭做好了。我姓许，许临安。」

他/她把早餐端上桌：煎蛋、牛奶、几片烤好的吐司。阳光从窗户照进来，落在餐桌上。

「吃完我送你去学校。对了，」他/她顿了顿，从口袋里掏出一部手机推到你面前，「给你办了手机卡，电话和微信都存好了。有事随时找我。」

这大概就是"家人"的感觉。你低下头，喝了一口温热的牛奶。`,
    options: [
      { id: 'school', text: '吃完早餐，去学校报到' },
    ],
  },
  school: {
    id: 'school',
    title: '入学',
    text: `云栖市第一中学的大门在你面前展开。开学季的校园里人声鼎沸，新生们三三两两聚在校门口。

 许临安在校门口停下车，帮你拎下书包，又理了理你的衣领：「报道的地方在教学楼一楼大厅，班主任姓什么我看一眼……」他/她翻着手机，「找到了，初一（1）班，班主任到时候会点名。放学我来接你。」

你点了点头，背着新书包走进校园。阳光落在梧桐树梢，教学楼上挂着横幅——"明德、笃学、慎思、力行"。

这是你在云栖市的第一天。新的班级、新的同学、新的人生，都在等你。`,
    options: [
      { id: 'school-start', text: '前往教学楼报到' },
    ],
  },
  schoolStart: {
    id: 'schoolStart',
    title: '报到',
    text: `教学楼一楼大厅排着长队，你跟着人流往前走。登记完名字，领到了课程表、校服和宿舍钥匙——虽然你不住校，校服还是要穿的。

「蒋华？」一个声音从旁边传来。你转头，看见一个穿着干净校服的男生站在你旁边，冲你弯了弯眼睛：「我是初一（2）班的江望，就住你家隔壁那条街。以后可以一起上学。」

这是你在云栖市交到的第一个朋友。

接下来的日子，你慢慢适应了这里的一切：每天早起上学，放学回家，和许临安一起吃晚饭，周末和江望去打篮球。这座城市开始从陌生变得熟悉。`,
    options: [
      { id: 'free', text: '开始你的云栖生活' },
    ],
  },
  free: {
    id: 'free',
    title: '自由生活',
    text: `你的云栖生活正式开始了。每一天都有新的可能：去上学、去逛街、去打工、去认识新的人……
也可以打开手机，和朋友聊聊天，写写日记，或者找一处喜欢的地方发呆。

往后的日子，由你来书写。`,
    options: [],
  },
};

export function startGame(state) {
  state.narrative.sceneId = 'initial';
  state.narrative.history = [];
  state.flags.opened = true;
}

export function getScene(state) {
  return SCENES[state.narrative.sceneId] || SCENES.initial;
}

export function advanceScene(state, choiceId) {
  const scene = SCENES[state.narrative.sceneId];
  pushHistory(state, scene.title, scene.text);
  recordMemory(state, `【${scene.title}】${scene.text.replace(/\s+/g, ' ').slice(0, 120)}`);
  if (choiceId === 'sleep') {
    state.narrative.sceneId = 'sleep';
    advanceTime(state, 10 * 60);
  } else if (choiceId === 'explore') {
    state.narrative.sceneId = 'explore';
    advanceTime(state, 60);
  } else if (choiceId === 'morning') {
    state.narrative.sceneId = 'morning';
  } else if (choiceId === 'school-start') {
    state.narrative.sceneId = 'schoolStart';
  } else if (choiceId === 'school') {
    state.narrative.sceneId = 'school';
  } else if (choiceId === 'free') {
    state.narrative.sceneId = 'free';
  } else if (SCENES[choiceId]) {
    state.narrative.sceneId = choiceId;
  }
  return getScene(state);
}

export function pushHistory(state, title, text) {
  state.narrative.history.push({
    id: Date.now() + Math.random().toString(36).slice(2, 6),
    title,
    text,
    ts: Date.now(),
    day: state.time.day,
  });
  if (state.narrative.history.length > 200) state.narrative.history.shift();
}

export function recordMemory(state, text) {
  state.journal.memory.unshift({
    id: Date.now() + Math.random().toString(36).slice(2, 6),
    text,
    ts: Date.now(),
    day: state.time.day,
    timeText: `${state.time.date.year}-${state.time.date.month}-${state.time.date.day} 第${state.time.day}天`,
  });
}

export async function aiGenerateNarrative(state, userInput) {
  if (!isAIReady()) {
    return '（尚未配置AI模型，此处为演示文本。请在设置中完成API配置以启用AI生成剧情。）';
  }
  const sys = buildSystemPrompt(state, userInput);
  const msgs = [
    { role: 'system', content: sys.system },
    { role: 'user', content: userInput || '继续推进剧情，描述接下来的场景与人物互动。' },
  ];
  try {
    return await chat(msgs, { temperature: 0.9, max_tokens: 500 });
  } catch (e) {
    return `（AI生成失败：${e.message}）`;
  }
}
