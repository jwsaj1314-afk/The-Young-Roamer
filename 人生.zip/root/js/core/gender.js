import { CHARACTERS } from '../data/characters.js';

// 简单的可复现随机数生成器（mulberry32），同一种子下角色性别分布固定
function mulberry32(seed) {
  let a = seed >>> 0;
  return function () {
    a |= 0; a = (a + 0x6D2B79F5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// 玩家性别归一化：双性偏男视为男、双性偏女视为女、无性随机
export function isPlayerMale(state) {
  const g = state.player.gender;
  if (g === '男' || g === '双性偏男') return true;
  if (g === '女' || g === '双性偏女') return false;
  const seed = state.characterSeed || state.createdAt || 1;
  return mulberry32(seed)(0.5) < 0.5;
}

export function playerOrientation(state) {
  return state.player.orientation || '异性恋';
}

function pickGender(rng, pMale, orient) {
  if (orient === '异性恋') return rng() < 0.8 ? (pMale ? '女' : '男') : (pMale ? '男' : '女');
  if (orient === '同性恋') return rng() < 0.8 ? (pMale ? '男' : '女') : (pMale ? '女' : '男');
  return rng() < 0.5 ? '男' : '女';
}

// 许临安（核心角色）性别规则
function guardianGender(pMale, orient) {
  if (orient === '异性恋') return pMale ? '女' : '男';
  if (orient === '同性恋') return pMale ? '男' : '女';
  return Math.random() < 0.5 ? '男' : '女';
}

// 生成并保存所有内置角色的性别分配
export function assignCharacterGenders(state) {
  if (!state.characterSeed) state.characterSeed = (Date.now() % 0x7fffffff) || 987654;
  const rng = mulberry32(state.characterSeed);
  const pMale = isPlayerMale(state);
  const orient = playerOrientation(state);
  const map = {};
  const isCore = (id) => id === 'xulinan';

  CHARACTERS.forEach((c) => {
    if (isCore(c.id)) {
      map[c.id] = guardianGender(pMale, orient);
    } else {
      map[c.id] = pickGender(rng, pMale, orient);
    }
  });

  // 应用到角色数据（性别字段 + 显示用代词），并写回存档
  state.characterGenders = map;
  CHARACTERS.forEach((c) => {
    c.gender = map[c.id];
    c.displayGender = map[c.id];
    c.pronoun = pronoun(map[c.id]);
  });
  return map;
}

// 只读展示：获取某角色的性别
export function charGender(state, charId) {
  return (state.characterGenders && state.characterGenders[charId]) || '';
}

export function pronoun(g) {
  if (g === '男') return '他';
  if (g === '女') return '她';
  return 'TA';
}

// 将文本中的中性代词 "ta"/"他/她" 按性别替换为实际代词
export function gendText(state, charId, text) {
  if (!text) return text;
  const g = charGender(state, charId);
  if (!g) return text;
  const he = pronoun(g);
  return text.replace(/他\/她/g, he).replace(/TA/g, he).replace(/\bta\b/g, he);
}
