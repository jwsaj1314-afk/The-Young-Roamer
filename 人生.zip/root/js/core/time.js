import { getPeriod, getSeason, chance, rand, pick, clamp } from './utils.js';

const DAYS_IN_MONTH = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

export function advanceTime(state, minutes) {
  const t = state.time;
  let remaining = minutes;
  while (remaining > 0) {
    const toHourEnd = 60 - t.minute;
    const step = Math.min(remaining, toHourEnd);
    t.minute += step;
    remaining -= step;
    if (t.minute >= 60) {
      t.minute = 0;
      t.hour++;
    }
    if (t.hour >= 24) {
      t.hour = 0;
      rollDay(state);
    }
  }
  updateWeather(state);
}

function rollDay(state) {
  const t = state.time;
  t.day++;
  const d = t.date;
  d.day++;
  if (d.day > DAYS_IN_MONTH[d.month - 1]) {
    d.day = 1;
    d.month++;
    if (d.month > 12) {
      d.month = 1;
      d.year++;
    }
  }
  state.weather = rollWeather(state);
  dailyReset(state);
  checkAgeUp(state);
  checkAutoSave(state);
  if (t.day % 2 === 0) {
    state.narrative.lastAutoSave.day = t.day;
  }
}

function rollWeather(state) {
  const season = getSeason(state.time.date.month);
  const table = {
    '春': ['晴', '晴', '多云', '多云', '阴', '小雨', '小雨', '雷阵雨'],
    '夏': ['晴', '晴', '晴', '多云', '阴', '小雨', '雷阵雨', '雷阵雨'],
    '秋': ['晴', '晴', '多云', '多云', '阴', '小雨', '小雨', '晴'],
    '冬': ['晴', '多云', '多云', '阴', '小雨', '雪', '雪', '晴'],
  };
  return pick(table[season] || table['春']);
}

function updateWeather(state) {
  // 少量概率随机微调当前天气，保持天气变化的自然感
  if (chance(15)) {
    state.weather = rollWeather(state);
  }
}

function dailyReset(state) {
  const p = state.player;
  const s = p.stats;
  const sleepHours = 8;
  p.stats.ep = clamp(s.ep + sleepHours * (8 + p.attributes.con * 0.3), 0, 100);
  p.stats.sta = clamp(s.sta + sleepHours * (5 + p.attributes.con * 0.5), 0, 100);
  p.stats.hp = clamp(s.hp + sleepHours * (3 + p.attributes.con * 0.5), 0, 100);
  p.stats.stress = clamp(s.stress - sleepHours * 3, 0, 100);
  p.mood = clamp(p.mood + 2, 0, 100);
  // 每日杂项刷新
  state.phone.tarot.dailyUsed = false;
}

function checkAgeUp(state) {
  const t = state.time;
  const p = state.player;
  const birthday = { 9: 1 };
  if (t.date.month === 9 && t.date.day === 1) {
    const newAge = 14 + Math.floor((t.day - 1) / 365);
    if (newAge > p.age) {
      p.age = newAge;
      state.narrative.history.push({ type: 'system', text: `今天是你${newAge}岁的生日。` });
    }
  }
}

function checkAutoSave(state) {
  if (state.time.day % 2 === 0) {
    import('./storage.js').then((m) => m.autoSave(state));
  }
}

export function updateHourlyStats(state) {
  const p = state.player;
  const s = p.stats;
  s.ep = clamp(s.ep - 2, 0, 200);
  s.sat = clamp(s.sat - 1.5, 0, 100);
  s.cln = clamp(s.cln - 0.3, 0, 100);
  s.sta = clamp(s.sta - 0.5, 0, 200);
  s.stress = clamp(s.stress + 0.5, 0, 100);
  if (s.sat < 30) p.mood = clamp(p.mood - 1, 0, 100);
  if (s.sat < 10) s.hp = clamp(s.hp - 1, 0, 200);
  if (s.cln < 10 && chance(5)) p.health = '患病';
}

export function getInfoBar(state) {
  const t = state.time;
  const d = t.date;
  const period = getPeriod(t.hour);
  const season = getSeason(d.month);
  const loc = getPlaceName(state.location);
  return {
    date: `${d.year}年${d.month}月${d.day}日`,
    month: d.month,
    day: d.day,
    period,
    season,
    weather: state.weather,
    location: loc,
    shortLocation: getShortPlaceName(state.location),
    money: state.player.money,
  };
}

function getShortPlaceName(id) {
  const map = {
    home: '云栖市-家', school: '云栖市-学校', mall: '云栖市-购物中心',
    convenience: '云栖市-便利店', stationery: '云栖市-文具店', flower: '云栖市-花店',
    bakery: '云栖市-面包房', coffee: '云栖市-咖啡店', bookstore: '云栖市-书店',
    pharmacy: '云栖市-药房', foodstreet: '云栖市-食集', supermarket: '云栖市-超市',
    library: '云栖市-图书馆', church: '云栖市-教堂', centralpark: '云栖市-中央公园',
    riverside: '云栖市-南河步道', linhai: '云栖市-林海', jinghu: '云栖市-镜湖',
    goldbeach: '云栖市-金沙滩', port: '云栖市-云栖港',
  };
  return map[id] || id;
}

function getPlaceName(id) {
  const map = {
    home: '云栖市·家',
    school: '云栖市第一中学',
    mall: '云栖市·云栖汇购物中心',
    convenience: '云栖市·全天便利',
    stationery: '云栖市·纸墨时光',
    flower: '云栖市·朝露花坊',
    bakery: '云栖市·麦香晨光',
    coffee: '云栖市·街角咖啡',
    bookstore: '云栖市·纸上云栖',
    pharmacy: '云栖市·仁心药房',
    foodstreet: '云栖市·云栖食集',
    supermarket: '云栖市·大润发',
    library: '云栖市·市立图书馆',
    church: '云栖市·圣心大教堂',
    centralpark: '云栖市·中央公园',
    riverside: '云栖市·南河滨水步道',
    linhai: '云栖市·云栖林海',
    jinghu: '云栖市·镜湖',
    goldbeach: '云栖市·金沙滩',
    port: '云栖市·云栖港',
  };
  return map[id] || id;
}

export function getTodayTasks(state) {
  const t = state.time;
  const tasks = [];
  const weekday = ['日', '一', '二', '三', '四', '五', '六'][new Date(t.date.year, t.date.month - 1, t.date.day).getDay()];
  if (weekday !== '六' && weekday !== '日') {
    tasks.push('去学校上课（8:00-16:00）');
    tasks.push('完成今日作业');
  }
  tasks.push('注意饱腹度与精力');
  return tasks;
}

export function getTimelineEvents(state) {
  const t = state.time;
  return {
    today: `${t.date.year}-${t.date.month}-${t.date.day}`,
    day: t.day,
    period: getPeriod(t.hour),
  };
}
