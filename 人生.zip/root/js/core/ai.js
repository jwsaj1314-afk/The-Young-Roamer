import { CHARACTERS } from '../data/characters.js';

let config = { url: '', key: '', model: '', connected: false };

export function setAPIConfig(cfg) {
  config = cfg;
}

export function getAPIConfig() {
  return { ...config };
}

export function isAIReady() {
  return config.connected && config.url && config.key && config.model;
}

function normalizeUrl(url) {
  let u = url.trim();
  if (!u) return '';
  u = u.replace(/\/+$/, '');
  if (/\/chat\/completions$/.test(u)) return u;
  if (/\/completions$/.test(u)) return u;
  if (/\/v1$/.test(u)) return u + '/chat/completions';
  if (/\/v1\//.test(u)) return u.replace(/\/v1\/.*$/, '/v1/chat/completions');
  if (/\/api(\/|$)/.test(u)) return u + '/v1/chat/completions';
  return u + '/v1/chat/completions';
}

function httpHint(status) {
  if (status === 401) return '401：API Key 无效或无权限，请检查 Key';
  if (status === 403) return '403：访问被拒绝，请检查 Key 或套餐权限';
  if (status === 404) return '404：接口地址不存在，请确认 API 地址是否正确';
  if (status === 429) return '429：请求过于频繁，请稍后重试';
  if (status === 500) return '500：服务端内部错误，请稍后重试';
  if (status === 502 || status === 503 || status === 504) return `${status}：服务暂不可用，请检查 API 地址是否正确，或稍后重试`;
  return `HTTP ${status}`;
}

async function fetchWithTimeout(url, options, ms = 20000) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), ms);
  try {
    return await fetch(url, { ...options, signal: ctrl.signal });
  } catch (e) {
    if (e && e.name === 'AbortError') throw new Error('请求超时，请检查 API 地址与网络');
    throw e;
  } finally {
    clearTimeout(timer);
  }
}

export async function testConnection() {
  if (!config.url || !config.key) return { ok: false, msg: '请先填写 URL 与 Key' };
  try {
    const res = await fetchWithTimeout(normalizeUrl(config.url), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${config.key}`,
      },
      body: JSON.stringify({
        model: config.model || 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: '你好' }],
        max_tokens: 5,
      }),
    });
    if (!res.ok) {
      const txt = await res.text();
      const body = (txt || '').slice(0, 120).replace(/\n/g, ' ');
      return { ok: false, msg: `${httpHint(res.status)}${body ? ` · ${body}` : ''}` };
    }
    return { ok: true };
  } catch (e) {
    return { ok: false, msg: `连接失败：${e.message}` };
  }
}

export async function fetchModels() {
  if (!config.url || !config.key) return [];
  let base = config.url.trim().replace(/\/+$/, '');
  if (base.endsWith('/v1')) base = base.slice(0, -3);
  if (base.endsWith('/chat/completions')) base = base.replace('/chat/completions', '');
  const res = await fetch(base + '/models', {
    headers: { 'Authorization': `Bearer ${config.key}` },
  });
  if (!res.ok) return [];
  const data = await res.json();
  return (data.data || []).map((m) => m.id);
}

export async function chat(messages, opts = {}) {
  if (!isAIReady()) throw new Error('AI 未配置');
  const res = await fetchWithTimeout(normalizeUrl(config.url), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${config.key}`,
    },
    body: JSON.stringify({
      model: config.model,
      messages,
      temperature: opts.temperature ?? 0.8,
      max_tokens: opts.max_tokens ?? 800,
    }),
  });
  if (!res.ok) {
    const txt = await res.text();
    throw new Error(`${httpHint(res.status)} · ${(txt || '').slice(0, 120).replace(/\n/g, ' ')}`);
  }
  const data = await res.json();
  return data.choices?.[0]?.message?.content || '';
}

export function buildSystemPrompt(gameState, context) {
  const p = gameState.player;
  const t = gameState.time;
  const metChars = Object.entries(gameState.relations)
    .filter(([, r]) => r.met)
    .map(([id]) => id);
  const charMap = (() => {
    const map = {};
    (window.Game && window.Game.state ? [...CHARACTERS, ...(window.Game.state.createdChars || [])] : CHARACTERS).forEach((c) => { map[c.id] = c.name; });
    return map;
  })();
  const charName = (id) => charMap[id] || id;
  return {
    system: `你是《此间少年行》的文字冒险游戏叙事引擎。云栖市是一座温和的沿海城市，你正以${p.name}（${p.nickname}，${p.age}岁，${p.gender}）的身份生活。
当前时间：${t.date.year}年${t.date.month}月${t.date.day}日 第${t.day}天，${t.hour}点${t.minute}分，天气${gameState.weather}，位置：${gameState.location}。
玩家五维：体质${p.attributes.con} 智力${p.attributes.int} 感知${p.attributes.per} 魅力${p.attributes.cha} 运气${p.attributes.luk}。
已认识角色：${metChars.length ? metChars.map(charName).join('、') : '暂无'}。
请用简体中文、第二人称"你"叙述，文字优美、贴近INS韩系治愈风格，控制在120-220字之间。
格式要求（重要）：
- 角色说出口的话语（对白），必须用「」包裹，例如：「放学一起走吗？」
- 剧情中的小纸条用【纸条】与【/纸条】包裹；情书用【情书】与【/情书】；信件用【信】与【/信】；书签用【书签】与【/书签】；花束用【花束】与【/花束】。
- 无此类内容时不要使用这些标记。
- 若剧情引入了新的次要角色，请给出其姓名（2-4字中文名），并尽量说明其身份。` + (context ? `\n额外情境：${context}` : ''),
  };
}
