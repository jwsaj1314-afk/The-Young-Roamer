// 成就判定引擎：根据当前状态评估并解锁满足条件的成就
import { ACHIEVEMENTS } from '../data/achievements.js';

const SKILL_CAT = {
  'liberal-arts': 'academic', 'science': 'academic', 'foreign-lang': 'academic',
  'painting': 'art', 'instrument': 'art', 'dance': 'art', 'acting': 'art',
  'photography': 'art', 'screenwriting': 'art', 'composition': 'art', 'perfume': 'art',
  'cooking': 'practical', 'fight': 'practical', 'driving': 'practical',
  'law': 'practical', 'medicine': 'practical', 'new-media': 'practical',
  'leadership': 'social', 'friendliness': 'social', 'persuasion': 'social', 'insight': 'social',
};

const PUBLIC_FACILITIES = ['library', 'museum', 'hospital', 'centralpark', 'church', 'riverside'];
const LANDMARKS = ['church', 'theater', 'museum', 'stadium', 'mall', 'library', 'school'];

function skillValues(s) {
  return Object.values(s.player.skills || {}).filter((v) => v > 0);
}

function skillByCat(s, cat) {
  return Object.entries(s.player.skills || {})
    .filter(([k, v]) => SKILL_CAT[k] === cat && v > 0)
    .map(([, v]) => v);
}

function maxRelation(s, type) {
  let max = 0;
  for (const r of Object.values(s.relations)) {
    if (type === 'f' && r.f > max) max = r.f;
    if (type === 'l' && r.l > max) max = r.l;
  }
  return max;
}

function countRelations(s, type, min) {
  let n = 0;
  for (const r of Object.values(s.relations)) {
    if (type === 'f' && r.f >= min) n++;
    if (type === 'l' && r.l >= min) n++;
    if (type === 'met' && r.met) n++;
  }
  return n;
}

function visit(s, id) {
  return (s.journal.visitedPlaces || []).includes(id);
}

function rule(id) {
  switch (id) {
    case 1: return (s) => s.time.day >= 2;
    case 2: return (s) => s.time.day >= 30;
    case 3: return (s) => s.time.day >= 100;
    case 4: return (s) => s.player.age >= 15;
    case 10: return (s) => s.player.age >= 18;
    case 17: return (s) => (s.player.skills['liberal-arts'] || 0) >= 6;
    case 18: return (s) => (s.player.skills['science'] || 0) >= 6;
    case 19: return (s) => (s.player.skills['foreign-lang'] || 0) >= 6;
    case 23: return (s) => skillValues(s).some((v) => v >= 2);
    case 24: return (s) => skillValues(s).some((v) => v >= 4);
    case 25: return (s) => skillValues(s).some((v) => v >= 6);
    case 26: return (s) => skillValues(s).some((v) => v >= 8);
    case 27: return (s) => skillValues(s).filter((v) => v >= 4).length >= 5;
    case 28: return (s) => skillValues(s).some((v) => v >= 6) && skillValues(s).filter((v) => v >= 4).length >= 3;
    case 29: return (s) => skillValues(s).filter((v) => v >= 6).length >= 3;
    case 30: return (s) => (s.player.skills['liberal-arts'] || 0) >= 6 && (s.player.skills['fight'] || 0) >= 6;
    case 31: return (s) => skillByCat(s, 'art').filter((v) => v >= 5).length >= 2;
    case 32: return (s) => skillByCat(s, 'practical').filter((v) => v >= 5).length >= 2;
    case 33: {
      return (s) => {
        const vals = skillValues(s);
        return vals.length > 0 && vals.reduce((a, b) => a + b, 0) / vals.length >= 5;
      };
    }
    case 35: return (s) => (s.journal.earned || 0) > 0;
    case 36: return (s) => (s.journal.earned || 0) >= 10000;
    case 43: return (s) => maxRelation(s, 'f') >= 20;
    case 44: return (s) => maxRelation(s, 'l') >= 20;
    case 45: {
      return (s) => Object.values(s.relations).some((r) => r.f >= 40 && r.l >= 40);
    }
    case 46: return (s) => countRelations(s, 'f', 50) >= 2;
    case 47: return (s) => countRelations(s, 'l', 30) >= 2;
    case 48: return (s) => maxRelation(s, 'l') >= 50;
    case 51: return (s) => maxRelation(s, 'f') >= 70;
    case 52: return (s) => maxRelation(s, 'f') >= 90;
    case 53: return (s) => maxRelation(s, 'f') >= 100;
    case 54: return (s) => countRelations(s, 'f', 50) >= 5;
    case 55: return (s) => countRelations(s, 'met', 1) >= 8;
    case 59: return (s) => maxRelation(s, 'l') >= 60;
    case 60: return (s) => maxRelation(s, 'l') >= 80;
    case 68: return (s) => s.time.day >= 365;
    case 74: return (s) => (s.player.rep.school || 0) >= 40;
    case 75: return (s) => (s.player.rep.school || 0) >= 70;
    case 76: return (s) => (s.player.rep.community || 0) >= 40;
    case 77: return (s) => (s.player.rep.community || 0) >= 70;
    case 78: return (s) => (s.player.rep.total || 0) >= 50 && (s.player.crime || 0) === 0;
    case 79: return (s) => (s.journal.exploredStreets || []).length >= 6;
    case 80: return (s) => LANDMARKS.filter((id) => visit(s, id)).length >= 5;
    case 81: return (s) => PUBLIC_FACILITIES.every((id) => visit(s, id));
    case 83: return (s) => visit(s, 'linhai');
    case 84: return (s) => visit(s, 'jinghu');
    case 85: return (s) => visit(s, 'goldbeach');
    case 86: return (s) => visit(s, 'port');
    case 91: return (s) => visit(s, 'library');
    case 92: return (s) => visit(s, 'museum');
    case 93: return (s) => visit(s, 'theater');
    case 94: return (s) => visit(s, 'stadium');
    case 95: return (s) => visit(s, 'church');
    case 96: return (s) => visit(s, 'mall');
    case 97: return (s) => visit(s, 'foodstreet');
    case 98: return (s) => !!s.journal.convenienceNight;
    case 129: return (s) => visit(s, 'yeyouchuan');
    case 131: return (s) => (s.journal.grayTrades || 0) >= 3;
    case 133: return (s) => (s.player.crime || 0) >= 30;
    case 134: return (s) => (s.player.crime || 0) >= 50;
    case 135: return (s) => (s.journal.crimePeak || 0) >= 50 && (s.player.crime || 0) < 20;
    case 101: return (s) => (s.journal.workCount || 0) >= 1;
    case 102: return (s) => (s.journal.workCount || 0) >= 50;
    case 103: return (s) => (s.journal.workCount || 0) >= 200;
    case 104: return (s) => (s.journal.workTypes || []).length >= 5;
    case 105: return (s) => (s.journal.workTypes || []).length >= 10;
    case 107: return (s) => skillValues(s).some((v) => v >= 6);
    case 120: return (s) => (s.journal.earned || 0) >= 100000;
    case 121: return (s) => (s.journal.earned || 0) >= 500000;
    case 151: return (s) => (s.player.faith || 0) >= 20;
    case 152: return (s) => (s.player.faith || 0) >= 50;
    case 153: return (s) => (s.player.faith || 0) >= 80;
    case 154: return (s) => (s.player.faith || 0) >= 100;
    case 157: {
      return (s) => {
        const lovers = Object.values(s.relations).filter((r) => r.l >= 60);
        return lovers.length === 1 && (s.journal.endingLoved || s.flags.endingWithLover);
      };
    }
    default: return null;
  }
}

export function checkAchievements(state) {
  const newly = [];
  const unlocked = new Set(state.journal.unlockedAch || []);
  const progress = state.journal.achProgress || (state.journal.achProgress = {});
  for (const a of ACHIEVEMENTS) {
    if (unlocked.has(a.id)) continue;
    if (a.progressTarget) {
      const v = a.id === 102 || a.id === 103 ? (state.journal.workCount || 0) : 0;
      progress[a.id] = v;
    }
    const fn = rule(a.id);
    if (fn && fn(state)) {
      unlocked.add(a.id);
      newly.push(a);
      state.narrative.history.push({ type: 'system', text: `🎉 成就解锁：${a.name}` });
    }
  }
  if (state.player.crime > (state.journal.crimePeak || 0)) {
    state.journal.crimePeak = state.player.crime;
  }
  state.journal.unlockedAch = Array.from(unlocked);
  if (newly.length) {
    state._pendingAch = (state._pendingAch || []).concat(newly);
  }
  return newly;
}
