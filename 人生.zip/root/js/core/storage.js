import { createDefaultState, SAVE_VERSION } from './state.js';
import { clamp } from './utils.js';
import { checkAchievements } from './achievements.js';

const LS_KEY = 'cijian_save_v3';
const AUTO_KEY = 'cijian_autosave_v3';

export function loadState() {
  try {
    const raw = localStorage.getItem(LS_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  const fresh = createDefaultState();
  fresh.flags.disclaimer = localStorage.getItem('cijian_disclaimer') === '1';
  return fresh;
}

export function saveState(state, slot = 'main') {
  try {
    const newly = checkAchievements(state);
    localStorage.setItem(LS_KEY, JSON.stringify(state));
    localStorage.setItem('cijian_disclaimer', state.flags.disclaimer ? '1' : '0');
    if (newly.length) {
      window.dispatchEvent(new CustomEvent('cijian-ach', { detail: newly }));
    }
    return true;
  } catch (e) {
    console.error('save failed', e);
    return false;
  }
}

export function createSaveSlot(id) {
  return {
    id,
    ts: Date.now(),
    state: null,
    summary: '',
  };
}

export function getSlots() {
  const slots = [];
  for (let i = 1; i <= 20; i++) {
    try {
      const raw = localStorage.getItem(`cijian_slot_${i}`);
      if (raw) {
        const data = JSON.parse(raw);
        slots.push({ ...data, num: i, id: i });
      }
    } catch (e) {}
  }
  return slots.sort((a, b) => b.ts - a.ts);
}

export function saveToSlot(state, num) {
  const snapshot = JSON.parse(JSON.stringify(state));
  snapshot.meta = {
    ts: Date.now(),
    summary: summarize(state),
  };
  localStorage.setItem(`cijian_slot_${num}`, JSON.stringify(snapshot));
  return true;
}

export function loadFromSlot(num) {
  try {
    const raw = localStorage.getItem(`cijian_slot_${num}`);
    if (!raw) return null;
    const data = JSON.parse(raw);
    if (data.version !== SAVE_VERSION) return null;
    return data;
  } catch (e) {
    return null;
  }
}

export function deleteSlot(num) {
  localStorage.removeItem(`cijian_slot_${num}`);
}

export function exportSaveJSON(state) {
  const snapshot = JSON.parse(JSON.stringify(state));
  return JSON.stringify(snapshot, null, 2);
}

export function importSaveJSON(text) {
  try {
    const data = JSON.parse(text);
    if (!data || !data.player || !data.time) return null;
    data.version = SAVE_VERSION;
    return data;
  } catch (e) {
    return null;
  }
}

export function autoSave(state) {
  try {
    localStorage.setItem(AUTO_KEY, JSON.stringify(state));
    return true;
  } catch (e) {
    return false;
  }
}

export function loadAutoSave() {
  try {
    const raw = localStorage.getItem(AUTO_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {}
  return null;
}

export function hasAutoSave() {
  return !!localStorage.getItem(AUTO_KEY);
}

function summarize(state) {
  const p = state.player;
  const t = state.time;
  const day = t.date.year + '-' + t.date.month + '-' + t.date.day;
  const met = Object.values(state.relations).filter((r) => r.met).length;
  return `${p.name} · 第${t.day}天(${day}) · 认识${met}人 · ¥${p.money}`;
}

export function downloadSave(state) {
  const blob = new Blob([exportSaveJSON(state)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `此间少年行_${state.player.name}_第${state.time.day}天.json`;
  a.click();
  URL.revokeObjectURL(url);
}

export function clampAll(p) {
  p.stats.hp = clamp(p.stats.hp, 0, 50 + p.attributes.con * 5 + p.stats.sta * 0.2);
  p.stats.ep = clamp(p.stats.ep, 0, 80 + p.attributes.int * 2 + p.mood * 0.2);
  p.stats.sat = clamp(p.stats.sat, 0, 100);
  p.stats.cln = clamp(p.stats.cln, 0, 100);
  p.stats.sta = clamp(p.stats.sta, 0, 50 + p.attributes.con * 4);
  p.stats.stress = clamp(p.stats.stress, 0, 100);
  p.mood = clamp(p.mood, 0, 100);
  p.morality = clamp(p.morality, 0, 100);
}
