export const rand = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;
export const randFloat = (min, max) => Math.random() * (max - min) + min;
export const clamp = (v, min, max) => Math.max(min, Math.min(max, v));
export const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
export const chance = (p) => Math.random() * 100 < p;
export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

export function formatMoney(n) {
  return '¥' + Math.floor(n).toLocaleString('zh-CN');
}

export function formatDate(date) {
  const { year, month, day } = date;
  return `${year}年${month}月${day}日`;
}

export function weekdayCN(date) {
  const { year, month, day } = date;
  const d = new Date(year, month - 1, day);
  return ['日', '一', '二', '三', '四', '五', '六'][d.getDay()];
}

export function getPeriod(hour) {
  if (hour >= 6 && hour < 9) return '清晨';
  if (hour >= 9 && hour < 12) return '上午';
  if (hour >= 12 && hour < 14) return '正午';
  if (hour >= 14 && hour < 17) return '下午';
  if (hour >= 17 && hour < 19) return '黄昏';
  if (hour >= 19 && hour < 22) return '夜晚';
  return '深夜';
}

export function getSeason(month) {
  if (month >= 3 && month <= 5) return '春';
  if (month >= 6 && month <= 8) return '夏';
  if (month >= 9 && month <= 11) return '秋';
  return '冬';
}

export function relTime(ts) {
  if (!ts) return '';
  const diff = Math.floor((Date.now() - ts) / 60000);
  if (diff < 1) return '刚刚';
  if (diff < 60) return diff + '分钟前';
  if (diff < 1440) return Math.floor(diff / 60) + '小时前';
  if (diff < 43200) return Math.floor(diff / 1440) + '天前';
  return new Date(ts).toLocaleDateString('zh-CN');
}

export function vibrate() {
  if (navigator.vibrate) navigator.vibrate(15);
}

export function hashCode(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  return Math.abs(h);
}

export function escapeHTML(str) {
  return String(str).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}
