import { saveState } from '../core/storage.js';
import { formatGameDate } from '../core/state.js';
import { getPeriod } from '../core/utils.js';
import { toast } from '../main.js';

const APPS = [
  { id: 'qq', name: 'QQ', ico: '🐧', bg: '#6BB2E8', file: 'qq' },
  { id: 'contacts', name: '通讯录', ico: '📖', bg: '#9FB4C7', file: 'contacts' },
  { id: 'forum', name: '论坛', ico: '🌐', bg: '#A8B5A0', file: 'forum' },
  { id: 'diary', name: '日记', ico: '📔', bg: '#D9B26B', file: 'diary' },
  { id: 'creations', name: '创作', ico: '🎨', bg: '#7FA8C9', file: 'creations' },
  { id: 'tarot', name: '塔罗', ico: '🔮', bg: '#8E86A8', file: 'tarot' },
  { id: 'calendar', name: '日历', ico: '📅', bg: '#7FA07F', file: 'calendar' },
  { id: 'wallet', name: '钱包', ico: '💰', bg: '#D8A657', file: 'wallet' },
  { id: 'mail', name: '邮箱', ico: '✉️', bg: '#C77E7E', file: 'mail' },
  { id: 'music', name: '音乐', ico: '🎵', bg: '#B5A6C9', file: 'music' },
  { id: 'psettings', name: '手机设置', ico: '⚙️', bg: '#6E8296', file: 'psettings' },
];

// 底部固定 Dock 栏应用
const DOCK_APPS = ['qq', 'contacts', 'forum', 'diary'];

let phoneState = null;

export function openPhone(state, opts = {}) {
  phoneState = { state, opts, app: null, page: 0 };
  const overlay = document.createElement('div');
  overlay.className = 'phone-overlay';

  const device = document.createElement('div');
  device.className = 'phone-device';
  overlay.appendChild(device);
  document.body.appendChild(overlay);

  let screen;

  function statusbar() {
    const t = state.time;
    const period = getPeriod(t.hour);
    return `
      <div class="phone-statusbar">
        <span>${period} ${String(t.hour).padStart(2, '0')}:${String(t.minute).padStart(2, '0')}</span>
        <span style="letter-spacing:1px;font-size:10px;">${formatGameDate(t.date)}</span>
        <span>📶 🔋</span>
      </div>`;
  }

  function render() {
    screen = document.createElement('div');
    screen.className = 'phone-screen';
    device.innerHTML = statusbar();
    device.appendChild(screen);
    applyWallpaper();

    if (phoneState.app) {
      renderApp();
    } else {
      renderHome();
    }

    const homebar = document.createElement('div');
    homebar.className = 'phone-homebar';
    homebar.innerHTML = `<div class="home-indicator"></div>`;
    homebar.addEventListener('click', () => {
      phoneState.app = null;
      render();
    });
    device.appendChild(homebar);
  }

  function renderHome() {
    screen.innerHTML = '';
    const home = document.createElement('div');
    home.className = 'phone-home';

    const unreadTotal = totalUnread();
    home.innerHTML = `
      <div class="phone-home-header">
        <span class="ph-nick">${state.player.nickname}</span>
        <span class="ph-battery">🔔 ${unreadTotal || ''} · 电量 98% <button class="notif-toggle" id="notifToggle">↓</button></span>
      </div>
      <div class="phone-pages" id="phonePages">
        <div class="phone-page" data-pg="0">
          ${Array.from({ length: 12 }, (_, slot) => {
            const app = appForSlot(0, slot);
            if (!app) return `<div></div>`;
            const u = unreadOf(app.id);
            return `
              <button class="phone-app ${DOCK_APPS.includes(app.id) ? '' : 'dragable'}" data-app="${app.id}">
                <div class="phone-app-ico" style="background:linear-gradient(135deg, ${app.bg}, ${shade(app.bg, -18)});">
                  <span>${app.ico}</span>
                  ${u ? `<div class="app-badge">${u}</div>` : ''}
                </div>
                <div class="phone-app-name">${app.name}</div>
              </button>`;
          }).join('')}
        </div>
      </div>
      <div class="phone-notif-center" id="phoneNotif">
        <div class="notif-handle"></div>
        <div class="notif-title">通知中心</div>
        <div class="notif-list"></div>
      </div>`;

    screen.appendChild(home);
    home.querySelectorAll('.phone-app').forEach((btn) => {
      btn.addEventListener('click', () => openApp(btn.dataset.app));
    });
    // 下拉通知中心
    setupNotifCenter(home);
    // 长按拖动排序（仅非固定应用）
    setupDragReorder(home);
  }

  function renderApp() {
    const app = APPS.find((a) => a.id === phoneState.app);
    const ctx = {
      state,
      goBack: () => { phoneState.app = null; render(); },
      back: () => {
        if (phoneState.backFn) { phoneState.backFn(); phoneState.backFn = null; }
        else { phoneState.app = null; render(); }
      },
      setBack: (fn) => { phoneState.backFn = fn || null; },
      render,
      save: () => saveState(state),
      notify: () => renderHome,
      toast,
    };
    import(`./apps/${app.file}.js`).then((m) => {
      screen.innerHTML = '';
      m.renderApp(phoneState.app, screen, ctx);
    });
  }

  function openApp(id) {
    const app = APPS.find((a) => a.id === id);
    if (!app) return;
    phoneState.app = id;
    render();
  }

  function unreadOf(appId) {
    const q = state.phone;
    if (appId === 'qq') {
      return Object.values(q.qq.unread || {}).reduce((a, b) => a + b, 0);
    }
    if (appId === 'mail') return q.mailbox.unread || 0;
    if (appId === 'forum') return q.forum.unread || 0;
    return 0;
  }

  // 单页 4x3 网格：11 个应用全部放在一个页面，不可重叠；支持 layout 排序
  function appForSlot(pg, slot) {
    const layout = state.phone.layout && state.phone.layout.length === APPS.length
      ? state.phone.layout
      : APPS.map((a) => a.id);
    if (pg !== 0) return null;
    return slot < APPS.length ? APPS.find((a) => a.id === layout[slot]) : null;
  }

  function totalUnread() {
    return APPS.reduce((sum, a) => sum + unreadOf(a.id), 0);
  }

  // 手机壁纸：8 个预设或导入图片
  const WALLPAPERS = {
    spring: { label: '春·樱落', bg: 'linear-gradient(160deg, #FDE8EF, #F7C7D9, #E8F5E9)' },
    summer: { label: '夏·碧海', bg: 'linear-gradient(160deg, #D6F0FF, #9ED6F0, #FDEBC8)' },
    autumn: { label: '秋·枫红', bg: 'linear-gradient(160deg, #FDEAD2, #F0B88C, #C97B63)' },
    winter: { label: '冬·雪寂', bg: 'linear-gradient(160deg, #F2F6FA, #D9E4EE, #C3D2E0)' },
    cityNight: { label: '城市夜景', bg: 'linear-gradient(160deg, #2C3A52, #4A5B7A, #F2C94C)' },
    cloudForest: { label: '云栖林海', bg: 'linear-gradient(160deg, #E4F1E8, #B7D6C0, #8FBFA0)' },
    minimalMoon: { label: '极简月灰', bg: 'linear-gradient(160deg, #EFEFEF, #D8D8D8, #BDBDBD)' },
    darkInk: { label: '深色砚蓝', bg: 'linear-gradient(160deg, #1B2536, #2E3B52, #0F1622)' },
  };

  function applyWallpaper() {
    const q = state.phone;
    let style = '';
    if (q.wallpaper && q.wallpaper.startsWith('custom:')) {
      style = `background-image:url(${q.wallpaper.slice(7)}); background-size:cover; background-position:center;`;
    } else {
      const w = WALLPAPERS[q.wallpaper];
      style = w ? `background:${w.bg};` : `background:${WALLPAPERS.spring.bg};`;
    }
    device.style.cssText = style;
  }

  // 下拉通知中心：从顶部下拉展开，显示好友消息/论坛回复/系统通知等
  function setupNotifCenter(home) {
    const notif = home.querySelector('#phoneNotif');
    const header = home.querySelector('.phone-home-header');
    let startY = 0;
    let pulling = false;
    header.addEventListener('touchstart', (e) => {
      startY = e.touches[0].clientY;
      pulling = true;
    }, { passive: true });
    header.addEventListener('touchmove', (e) => {
      if (!pulling) return;
      const dy = e.touches[0].clientY - startY;
      if (dy > 0) notif.style.transform = `translateY(${Math.min(dy, 260)}px)`;
    }, { passive: true });
    header.addEventListener('touchend', (e) => {
      const dy = e.changedTouches[0].clientY - startY;
      if (dy > 90) openNotif();
      notif.style.transform = '';
      pulling = false;
    });
    const toggle = home.querySelector('#notifToggle');
    toggle.addEventListener('click', () => {
      notif.classList.contains('open') ? closeNotif() : openNotif();
    });
    notif.querySelector('.notif-handle').addEventListener('click', () => closeNotif());
    notif.addEventListener('click', (e) => {
      if (e.target.closest('.notif-close')) closeNotif();
    });
    // 供自动化/入口调用
    notif.openNotif = openNotif;

    function openNotif() {
      renderNotifList();
      notif.classList.add('open');
    }
    function closeNotif() {
      notif.classList.remove('open');
    }

    function renderNotifList() {
      const list = notif.querySelector('.notif-list');
      const items = buildNotifItems();
      if (!items.length) {
        list.innerHTML = `<div class="notif-empty">暂无新通知</div>`;
        return;
      }
      list.innerHTML = items.map((it) => `
        <div class="notif-item">
          <span class="notif-app">${it.app}</span>
          <div class="notif-text">${it.text}</div>
          <div class="notif-time">${it.time}</div>
        </div>`).join('');
    }
  }

  function buildNotifItems() {
    const q = state.phone;
    const out = [];
    const now = formatTime(new Date());
    // QQ 未读
    Object.entries(q.qq.unread || {}).forEach(([id, n]) => {
      if (!n) return;
      const c = (q.qq.contacts || []).find((x) => x.id === id);
      const who = c ? c.nick : id;
      out.push({ app: 'QQ', text: `${who} 发来 ${n} 条新消息`, time: now });
    });
    // 论坛未读
    if (q.forum.unread) out.push({ app: '云栖论坛', text: `有 ${q.forum.unread} 条新回复或通知`, time: now });
    // 邮箱未读
    if (q.mailbox.unread) out.push({ app: '邮箱', text: `收到 ${q.mailbox.unread} 封新邮件`, time: now });
    // 显式通知
    (q.notifications || []).slice(-6).forEach((n) => {
      out.push({ app: n.app || '系统', text: n.text, time: n.time || now });
    });
    return out.slice(0, 8);
  }

  function formatTime(d) {
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  }

  // 长按拖动排序（仅非固定应用）：长按 500ms 进入拖动，拖动到目标图标上交换位置
  function setupDragReorder(home) {
    let dragEl = null;
    let clone = null;
    let pressTimer = null;
    let longPressed = false;
    let startX = 0;
    let startY = 0;

    const icons = home.querySelectorAll('.phone-app.dragable');
    icons.forEach((icon) => {
      icon.addEventListener('touchstart', (e) => {
        const t = e.touches[0];
        startX = t.clientX;
        startY = t.clientY;
        longPressed = false;
        pressTimer = setTimeout(() => {
          longPressed = true;
          dragEl = icon;
          clone = icon.cloneNode(true);
          clone.className = 'phone-app drag-clone';
          clone.style.left = `${t.clientX}px`;
          clone.style.top = `${t.clientY}px`;
          document.body.appendChild(clone);
          icon.classList.add('dragging');
          e.preventDefault();
        }, 500);
      }, { passive: true });
      icon.addEventListener('touchmove', (e) => {
        if (!longPressed || !clone) return;
        const t = e.touches[0];
        clone.style.left = `${t.clientX}px`;
        clone.style.top = `${t.clientY}px`;
        const target = document.elementFromPoint(t.clientX, t.clientY);
        if (target && target.closest && target.closest('.phone-app.dragable') && target.closest('.phone-app.dragable') !== dragEl) {
          swapApps(dragEl.dataset.app, target.closest('.phone-app.dragable').dataset.app);
          render();
        }
        e.preventDefault();
      }, { passive: false });
      const endDrag = () => {
        clearTimeout(pressTimer);
        if (clone) { clone.remove(); clone = null; }
        if (dragEl) { dragEl.classList.remove('dragging'); dragEl = null; }
        longPressed = false;
      };
      icon.addEventListener('touchend', endDrag);
      icon.addEventListener('touchcancel', endDrag);
    });

    function swapApps(idA, idB) {
      const layout = state.phone.layout && state.phone.layout.length === APPS.length
        ? [...state.phone.layout]
        : APPS.map((a) => a.id);
      const iA = layout.indexOf(idA);
      const iB = layout.indexOf(idB);
      if (iA < 0 || iB < 0) return;
      [layout[iA], layout[iB]] = [layout[iB], layout[iA]];
      state.phone.layout = layout;
      saveState(state);
    }
  }

  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) closePhone();
  });

  function closePhone() {
    saveState(state);
    overlay.remove();
    if (phoneState.opts && phoneState.opts.onClose) phoneState.opts.onClose();
  }

  window.addEventListener('keydown', closeOnEsc);
  function closeOnEsc(e) {
    if (e.key === 'Escape') closePhone();
  }

  render();
  return { overlay, close: closePhone };
}

function shade(hex, amt) {
  let h = hex.replace('#', '');
  if (h.length === 3) h = h.split('').map((c) => c + c).join('');
  const n = parseInt(h, 16);
  let r = (n >> 16) + amt, g = ((n >> 8) & 0xff) + amt, b = (n & 0xff) + amt;
  r = Math.max(0, Math.min(255, r)); g = Math.max(0, Math.min(255, g)); b = Math.max(0, Math.min(255, b));
  return `#${((r << 16) | (g << 8) | b).toString(16).padStart(6, '0')}`;
}
