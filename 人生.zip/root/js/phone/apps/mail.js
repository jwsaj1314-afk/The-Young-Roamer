import { isAIReady, chat, buildSystemPrompt } from '../../core/ai.js';
import { knownContacts } from './common.js';

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-mail';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="mlBack">‹</button>
      <div class="phone-app-title">邮箱</div>
      <button class="phone-back-btn" id="mlWrite" title="写信">✎</button>
      <button class="phone-back-btn" id="mlRefresh" title="刷新">⟳</button>
    </div>
    <div class="phone-app-body" id="mlBody"></div>`;
  screen.querySelector('#mlBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#mlWrite').addEventListener('click', () => write());
  screen.querySelector('#mlRefresh').addEventListener('click', () => {
    maybeIncoming();
    render();
  });
  seed();
  render();

  function seed() {
    const mb = state.phone.mailbox;
    if (!mb.emails) mb.emails = [];
    if (!mb._seeded) {
      mb._seeded = true;
      mb.emails.unshift(
        { id: 'e1', from: '云栖市第一中学', subject: '欢迎入学', body: '亲爱的蒋华同学：欢迎你成为云栖市第一中学的一员。请于9月2日早晨8:00到教学楼一楼大厅报到，并领取课表。愿你在新的校园里收获成长与友谊。', ts: Date.now() - 86400000, read: false },
        { id: 'e2', from: '云栖市福利院', subject: '愿你安好', body: '小华：到了新家，要照顾好自己。许先生是个可靠的人，有什么事都可以和我们说。记得常回来看看。陈阿姨', ts: Date.now() - 86400000 * 2, read: false },
      );
      mb.unread = 2;
      ctx.save();
    }
  }

  function render() {
    const body = screen.querySelector('#mlBody');
    const mb = state.phone.mailbox;
    mb.unread = mb.emails.filter((e) => !e.read).length;
    ctx.save();
    body.innerHTML = `
      <div style="padding:4px 2px 10px;font-size:12px;color:var(--text-secondary);display:flex;justify-content:space-between;">
        <span>${state.phone.email || 'xiaohua@yunqimail.cn'}</span>
        <span>${mb.unread ? mb.unread + ' 封未读' : '收件箱已读'}</span>
      </div>
      ${mb.emails.length ? '' : '<div class="empty-hint">收件箱为空</div>'}
      ${[...mb.emails].reverse().map((e, i) => `
        <div class="mail-item ${e.read ? '' : 'unread'}" data-i="${i}">
          <div class="mail-from"><span class="mail-dot"></span>${e.from} ${e.read ? '' : '<span class="tag">未读</span>'}</div>
          <div class="mail-subject">${e.subject}</div>
          <div class="mail-preview">${e.body.slice(0, 40)}${e.body.length > 40 ? '…' : ''}</div>
          <div class="mail-time">${new Date(e.ts).toLocaleString()}</div>
        </div>`).join('')}`;
    body.querySelectorAll('.mail-item').forEach((el) => {
      el.addEventListener('click', () => openMail(parseInt(el.dataset.i, 10)));
    });
  }

  function openMail(idx) {
    const body = screen.querySelector('#mlBody');
    ctx.setBack(render);
    const mb = state.phone.mailbox;
    const mail = mb.emails[mb.emails.length - 1 - idx];
    mail.read = true;
    mb.unread = mb.emails.filter((e) => !e.read).length;
    ctx.save();
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
        <button class="btn btn-sm" id="mlBack2">‹ 返回</button>
        <span style="flex:1;font-size:13px;font-weight:600;color:var(--accent-deep);">${mail.from}</span>
        <button class="btn btn-sm" id="mlMore">···</button>
      </div>
      <div id="mlMoreBox" style="display:none;margin-bottom:10px;border:1px solid var(--card-border);border-radius:12px;padding:6px;background:rgba(255,255,255,0.7);">
        <div class="menu-item" id="mlToggleRead">${mail.read ? '标记为未读' : '标记为已读'}</div>
        <div class="menu-item" id="mlForward">↪ 转发</div>
        <div class="menu-item danger" id="mlDelete">🗑 删除</div>
      </div>
      <div style="padding:6px 2px 12px;">
        <div class="mail-from">${mail.from}</div>
        <div style="font-size:11px;color:var(--text-faint);">发件人：${mail.address || mail.from + '@yunqimail.cn'}</div>
        <div class="mail-subject" style="font-size:16px;margin-top:6px;">${mail.subject}</div>
        <div class="mail-time" style="margin-bottom:14px;">${new Date(mail.ts).toLocaleString()}</div>
        <div style="font-size:13px;line-height:1.9;color:var(--text-primary);white-space:pre-wrap;">${mail.body}</div>
        <div style="display:flex;gap:8px;margin-top:16px;">
          ${mail.from !== state.phone.email && mail.from !== '我' ? `<button class="btn btn-sm btn-primary" id="mlReply">回复</button>` : ''}
          <button class="btn btn-sm" id="mlBack3">返回收件箱</button>
        </div>
      </div>`;
    body.querySelector('#mlMore').addEventListener('click', () => {
      const box = body.querySelector('#mlMoreBox');
      box.style.display = box.style.display === 'none' ? 'block' : 'none';
    });
    body.querySelector('#mlToggleRead').addEventListener('click', () => {
      mail.read = !mail.read;
      mb.unread = mb.emails.filter((e) => !e.read).length;
      ctx.save();
      render();
    });
    body.querySelector('#mlForward').addEventListener('click', () => {
      write(null, '转发：' + mail.subject, mail.body);
    });
    body.querySelector('#mlDelete').addEventListener('click', () => {
      mb.emails = mb.emails.filter((e) => e.id !== mail.id);
      mb.unread = mb.emails.filter((e) => !e.read).length;
      ctx.save();
      ctx.toast('已删除邮件');
      render();
    });
    const replyBtn = body.querySelector('#mlReply');
    if (replyBtn) replyBtn.addEventListener('click', () => write(mail));
    body.querySelector('#mlBack2').addEventListener('click', render);
    body.querySelector('#mlBack3').addEventListener('click', render);
  }

  function write(replyTo, fwdSubject, fwdBody) {
    const body = screen.querySelector('#mlBody');
    ctx.setBack(render);
    const mb = state.phone.mailbox;
    const recipients = {
      '云栖市第一中学': '教务处',
      '云栖市福利院': '陈阿姨',
      '云栖社区服务中心': '服务中心',
      '麦香晨光': '店长',
      '市立图书馆': '图书管理员',
    };
    const knownMails = knownContacts(state);
    body.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:10px;">
        <div style="font-size:13px;color:var(--text-secondary);">${fwdSubject ? '转发邮件' : (replyTo ? `回复：${replyTo.from}` : '写信')}</div>
        <div>
          <div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;">收件人</div>
          <input type="text" id="mlTo" list="mlToList" placeholder="输入 NPC 姓名或邮箱…" value="${replyTo ? replyTo.from : ''}" style="width:100%;">
          <datalist id="mlToList">
            ${Object.keys(recipients).map((k) => `<option value="${k}">`).join('')}
            ${knownMails.map((c) => `<option value="${c.name}">`).join('')}
          </datalist>
        </div>
        <input type="text" id="mlSubject" placeholder="主题" value="${fwdSubject ? fwdSubject : (replyTo ? 'Re: ' + replyTo.subject : '')}" style="width:100%;">
        <textarea id="mlBodyTxt" placeholder="写下你想说的话…" style="width:100%;min-height:160px;font-size:13px;line-height:1.7;resize:none;">${fwdBody ? fwdBody + '\n\n—— 转发的原邮件' : ''}</textarea>
        <div style="font-size:11px;color:var(--text-faint);">发给角色或机构的邮件会收到 AI 回信</div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm" id="mlCancel">取消</button>
          <button class="btn btn-sm btn-primary" id="mlSend">发送</button>
        </div>
      </div>`;
    body.querySelector('#mlCancel').addEventListener('click', render);
    body.querySelector('#mlSend').addEventListener('click', () => {
      const toInput = body.querySelector('#mlTo');
      const subject = body.querySelector('#mlSubject').value.trim();
      const text = body.querySelector('#mlBodyTxt').value.trim();
      if (!text) return ctx.toast('内容不能为空');
      let to = (toInput ? toInput.value.trim() : '') || 'NPC';
      const match = Object.keys(recipients).find((k) => k === to);
      if (!match && knownMails.some((c) => c.name === to)) {
        to = to;
      } else if (!match) {
        to = 'NPC';
      }
      mb.emails.unshift({ id: 'e' + Date.now(), from: '我', subject: subject || '(无主题)', body: text, ts: Date.now(), read: true });
      ctx.save();
      ctx.toast('已发送');
      if (isAIReady()) {
        scheduleAiReply(to, subject || '(无主题)', text);
      } else {
        setTimeout(() => {
          const from = to === 'NPC' ? randomChar() : to;
          const sender = Object.prototype.hasOwnProperty.call(recipients, from) ? recipients[from] : from;
          mb.emails.unshift({ id: 'e' + Date.now(), from, subject: 'Re: ' + (subject || '(无主题)'), body: `${sender}：已收到你的来信，谢谢你想到我们。`, ts: Date.now(), read: false });
          ctx.save();
          ctx.toast('收到回信');
        }, 3000);
      }
      render();
    });
  }

  function randomChar() {
    const met = Object.entries(state.relations || {}).filter(([, r]) => r.met).map(([k]) => k);
    const pool = met.length ? met : Object.keys(state.relations || {});
    const char = pool[Math.floor(Math.random() * pool.length)];
    return state.characters && state.characters[char] ? state.characters[char].name : char;
  }

  function scheduleAiReply(to, subject, text) {
    const mb = state.phone.mailbox;
    const delay = 3000 + Math.random() * 7000;
    setTimeout(async () => {
      const sys = buildSystemPrompt(state, '有人写信给' + (to === 'NPC' ? '一位角色' : to) + '。');
      try {
        const reply = (await chat([
          { role: 'system', content: sys.system + `\n你是${to === 'NPC' ? '一位云栖市的角色' : to}，收到来信后写一封简短温暖的回信（60字内）。` },
          { role: 'user', content: `来信主题：${subject}\n来信内容：${text}` },
        ], { temperature: 0.9, max_tokens: 150 })).trim();
        const from = to === 'NPC' ? randomChar() : to;
        mb.emails.unshift({ id: 'e' + Date.now(), from, subject: 'Re: ' + subject, body: reply, ts: Date.now(), read: false });
      } catch (e) {
        const from = to === 'NPC' ? randomChar() : to;
        mb.emails.unshift({ id: 'e' + Date.now(), from, subject: 'Re: ' + subject, body: '已收到你的来信，愿你在云栖市一切安好。', ts: Date.now(), read: false });
      }
      mb.unread = mb.emails.filter((x) => !x.read).length;
      ctx.save();
      ctx.toast('收到回信');
    }, delay);
  }

  function maybeIncoming() {
    if (Math.random() < 0.3) {
      const mb = state.phone.mailbox;
      const senders = ['云栖社区服务中心', '麦香晨光', '市立图书馆'];
      const subjects = ['社区通知', '本周新品', '读书推荐'];
      const from = senders[Math.floor(Math.random() * senders.length)];
      mb.emails.unshift({ id: 'e' + Date.now(), from, subject: subjects[Math.floor(Math.random() * subjects.length)], body: '这是一封来自' + from + '的邮件，祝你在云栖市生活愉快。', ts: Date.now(), read: false });
      ctx.save();
      ctx.toast('收到新邮件');
    }
  }
}
