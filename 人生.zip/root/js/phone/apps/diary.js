import { isAIReady, chat, buildSystemPrompt } from '../../core/ai.js';
import { recordMemory } from '../../core/narrative.js';

const WEATHERS = ['☀️', '⛅', '☁️', '🌧️', '🌨️', '🌈'];
const MOODS = ['😊', '😐', '😢', '😡', '😰', '🥰'];

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-diary';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="dyBack">‹</button>
      <div class="phone-app-title">我的日记</div>
      <button class="phone-back-btn" id="dyRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="dyView" title="切换视图">▦</button>
      <button class="phone-back-btn" id="dyNew" title="写日记">＋</button>
    </div>
    <div class="phone-app-body" id="dyBody"></div>`;
  screen.querySelector('#dyBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#dyNew').addEventListener('click', () => write());
  screen.querySelector('#dyRefresh').addEventListener('click', () => refreshPrompt());
  let listMode = true;
  render();

  function render() {
    const body = screen.querySelector('#dyBody');
    const list = state.phone.diary || [];
    screen.querySelector('#dyView').addEventListener('click', () => { listMode = !listMode; render(); });
    if (listMode) renderList(body, list);
    else renderCalendar(body, list);
  }

  function renderList(body, list) {
    body.innerHTML = `
      <div style="padding:4px 2px 10px;font-size:12px;color:var(--text-secondary);display:flex;justify-content:space-between;">
        <span>共 ${list.length} 篇日记</span>
        <span>${listMode ? '列表视图' : '日历视图'}</span>
      </div>
      ${list.length ? '' : '<div class="empty-hint">还没有写过日记<br>用文字留住云栖市的日子</div>'}
      ${[...list].reverse().map((d) => {
        const dt = d.ts ? new Date(d.ts) : null;
        const dateLabel = dt ? `${dt.getMonth() + 1}月${dt.getDate()}日` : `第${d.day}天`;
        return `
        <div class="diary-item">
          <div class="diary-date-row">
            <span class="diary-date">${dateLabel}</span>
            <span class="diary-meta">${d.weather || '☀️'} ${d.mood || '😊'} ${d.public ? '🌐公开' : '🔒私密'}</span>
          </div>
          ${d.title ? `<div class="diary-item-title">${d.title}</div>` : ''}
          <div class="diary-item-body">${d.content}</div>
        </div>`;
      }).join('')}`;
  }

  function renderCalendar(body, list) {
    const t = state.time.date;
    const year = state.time.date.year;
    const month = state.time.date.month;
    const first = new Date(year, month - 1, 1).getDay();
    const days = new Date(year, month, 0).getDate();
    const dayMap = {};
    list.forEach((d) => {
      const dt = d.ts ? new Date(d.ts) : null;
      const dd = dt && dt.getFullYear() === year && dt.getMonth() === month - 1 ? dt.getDate() : (d.day ? null : null);
      if (dd) (dayMap[dd] = dayMap[dd] || []).push(d);
    });
    let cells = '';
    for (let i = 0; i < first; i++) cells += `<div class="cal-cell other"></div>`;
    for (let d = 1; d <= days; d++) {
      const isToday = d === t.day;
      const has = dayMap[d];
      cells += `
        <div class="cal-cell ${isToday ? 'today' : ''} ${has ? 'has-diary' : ''}" data-day="${d}">
          ${d}
          ${has ? `<div class="cal-dot diary-dot"></div>` : ''}
        </div>`;
    }
    body.innerHTML = `
      <div style="padding:4px 2px 10px;font-size:12px;color:var(--text-secondary);display:flex;justify-content:space-between;">
        <span>${year}年${month}月 · 日历视图</span>
      </div>
      <div class="cal-week">${['日', '一', '二', '三', '四', '五', '六'].map((w) => `<div>${w}</div>`).join('')}</div>
      <div class="cal-grid">${cells}</div>
      <div class="cal-events">
        <div class="panel-sec">当月日记</div>
        ${list.length ? '' : '<div style="font-size:12px;color:var(--text-faint);">当月没有日记</div>'}
        ${[...list].reverse().map((d) => {
          const dt = d.ts ? new Date(d.ts) : null;
          const dateLabel = dt ? `${dt.getMonth() + 1}月${dt.getDate()}日` : `第${d.day}天`;
          return `
          <div class="diary-item">
            <div class="diary-date-row">
              <span class="diary-date">${dateLabel}</span>
              <span class="diary-meta">${d.weather || '☀️'} ${d.mood || '😊'} ${d.public ? '🌐公开' : '🔒私密'}</span>
            </div>
            ${d.title ? `<div class="diary-item-title">${d.title}</div>` : ''}
            <div class="diary-item-body">${d.content}</div>
          </div>`;
        }).join('')}
      </div>`;
  }

  function write() {
    const body = screen.querySelector('#dyBody');
    ctx.setBack(render);
    const curWeather = { 晴: '☀️', 多云: '⛅', 阴: '☁️', 小雨: '🌧️', 大雨: '🌧️', 雷阵雨: '⛈️', 雪: '🌨️' }[state.weather] || '☀️';
    body.innerHTML = `
      <div class="diary-editor">
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;">
          <span style="font-size:13px;color:var(--text-secondary);">日期</span>
          <input type="number" id="dyY" value="${state.time.date.year}" min="2024" max="2035" style="width:64px;font-size:13px;">
          <span style="font-size:13px;">年</span>
          <input type="number" id="dyM" value="${state.time.date.month}" min="1" max="12" style="width:48px;font-size:13px;">
          <span style="font-size:13px;">月</span>
          <input type="number" id="dyD" value="${state.time.date.day}" min="1" max="31" style="width:48px;font-size:13px;">
          <span style="font-size:13px;">日</span>
        </div>
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;flex-wrap:wrap;">
          <span style="font-size:12px;color:var(--text-secondary);">天气</span>
          <div style="display:flex;gap:4px;">
            ${WEATHERS.map((w) => `<button class="btn btn-sm dy-weather ${w === curWeather ? 'selected' : ''}" data-w="${w}">${w}</button>`).join('')}
          </div>
        </div>
        <div style="display:flex;gap:8px;align-items:center;margin-bottom:8px;flex-wrap:wrap;">
          <span style="font-size:12px;color:var(--text-secondary);">心情</span>
          <div style="display:flex;gap:4px;">
            ${MOODS.map((m, i) => `<button class="btn btn-sm dy-mood ${i === 0 ? 'selected' : ''}" data-m="${m}">${m}</button>`).join('')}
          </div>
        </div>
        <input type="text" id="dyTitle" placeholder="日记标题（可选）" style="width:100%;margin-bottom:8px;">
        <textarea id="dyInput" placeholder="今天在云栖市发生了什么呢…"></textarea>
        <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px;">
          <label class="switch" style="flex-shrink:0;"><input type="checkbox" id="dyPublic"><span class="slider"></span></label>
          <span style="font-size:12px;color:var(--text-secondary);">公开（同步至论坛个人主页）</span>
        </div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm" id="dyCancel">返回</button>
          <button class="btn btn-sm btn-primary" id="dySave">保存</button>
          ${isAIReady() ? '<button class="btn btn-sm" id="dyAI">✨ AI代写</button>' : ''}
        </div>
      </div>`;
    let weather = curWeather;
    let mood = MOODS[0];
    body.querySelectorAll('.dy-weather').forEach((b) => {
      b.addEventListener('click', () => {
        body.querySelectorAll('.dy-weather').forEach((x) => x.classList.remove('selected'));
        b.classList.add('selected');
        weather = b.dataset.w;
      });
    });
    body.querySelectorAll('.dy-mood').forEach((b) => {
      b.addEventListener('click', () => {
        body.querySelectorAll('.dy-mood').forEach((x) => x.classList.remove('selected'));
        b.classList.add('selected');
        mood = b.dataset.m;
      });
    });
    body.querySelector('#dyCancel').addEventListener('click', render);
    body.querySelector('#dySave').addEventListener('click', () => {
      const content = body.querySelector('#dyInput').value.trim();
      const title = body.querySelector('#dyTitle').value.trim();
      if (!content) return ctx.toast('内容不能为空');
      const y = parseInt(body.querySelector('#dyY').value, 10) || state.time.date.year;
      const m = parseInt(body.querySelector('#dyM').value, 10) || state.time.date.month;
      const d = parseInt(body.querySelector('#dyD').value, 10) || state.time.date.day;
      save(content, title, weather, mood, body.querySelector('#dyPublic').checked, { y, m, d });
      ctx.toast('日记已保存');
      render();
    });
    const aiBtn = body.querySelector('#dyAI');
    if (aiBtn) {
      aiBtn.addEventListener('click', async () => {
        aiBtn.textContent = 'AI写作中…';
        aiBtn.disabled = true;
        const sys = buildSystemPrompt(state, '玩家想写一篇今日日记。');
        try {
          const content = (await chat([
            { role: 'system', content: sys.system + '\n请以第一人称"我"写一篇150字以内的治愈系日记，记录今天的云栖市生活，语气温柔平静，加入天气与心情细节。' },
            { role: 'user', content: `今天是第${state.time.day}天，${state.time.date.year}年${state.time.date.month}月${state.time.date.day}日，天气${state.weather}。` },
          ], { temperature: 0.9, max_tokens: 300 })).trim();
          body.querySelector('#dyInput').value = content;
          body.querySelector('#dyTitle').value = '第' + state.time.day + '天';
        } catch (e) {
          ctx.toast('AI 生成失败');
        }
        aiBtn.textContent = '✨ AI代写';
        aiBtn.disabled = false;
      });
    }
  }

  async function refreshPrompt() {
    const btn = screen.querySelector('#dyRefresh');
    if (btn) { btn.textContent = '…'; btn.disabled = true; }
    let tip = '';
    if (isAIReady()) {
      const sys = buildSystemPrompt(state, '玩家刷新日记灵感。');
      try {
        tip = (await chat([
          { role: 'system', content: sys.system + '\n请给玩家一条日记写作灵感提示，15-30字，贴合云栖市生活，温暖治愈。' },
          { role: 'user', content: `今天是第${state.time.day}天，${state.time.date.year}年${state.time.date.month}月${state.time.date.day}日，天气${state.weather}。` },
        ], { temperature: 0.9, max_tokens: 80 })).trim();
      } catch (e) {}
    }
    if (!tip) {
      const tips = ['记录今天遇见的第一个人。', '写写窗外云栖市的天气与心情。', '把今天的小确幸留进日记里。', '回忆今天吃过的那顿饭。'];
      tip = tips[Math.floor(Math.random() * tips.length)];
    }
    if (btn) { btn.textContent = '⟳'; btn.disabled = false; }
    ctx.toast('灵感：' + tip);
  }

  function save(content, title, weather, mood, isPublic, date) {
    if (!state.phone.diary) state.phone.diary = [];
    const y = date ? date.y : state.time.date.year;
    const m = date ? date.m : state.time.date.month;
    const d = date ? date.d : state.time.date.day;
    const ts = date ? new Date(y, m - 1, d).getTime() : Date.now();
    state.phone.diary.push({ day: state.time.day, title, content, weather, mood, public: isPublic, ts });
    recordMemory(state, '日记：' + content.slice(0, 40) + (content.length > 40 ? '…' : ''));
    ctx.save();
  }
}
