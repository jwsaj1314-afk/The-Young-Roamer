import { MUSIC_TRACKS } from '../../data/misc.js';

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  let audio = null;
  screen.className = 'phone-app-screen app-music';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="muBack">‹</button>
      <div class="phone-app-title">音乐</div>
      <button class="phone-back-btn" id="muRefresh" title="刷新">⟳</button>
    </div>
    <div class="phone-app-body" id="muBody"></div>`;
  screen.querySelector('#muBack').addEventListener('click', () => {
    if (audio) { audio.pause(); audio.src = ''; }
    ctx.back();
  });
  screen.querySelector('#muRefresh').addEventListener('click', () => {
    ctx.toast('今日推荐：' + MUSIC_TRACKS[Math.floor(Math.random() * MUSIC_TRACKS.length)].name);
  });
  if (!state.phone.playMode) state.phone.playMode = 'list';
  render();

  function render() {
    const body = screen.querySelector('#muBody');
    const current = state.phone.currentTrack || 0;
    const track = MUSIC_TRACKS[current];
    const playing = state.phone.playing;
    const mode = state.phone.playMode;
    body.innerHTML = `
      <div class="music-player">
        <div class="music-disc ${playing ? 'playing' : ''}" id="muDisc">🎵</div>
        <div class="music-title" id="muTitle">${track ? track.name : '暂无曲目'}</div>
        <div class="music-artist">${track && track.artist ? track.artist : '清姈工作室选曲'}</div>
        <div class="music-controls">
          <button id="muPrev">⏮</button>
          <button class="play" id="muToggle">${playing ? '⏸' : '▶'}</button>
          <button id="muNext">⏭</button>
        </div>
        <button class="music-mode" id="muMode">${mode === 'list' ? '🔁 列表循环' : '🔂 单曲循环'}</button>
      </div>
      <div class="music-list">
        ${MUSIC_TRACKS.map((m, i) => `
          <div class="music-row ${i === current ? 'active' : ''}" data-i="${i}">
            <div class="music-row-index">${i + 1}</div>
            <div class="music-row-name">${m.name}</div>
            ${i === current && playing ? '<span class="tag">播放中</span>' : ''}
          </div>`).join('')}
      </div>`;
    body.querySelector('#muPrev').addEventListener('click', () => {
      state.phone.currentTrack = (current - 1 + MUSIC_TRACKS.length) % MUSIC_TRACKS.length;
      play();
    });
    body.querySelector('#muNext').addEventListener('click', () => {
      state.phone.currentTrack = (current + 1) % MUSIC_TRACKS.length;
      play();
    });
    body.querySelector('#muToggle').addEventListener('click', toggle);
    body.querySelector('#muMode').addEventListener('click', () => {
      state.phone.playMode = state.phone.playMode === 'list' ? 'single' : 'list';
      if (audio) audio.loop = state.phone.playMode === 'single';
      ctx.save();
      render();
    });
    body.querySelectorAll('.music-row').forEach((el) => {
      el.addEventListener('click', () => {
        state.phone.currentTrack = parseInt(el.dataset.i, 10);
        play();
      });
    });
  }

  function toggle() {
    if (!state.phone.playing) play();
    else pause();
  }

  function play() {
    const track = MUSIC_TRACKS[state.phone.currentTrack];
    if (!track) return;
    try {
      if (audio) { audio.pause(); audio.src = ''; }
      audio = new Audio(track.url);
      audio.loop = state.phone.playMode === 'single';
      audio.addEventListener('ended', () => {
        if (state.phone.playMode === 'list') {
          state.phone.currentTrack = (state.phone.currentTrack + 1) % MUSIC_TRACKS.length;
          play();
        } else {
          state.phone.playing = false;
          ctx.save();
          render();
        }
      });
      audio.play().catch(() => {});
    } catch (e) {}
    state.phone.playing = true;
    ctx.save();
    render();
  }

  function pause() {
    if (audio) audio.pause();
    state.phone.playing = false;
    ctx.save();
    render();
  }
}
