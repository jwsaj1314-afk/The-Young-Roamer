import { CHARACTERS } from '../../data/characters.js';
import { avatarColor, todayBirthdays } from './common.js';

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-calendar';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="clBack">‹</button>
      <div class="phone-app-title">日历</div>
      <button class="phone-back-btn" id="clRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="clNew" title="新建日程">＋</button>
    </div>
    <div class="phone-app-body" id="clBody"></div>`;
  screen.querySelector('#clBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#clNew').addEventListener('click', () => editEvent(null));
  screen.querySelector('#clRefresh').addEventListener('click', () => refreshSuggestion());
  let viewY = state.time.date.year;
  let viewM = state.time.date.month;
  let listMode = false;
  render();

  function refreshSuggestion() {
    const tips = ['宜与友人共进晚餐', '适合整理房间与心情', '宜早睡，养足精神', '适合去镜湖散步', '宜写信问候远方的朋友'];
    const tip = tips[Math.floor(Math.random() * tips.length)];
    ctx.toast('今日宜：' + tip);
    render();
  }

  function charBirthday(c) {
    if (!c.birthday) {
      const h = [...c.id].reduce((a, ch) => a + ch.charCodeAt(0), 0);
      return { month: (h % 12) + 1, day: (h * 7 % 28) + 1 };
    }
    return c.birthday;
  }
  function knownBirthdays() {
    const out = [];
    CHARACTERS.forEach((c) => {
      const r = state.relations[c.id];
      if (r && r.met) {
        const b = charBirthday(c);
        out.push({ id: c.id, name: c.name, ...b });
      }
    });
    return out;
  }

  function render() {
    const body = screen.querySelector('#clBody');
    if (listMode) return renderList(body);
    renderMonth(body);
  }

  function renderMonth(body) {
    const t = state.time.date;
    const first = new Date(viewY, viewM - 1, 1).getDay();
    const days = new Date(viewY, viewM, 0).getDate();
    const bdays = knownBirthdays().filter((b) => b.month === viewM);
    const bdayMap = {};
    bdays.forEach((b) => { (bdayMap[b.day] = bdayMap[b.day] || []).push(b.name); });
    const events = (state.phone.calendar.events || []).filter((e) => {
      const d = parseD(e.date);
      return d.m === viewM && d.y === viewY;
    });
    const eventMap = {};
    events.forEach((e) => { (eventMap[parseD(e.date).d] = eventMap[parseD(e.date).d] || []).push(e); });

    let cells = '';
    for (let i = 0; i < first; i++) cells += `<div class="cal-cell other"></div>`;
    for (let d = 1; d <= days; d++) {
      const isToday = viewY === t.year && viewM === t.month && d === t.day;
      const hasB = bdayMap[d];
      const hasE = eventMap[d];
      cells += `
        <div class="cal-cell ${isToday ? 'today' : ''}" data-day="${d}">
          ${d}
          <div class="cal-dots">
            ${hasB ? '<span class="cal-dot bday"></span>' : ''}
            ${hasE ? '<span class="cal-dot event"></span>' : ''}
          </div>
        </div>`;
    }

    body.innerHTML = `
      <div class="cal-head">
        <button class="cal-nav" id="calPrev">‹</button>
        <div class="cal-title">${viewY}年${viewM}月</div>
        <button class="cal-nav" id="calNext">›</button>
      </div>
      <div class="cal-week">${['日', '一', '二', '三', '四', '五', '六'].map((w) => `<div>${w}</div>`).join('')}</div>
      <div class="cal-grid">${cells}</div>
      <div class="cal-toggle-row">
        <button class="btn btn-sm" id="clToggleList">列表视图</button>
      </div>
      <div class="cal-events">
        <div class="panel-sec">本月特殊日期</div>
        ${(bdays.length || events.length) ? '' : '<div style="font-size:12px;color:var(--text-faint);">本月暂无已记录的特殊日期</div>'}
        ${bdays.map((b) => `<div style="font-size:13px;padding:4px 0;color:var(--text-secondary);">${viewM}月${b.day}日 · ${b.name}的生日 🎂</div>`).join('')}
        ${events.map((e) => {
          const d = parseD(e.date);
          return `<div style="font-size:13px;padding:4px 0;color:var(--text-secondary);">${d.m}月${d.d}日 · ${e.title} ${e.type ? '[' + e.type + ']' : ''}</div>`;
        }).join('')}
      </div>`;
    body.querySelector('#calPrev').addEventListener('click', () => { viewM--; if (viewM < 1) { viewM = 12; viewY--; } render(); });
    body.querySelector('#calNext').addEventListener('click', () => { viewM++; if (viewM > 12) { viewM = 1; viewY++; } render(); });
    body.querySelector('#clToggleList').addEventListener('click', () => { listMode = true; render(); });
    body.querySelectorAll('.cal-cell[data-day]').forEach((el) => {
      el.addEventListener('click', () => dayDetail(parseInt(el.dataset.day, 10)));
    });
    const grid = body.querySelector('.cal-grid');
    if (grid) {
      let gx = 0, gy = 0, gLock = false;
      grid.addEventListener('touchstart', (e) => {
        const t = e.touches[0];
        gx = t.clientX; gy = t.clientY; gLock = false;
      }, { passive: true });
      grid.addEventListener('touchmove', (e) => {
        if (gLock) return;
        const t = e.touches[0];
        if (Math.abs(t.clientX - gx) > 12 && Math.abs(t.clientX - gx) > Math.abs(t.clientY - gy)) {
          gLock = true;
          if (t.clientX - gx < 0) { viewM++; if (viewM > 12) { viewM = 1; viewY++; } }
          else { viewM--; if (viewM < 1) { viewM = 12; viewY--; } }
          render();
        }
      }, { passive: true });
    }
  }

  function renderList(body) {
    const bdays = knownBirthdays().map((b) => ({ ...b, title: b.name + '的生日', type: '生日', isBday: true }));
    const events = (state.phone.calendar.events || []).map((e) => ({ ...e, isBday: false }));
    const all = [...bdays, ...events].map((e) => {
      const d = e.isBday ? { y: viewY, m: e.month, d: e.day } : parseD(e.date);
      return { ...e, y: d.y, m: d.m, d: d.d, ts: new Date(d.y, d.m - 1, d.d).getTime() };
    }).sort((a, b) => a.ts - b.ts);
    const now = new Date(state.time.date.year, state.time.date.month - 1, state.time.date.day).getTime();
    const soon = all.filter((e) => e.ts >= now && e.ts - now <= 7 * 86400000);

    body.innerHTML = `
      <div class="cal-toggle-row">
        <button class="btn btn-sm" id="clToggleMonth">月视图</button>
      </div>
      <div class="cal-events">
        ${soon.length ? `
          <div class="panel-sec">即将到来（7天内）</div>
          ${soon.map((e) => `<div class="cal-list-item soon"><span class="cal-list-date">${e.m}月${e.d}日</span><b>${e.title}</b><span class="tag">即将到来</span></div>`).join('')}
        ` : ''}
        <div class="panel-sec">全部特殊日期</div>
        ${all.length ? '' : '<div style="font-size:12px;color:var(--text-faint);">还没有记录任何特殊日期</div>'}
        ${all.map((e) => `<div class="cal-list-item ${e.isBday ? 'bday' : ''}"><span class="cal-list-date">${e.m}月${e.d}日</span><b>${e.title}</b>${e.type ? `<span class="tag">${e.type}</span>` : ''}</div>`).join('')}
      </div>`;
    body.querySelector('#clToggleMonth').addEventListener('click', () => { listMode = false; render(); });
  }

  function dayDetail(day) {
    const body = screen.querySelector('#clBody');
    ctx.setBack(render);
    const bdays = knownBirthdays().filter((b) => b.month === viewM && b.day === day);
    const events = (state.phone.calendar.events || []).filter((e) => {
      const d = parseD(e.date);
      return d.y === viewY && d.m === viewM && d.d === day;
    });
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <button class="btn btn-sm" id="clDBack">‹ 返回</button>
        <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">${viewY}年${viewM}月${day}日</span>
      </div>
      <div class="cal-events">
        ${bdays.map((b) => `<div style="font-size:13px;padding:6px 0;color:var(--text-secondary);">🎂 ${b.name}的生日</div>`).join('')}
        ${events.length ? '' : '<div style="font-size:12px;color:var(--text-faint);">当天没有日程</div>'}
        ${events.map((e) => `
          <div style="font-size:13px;padding:8px 0;border-bottom:1px dashed rgba(150,170,190,0.3);" data-ev="${e.id}">
            <b style="color:var(--accent-deep);">${e.title}</b> ${e.type ? `<span class="tag">${e.type}</span>` : ''}
            ${e.note ? `<div style="font-size:12px;color:var(--text-secondary);margin-top:2px;">${e.note}</div>` : ''}
            <div style="font-size:11px;color:var(--text-faint);margin-top:4px;">
              <button class="btn btn-sm" data-edit="${e.id}">编辑</button>
              <button class="btn btn-sm btn-danger" data-del="${e.id}">删除</button>
            </div>
          </div>`).join('')}
        <button class="btn btn-sm" id="clDNew" style="margin-top:12px;">＋ 新建日程</button>
      </div>`;
    body.querySelector('#clDBack').addEventListener('click', render);
    body.querySelector('#clDNew').addEventListener('click', () => editEvent(null, { y: viewY, m: viewM, d: day }));
    body.querySelectorAll('[data-edit]').forEach((el) => {
      el.addEventListener('click', () => editEvent(el.dataset.edit));
    });
    body.querySelectorAll('[data-del]').forEach((el) => {
      el.addEventListener('click', () => {
        const ev = state.phone.calendar.events;
        const i = ev.findIndex((x) => x.id === el.dataset.del);
        if (i >= 0) { ev.splice(i, 1); ctx.save(); ctx.toast('已删除'); render(); }
      });
    });
  }

  function editEvent(evId, preset) {
    const body = screen.querySelector('#clBody');
    ctx.setBack(render);
    const ev = evId ? (state.phone.calendar.events || []).find((e) => e.id === evId) : null;
    const d = preset || (ev ? parseD(ev.date) : { y: state.time.date.year, m: state.time.date.month, d: state.time.date.day });
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <button class="btn btn-sm" id="clEBack">‹ 返回</button>
        <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">${ev ? '编辑日程' : '新建日程'}</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:10px;font-size:13px;">
        <div><label style="display:block;margin-bottom:4px;">标题（必填）</label><input type="text" id="clETitle" value="${ev ? ev.title : ''}" placeholder="日程标题…"></div>
        <div style="display:flex;gap:8px;">
          <div style="flex:1;"><label style="display:block;margin-bottom:4px;">年</label><input type="number" id="clEY" value="${d.y}" min="2024" max="2035"></div>
          <div style="flex:1;"><label style="display:block;margin-bottom:4px;">月</label><input type="number" id="clEM" value="${d.m}" min="1" max="12"></div>
          <div style="flex:1;"><label style="display:block;margin-bottom:4px;">日</label><input type="number" id="clED" value="${d.d}" min="1" max="31"></div>
        </div>
        <div><label style="display:block;margin-bottom:4px;">类型标签</label>
          <select id="clEType">
            ${['生日', '纪念日', '考试', '重要活动', '提醒事项', '自定义'].map((t) => `<option value="${t}" ${ev && ev.type === t ? 'selected' : ''}>${t}</option>`).join('')}
          </select>
          <input type="text" id="clECustom" placeholder="自定义标签" style="margin-top:6px;display:none;">
        </div>
        <div><label style="display:block;margin-bottom:4px;">备注（选填）</label><textarea id="clENote" placeholder="详细说明…" style="width:100%;min-height:70px;font-size:13px;line-height:1.6;resize:none;">${ev ? ev.note || '' : ''}</textarea></div>
        <div style="display:flex;align-items:center;gap:8px;"><label>当天提醒</label><label class="switch"><input type="checkbox" id="clERemind" ${ev && ev.remind ? 'checked' : ''}><span class="slider"></span></label></div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm btn-primary" id="clESave">保存</button>
          ${ev ? `<button class="btn btn-sm btn-danger" id="clEDel">删除</button>` : ''}
        </div>
      </div>`;
    body.querySelector('#clEBack').addEventListener('click', render);
    body.querySelector('#clEType').addEventListener('change', (e) => {
      body.querySelector('#clECustom').style.display = e.target.value === '自定义' ? 'block' : 'none';
    });
    if (ev && ev.type === '自定义') body.querySelector('#clECustom').style.display = 'block';
    body.querySelector('#clESave').addEventListener('click', () => {
      const title = body.querySelector('#clETitle').value.trim();
      if (!title) return ctx.toast('标题不能为空');
      const y = parseInt(body.querySelector('#clEY').value, 10);
      const m = parseInt(body.querySelector('#clEM').value, 10);
      const dd = parseInt(body.querySelector('#clED').value, 10);
      const type = body.querySelector('#clEType').value;
      const note = body.querySelector('#clENote').value.trim();
      const remind = body.querySelector('#clERemind').checked;
      const data = { title, date: `${y}-${String(m).padStart(2, '0')}-${String(dd).padStart(2, '0')}`, type: type === '自定义' ? (body.querySelector('#clECustom').value.trim() || '自定义') : type, note, remind };
      if (!state.phone.calendar.events) state.phone.calendar.events = [];
      if (ev) {
        Object.assign(ev, data);
        ctx.toast('已保存');
      } else {
        data.id = 'ev' + Date.now();
        state.phone.calendar.events.push(data);
        if (data.remind && isSameDay(data.date)) {
          if (!state.phone.notifications) state.phone.notifications = [];
          state.phone.notifications.push({ app: '日历', text: '今天有日程：' + data.title, time: formatTime(new Date()) });
        }
        ctx.toast('已创建日程');
      }
      ctx.save();
      render();
    });
    if (ev) body.querySelector('#clEDel').addEventListener('click', () => {
      const evs = state.phone.calendar.events;
      const i = evs.findIndex((x) => x.id === ev.id);
      if (i >= 0) evs.splice(i, 1);
      ctx.save();
      ctx.toast('已删除');
      render();
    });
  }

  function parseD(s) {
    const [y, m, d] = s.split('-').map(Number);
    return { y, m, d };
  }
  function isSameDay(dateStr) {
    const d = parseD(dateStr);
    const t = state.time.date;
    return d.y === t.year && d.m === t.month && d.d === t.day;
  }
  function formatTime(dt) {
    return `${String(dt.getHours()).padStart(2, '0')}:${String(dt.getMinutes()).padStart(2, '0')}`;
  }
}
