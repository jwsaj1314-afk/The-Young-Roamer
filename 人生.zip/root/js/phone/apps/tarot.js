import { TAROT } from '../../data/misc.js';
import { getPeriod } from '../../core/utils.js';
import { PLACES } from '../../data/world.js';

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-tarot';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="trBack">‹</button>
      <div class="phone-app-title">塔罗蜜语</div>
      <button class="phone-back-btn" id="trRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="trHistory" title="历史记录">🕘</button>
    </div>
    <div class="phone-app-body" id="trBody"></div>`;
  screen.querySelector('#trBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#trHistory').addEventListener('click', renderHistory);
  screen.querySelector('#trRefresh').addEventListener('click', () => refreshTip());
  renderHome();

  function todayKey() {
    const d = state.time.date;
    return `${d.year}-${d.month}-${d.day}`;
  }
  function dailyUsed() {
    return (state.phone.tarot.lastDate || '') === todayKey();
  }

  function fullDeck() {
    const deck = [];
    (TAROT.majorArcana || []).forEach((c) => {
      deck.push({ name: c.name, keywords: c.keywords, reversed: c.reversed, group: '大阿卡纳' });
    });
    const ranks = ['王牌', '二', '三', '四', '五', '六', '七', '八', '九', '十', '侍从', '骑士', '皇后', '国王'];
    (TAROT.minorArcanaSuits || []).forEach((suit) => {
      ranks.forEach((rank) => {
        deck.push({
          name: `${suit.name}·${rank}`,
          keywords: suit.keywords,
          reversed: suit.keywords,
          group: '小阿卡纳',
          element: suit.element,
        });
      });
    });
    return deck;
  }

  function renderHome() {
    const body = screen.querySelector('#trBody');
    const used = dailyUsed();
    const hist = state.phone.tarot.history || [];
    body.innerHTML = `
      <div class="tarot-card">
        <div class="tarot-face back">🔮</div>
        <div class="tarot-name">云栖塔罗</div>
        <div style="font-size:12px;color:var(--text-secondary);margin-top:8px;line-height:1.7;">
          静谧的牌面折射今日的天光。
          今日剩余占卜次数：<b style="color:var(--accent-deep);">${used ? 0 : 1}</b>。
        </div>
        ${used ? '' : '<button class="btn btn-primary btn-lg tarot-flip" id="trDraw">开始占卜</button>'}
        <div class="panel-sec" style="margin-top:20px;text-align:left;">今日提示</div>
        <div style="text-align:left;font-size:12px;color:var(--text-secondary);line-height:1.8;margin-top:4px;">${dailyTip()}</div>
      </div>`;
    const drawBtn = body.querySelector('#trDraw');
    if (drawBtn) drawBtn.addEventListener('click', () => draw());
  }

  function dailyTip() {
    const p = state.player;
    const parts = [];
    if (p.mood >= 70) parts.push('心情轻盈，适合主动社交。');
    else if (p.mood >= 40) parts.push('心情平稳，宜循序渐进。');
    else parts.push('心情低落的当下，记得给自己留些温柔。');
    const per = getPeriod(state.time.hour);
    if (per === '清晨') parts.push('清晨的直觉最准。');
    if (per === '深夜') parts.push('夜深了，把今天的事悄悄收好。');
    return parts.join(' ');
  }

  function refreshTip() {
    ctx.toast('今日塔罗已刷新：' + dailyTip());
    renderHome();
  }

  function draw() {
    const body = screen.querySelector('#trBody');
    ctx.setBack(renderHome);
    body.innerHTML = `
      <div class="tarot-card">
        <div class="tarot-face back" id="trCard" style="cursor:pointer;">🃏</div>
        <div style="font-size:13px;color:var(--text-secondary);margin-top:10px;">轻触牌面，切牌抽三张</div>
        <div style="font-size:12px;color:var(--text-faint);margin-top:6px;">过去 · 现在 · 未来</div>
      </div>`;
    body.querySelector('#trCard').addEventListener('click', () => reveal());
  }

  function reveal() {
    const body = screen.querySelector('#trBody');
    const deck = fullDeck();
    const picked = [];
    const pool = [...deck];
    while (picked.length < 3 && pool.length) {
      const i = Math.floor(Math.random() * pool.length);
      picked.push(pool.splice(i, 1)[0]);
    }
    const cards = picked.map((c) => ({ ...c, reversed: Math.random() < 0.3 }));
    const keyPhrase = fortuneKey(cards);
    const eventHint = randomEventHint(cards);
    const eventBoost = Math.round((Math.random() < 0.5 ? 1 : -1) * 15);

    state.phone.tarot.lastDate = todayKey();
    state.phone.tarot.lastReading = { cards, key: keyPhrase, event: eventHint, eventBoost, day: state.time.day, ts: Date.now() };
    state.phone.tarot.lastEventBoost = eventBoost;
    state.phone.tarot.lastFortuneKey = keyPhrase;
    if (!state.phone.tarot.history) state.phone.tarot.history = [];
    state.phone.tarot.history.push(state.phone.tarot.lastReading);
    ctx.save();

    body.innerHTML = `
      <div class="tarot-card">
        <div style="font-size:13px;font-weight:600;color:var(--accent-deep);margin-bottom:12px;">今日运势牌阵</div>
        <div class="tarot-spread">
          ${cards.map((c, i) => `
            <div class="tarot-spread-card">
              <div class="tarot-face ${c.reversed ? 'down' : 'up'}" style="font-size:18px;">${['✦', '☾', '★'][i]}</div>
              <div class="tarot-spread-role">${['过去', '现在', '未来'][i]}</div>
              <div class="tarot-spread-name">${c.name}</div>
              <div class="tarot-spread-suit">${c.group} · ${c.reversed ? '逆位' : '正位'}</div>
            </div>`).join('')}
        </div>
        <div class="tarot-keys" style="margin-top:14px;">${keyPhrase}</div>
        <div class="tarot-event">${eventHint}</div>
        <div style="font-size:11px;color:var(--text-faint);margin-top:8px;">今日特定事件触发概率${eventBoost > 0 ? '+' : ''}${eventBoost}%（${eventBoost > 0 ? '幸运' : '需留意'}）</div>
        <button class="btn btn-primary btn-lg tarot-flip" id="trSave">收好牌面</button>
      </div>`;
    body.querySelector('#trSave').addEventListener('click', renderHome);
  }

  function fortuneKey(cards) {
    const kw = cards.map((c) => c.keywords[Math.floor(Math.random() * Math.min(2, c.keywords.length))]);
    const phrases = [
      `今日宜${kw[0]}，${kw[1]}正合时宜`,
      `${kw[0]}的气息贯穿今日，宜${kw[1]}`,
      `让${kw[0]}为你开路，同时留意${kw[2] || kw[1]}`,
      `今日关键词：${kw[0]}、${kw[1]}${kw[2] ? '、' + kw[2] : ''}`,
    ];
    return phrases[Math.floor(Math.random() * phrases.length)];
  }

  function randomEventHint(cards) {
    const places = (PLACES || []).slice(0, 20);
    const where = places.length ? places[Math.floor(Math.random() * places.length)].name : '云栖市';
    const events = [
      `今天可能在某处（如${where}）遇见重要的人`,
      `下午在${where}附近，有机会获得意外的好运`,
      `傍晚时分，${where}一带或有惊喜发生`,
      `今天适合去${where}走走，也许会有新的际遇`,
    ];
    return '随机事件提示：' + events[Math.floor(Math.random() * events.length)];
  }

  function renderHistory() {
    const body = screen.querySelector('#trBody');
    ctx.setBack(renderHome);
    const hist = state.phone.tarot.history || [];
    body.innerHTML = `
      <div style="padding:4px 2px 10px;font-size:13px;color:var(--text-secondary);">历史记录（共 ${hist.length} 次）</div>
      ${hist.length ? '' : '<div class="empty-hint">还没有占卜记录</div>'}
      ${[...hist].reverse().map((h, i) => `
        <div class="tarot-hist-item" data-idx="${i}" style="cursor:pointer;">
          <div class="tarot-hist-date">第${h.day}天 · ${h.ts ? new Date(h.ts).toLocaleDateString() : ''}</div>
          <div class="tarot-hist-cards">${h.cards.map((c) => `${c.name}${c.reversed ? '（逆）' : ''}`).join(' / ')}</div>
          <div class="tarot-hist-key">${h.key}</div>
        </div>`).join('')}
      <button class="btn btn-sm" id="trBackHome" style="margin-top:12px;">返回</button>`;
    body.querySelectorAll('.tarot-hist-item').forEach((el) => {
      el.addEventListener('click', () => viewHist(hist.length - 1 - parseInt(el.dataset.idx, 10)));
    });
    body.querySelector('#trBackHome').addEventListener('click', renderHome);
  }

  function viewHist(histIdx) {
    const body = screen.querySelector('#trBody');
    ctx.setBack(renderHistory);
    const h = (state.phone.tarot.history || [])[histIdx];
    if (!h) return;
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <button class="btn btn-sm" id="trHBack">‹ 返回</button>
        <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">第${h.day}天 · 占卜详情</span>
      </div>
      <div class="tarot-card">
        <div class="tarot-spread">
          ${h.cards.map((c, i) => `
            <div class="tarot-spread-card">
              <div class="tarot-face ${c.reversed ? 'down' : 'up'}" style="font-size:18px;">${['✦', '☾', '★'][i]}</div>
              <div class="tarot-spread-role">${['过去', '现在', '未来'][i]}</div>
              <div class="tarot-spread-name">${c.name}</div>
              <div class="tarot-spread-suit">${c.group || ''} · ${c.reversed ? '逆位' : '正位'}</div>
              <div style="font-size:11px;color:var(--text-secondary);margin-top:4px;line-height:1.5;">${(c.reversed ? c.reversed : c.keywords || []).slice(0, 2).join('、')}</div>
            </div>`).join('')}
        </div>
        <div class="tarot-keys" style="margin-top:14px;">${h.key}</div>
        ${h.event ? `<div class="tarot-event">${h.event}</div>` : ''}
        ${h.eventBoost ? `<div style="font-size:11px;color:var(--text-faint);margin-top:8px;">当日事件概率${h.eventBoost > 0 ? '+' : ''}${h.eventBoost}%</div>` : ''}
      </div>`;
    body.querySelector('#trHBack').addEventListener('click', renderHistory);
  }
}
