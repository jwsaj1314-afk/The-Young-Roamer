import { avatarColor } from './common.js';
import { SAVE_VERSION } from '../../core/state.js';

const WP = {
  spring: '春·樱落', summer: '夏·碧海', autumn: '秋·枫红', winter: '冬·雪寂',
  cityNight: '城市夜景', cloudForest: '云栖林海', minimalMoon: '极简月灰', darkInk: '深色砚蓝',
};

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-psettings';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="psBack">‹</button>
      <div class="phone-app-title">手机设置</div>
      <button class="phone-back-btn" id="psRefresh" title="刷新">⟳</button>
    </div>
    <div class="phone-app-body" id="psBody"></div>`;
  screen.querySelector('#psBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#psRefresh').addEventListener('click', () => {
    ctx.toast('云栖 OS 已是最新版本');
    render();
  });
  render();

  function render() {
    const body = screen.querySelector('#psBody');
    const q = state.phone;
    body.innerHTML = `
      <div class="pset-sec">账号与安全</div>
      <div class="pset-row">
        <span>QQ 号</span>
        <input type="text" id="psQQId" value="${q.qq.id || ''}" maxlength="15" style="width:130px;font-size:12px;">
      </div>
      <div class="pset-row">
        <span>QQ 昵称</span>
        <input type="text" id="psQQ" value="${q.qq.nick || ''}" maxlength="10" style="width:130px;font-size:12px;">
      </div>
      <div class="pset-row">
        <span>论坛昵称</span>
        <input type="text" id="psForum" value="${q.forumNick || ''}" maxlength="12" style="width:130px;font-size:12px;">
      </div>
      <div class="pset-row">
        <span>电子邮箱</span>
        <input type="email" id="psEmail" value="${q.email || ''}" maxlength="40" style="width:160px;font-size:12px;">
      </div>
      <div class="pset-sec">外观</div>
      <div class="pset-row">
        <span>手机壁纸</span>
        <div class="wp-grid">
          ${Object.keys(WP).map((w) => `
            <div class="wp-cell ${q.wallpaper === w ? 'selected' : ''}" data-w="${w}">
              <div class="wp-thumb" style="background:${wpBg(w)}"></div>
              <div class="wp-name">${WP[w]}</div>
            </div>`).join('')}
          <div class="wp-cell" data-w="import">
            <div class="wp-thumb wp-import">＋</div>
            <div class="wp-name">导入图片</div>
          </div>
        </div>
        <input type="file" accept="image/*" id="psWpFile" style="display:none;">
      </div>
      <div class="pset-row">
        <span>字体大小</span>
        <div style="display:flex;align-items:center;gap:8px;">
          <input type="range" min="13" max="19" step="1" value="${q.fontScale || 15}" id="psFont" style="width:110px;">
          <span class="pset-val" id="psFontVal">${q.fontScale || 15}px</span>
        </div>
      </div>
      <div class="pset-sec">其他</div>
      <div class="pset-row">
        <span>版本号</span>
        <span class="pset-val">云栖 OS 3.0 · 此间少年行 v${SAVE_VERSION}.0.0</span>
      </div>
      <div class="pset-row">
        <span>清除本地数据</span>
        <button class="btn btn-sm btn-danger" id="psClear">清除</button>
      </div>
      <div class="panel-tip">修改 QQ/论坛昵称与邮箱后，对应社交内容会同步更新。</div>`;
    body.querySelectorAll('[data-w]').forEach((el) => {
      el.addEventListener('click', () => {
        const w = el.dataset.w;
        if (w === 'import') {
          body.querySelector('#psWpFile').click();
          return;
        }
        body.querySelectorAll('[data-w]').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        q.wallpaper = w;
        ctx.save();
        ctx.render();
        ctx.toast('壁纸已更换');
      });
    });
    const file = body.querySelector('#psWpFile');
    file.addEventListener('change', () => {
      const f = file.files && file.files[0];
      if (!f) return;
      const reader = new FileReader();
      reader.onload = () => {
        q.wallpaper = 'custom:' + reader.result;
        ctx.save();
        ctx.render();
        ctx.toast('壁纸已导入');
      };
      reader.readAsDataURL(f);
    });
    const font = body.querySelector('#psFont');
    font.addEventListener('input', () => {
      q.fontScale = parseInt(font.value, 10);
      body.querySelector('#psFontVal').textContent = q.fontScale + 'px';
      document.documentElement.style.setProperty('--font-size', q.fontScale + 'px');
      ctx.save();
    });
    body.querySelector('#psQQId').addEventListener('change', (e) => {
      q.qq.id = e.target.value.trim() || '13702149922';
      ctx.save();
    });
    body.querySelector('#psQQ').addEventListener('change', (e) => {
      q.qq.nick = e.target.value.trim() || '小华';
      ctx.save();
    });
    body.querySelector('#psForum').addEventListener('change', (e) => {
      q.forumNick = e.target.value.trim() || '云栖新芽';
      ctx.save();
    });
    body.querySelector('#psEmail').addEventListener('change', (e) => {
      q.email = e.target.value.trim() || 'xiaohua@yunqimail.cn';
      ctx.save();
    });
    body.querySelector('#psClear').addEventListener('click', () => {
      if (window.confirm('确定清除全部本地存档？此操作不可恢复。')) {
        try {
          localStorage.removeItem('cijian_save_v3');
          localStorage.removeItem('cijian_autosave_v3');
          localStorage.removeItem('cijian_disclaimer');
          for (let i = 1; i <= 20; i++) localStorage.removeItem(`cijian_slot_${i}`);
        } catch (e) {}
        window.location.reload();
      }
    });
  }

  function wpBg(w) {
    return {
      spring: 'linear-gradient(160deg, #FDE8EF, #F7C7D9, #E8F5E9)',
      summer: 'linear-gradient(160deg, #D6F0FF, #9ED6F0, #FDEBC8)',
      autumn: 'linear-gradient(160deg, #FDEAD2, #F0B88C, #C97B63)',
      winter: 'linear-gradient(160deg, #F2F6FA, #D9E4EE, #C3D2E0)',
      cityNight: 'linear-gradient(160deg, #2C3A52, #4A5B7A, #F2C94C)',
      cloudForest: 'linear-gradient(160deg, #E4F1E8, #B7D6C0, #8FBFA0)',
      minimalMoon: 'linear-gradient(160deg, #EFEFEF, #D8D8D8, #BDBDBD)',
      darkInk: 'linear-gradient(160deg, #1B2536, #2E3B52, #0F1622)',
    }[w] || 'linear-gradient(160deg, #D6F0FF, #9ED6F0, #FDEBC8)';
  }
}
