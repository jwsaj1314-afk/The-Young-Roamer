import { isAIReady, chat, buildSystemPrompt } from '../../core/ai.js';
import { avatarColor } from './common.js';

const BOARD_CATS = [
  { id: 'chat', name: '闲聊茶馆' },
  { id: 'school', name: '校园生活' },
  { id: 'art', name: '艺术创作' },
  { id: 'city', name: '城市话题' },
  { id: 'trade', name: '二手交易' },
  { id: 'help', name: '求助问答' },
];

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-forum';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="fbBack">‹</button>
      <div class="phone-app-title">云栖论坛</div>
      <button class="phone-back-btn" id="fbRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="fbNew" title="发帖">✎</button>
    </div>
    <div class="phone-app-body" id="fbBody"></div>`;
  screen.querySelector('#fbBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#fbNew').addEventListener('click', () => compose());
  screen.querySelector('#fbRefresh').addEventListener('click', () => refreshFeed());
  let tab = 'recommend';
  let boardView = null;
  seed();
  render();

  async function refreshFeed() {
    const f = state.phone.forum;
    const btn = screen.querySelector('#fbRefresh');
    if (btn) { btn.textContent = '…'; btn.disabled = true; }
    let title = '', content = '';
    if (isAIReady()) {
      const sys = buildSystemPrompt(state, '玩家在云栖论坛刷新动态。');
      try {
        const res = (await chat([
          { role: 'system', content: sys.system + '\n请生成一条云栖市论坛的新帖子，格式为「标题|正文」，标题15字内，正文60字内，有生活气息。' },
          { role: 'user', content: '生成一条新帖子。' },
        ], { temperature: 0.95, max_tokens: 200 })).trim();
        const parts = res.split('|');
        title = (parts[0] || '').trim();
        content = (parts[1] || parts[0] || '').trim();
      } catch (e) {}
    }
    if (!content) {
      const pool = [
        ['镜湖夜景真的美', '晚上沿着湖边走走，风很舒服。'],
        ['今天面包店打折', '麦香晨光的可颂买三送一，冲！'],
        ['求推荐一本好书', '最近想找本温暖的小说，大家有推荐吗？'],
        ['新开了家咖啡店', '巷口那家店拉花很好看，老板人也好。'],
      ];
      [title, content] = pool[Math.floor(Math.random() * pool.length)];
    }
    f.posts.unshift({ id: 'p' + Date.now(), author: randomForumUser(), board: BOARD_CATS[Math.floor(Math.random() * BOARD_CATS.length)].id, title: title || '（无标题）', ts: Date.now(), content: content || '…', likes: 0, replies: 0, myLike: false, myCollect: false });
    ctx.save();
    if (btn) { btn.textContent = '⟳'; btn.disabled = false; }
    ctx.toast('已刷新出新帖');
    render();
  }

  function randomForumUser() {
    const users = ['云栖小鹿', '夜航星', '爱吃可颂', '街角的面包', '一只路过的猫', '南河的风', '白噪音'];
    return users[Math.floor(Math.random() * users.length)];
  }

  function seed() {
    const f = state.phone.forum;
    if (!f.posts) f.posts = [];
    if (!f.titles) f.titles = {};
    if (!f._seeded) {
      f._seeded = true;
      f.posts.unshift(
        { id: 'seed1', author: '云栖观察员', board: 'chat', ts: Date.now() - 86400000 * 3, title: '西山路新开的面包店绝了！', content: '麦香晨光的可颂一绝，推荐！', likes: 12, replies: 3, myLike: false, myCollect: false },
        { id: 'seed2', author: '夜航星', board: 'city', ts: Date.now() - 86400000 * 2, title: '老城区教堂的历史', content: '有谁知道老城区那座教堂的历史吗？路过时总觉得很神秘。', likes: 8, replies: 5, myLike: false, myCollect: false },
        { id: 'seed3', author: '一杯温水', board: 'city', ts: Date.now() - 86400000, title: '周末镜湖看花', content: '周末镜湖边的樱花开了，适合去散心。', likes: 21, replies: 6, myLike: false, myCollect: false },
      );
      ctx.save();
    }
  }

  function boardName(id) {
    const b = BOARD_CATS.find((x) => x.id === id);
    return b ? b.name : '闲聊茶馆';
  }

  function render() {
    const f = state.phone.forum;
    const body = screen.querySelector('#fbBody');
    let posts = [...f.posts];
    if (tab === 'latest') posts.sort((a, b) => b.ts - a.ts);
    if (tab === 'recommend') posts.sort((a, b) => (b.likes || 0) - (a.likes || 0));

    let content;
    if (boardView) {
      const bid = boardView;
      const list = posts.filter((p) => p.board === bid);
      content = `
        <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
          <button class="btn btn-sm" id="fbBoardBack">‹ 返回</button>
          <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">${boardName(bid)}</span>
        </div>
        ${list.length ? '' : '<div class="empty-hint">该板块还没有帖子</div>'}
        ${list.map((p, i) => renderPostCard(p, i)).join('')}`;
    } else if (tab === 'board') {
      content = renderBoards();
    } else {
      content = renderPosts(posts);
    }

    body.innerHTML = `
      <div style="padding:4px 2px 10px;font-size:12px;color:var(--text-secondary);display:flex;justify-content:space-between;">
        <span>我是：${state.phone.forumNick || '云栖新芽'}</span>
        <span>声望 ${f.rep || 0}${forumTitle(f.rep || 0)}</span>
      </div>
      ${boardView ? '' : `<div class="forum-tabs">
        <button class="forum-tab ${tab === 'recommend' ? 'active' : ''}" data-tab="recommend">推荐</button>
        <button class="forum-tab ${tab === 'latest' ? 'active' : ''}" data-tab="latest">最新</button>
        <button class="forum-tab ${tab === 'board' ? 'active' : ''}" data-tab="board">板块</button>
      </div>`}
      ${content}`;
    body.querySelectorAll('.forum-tab').forEach((b) => {
      b.addEventListener('click', () => { tab = b.dataset.tab; render(); });
    });
    if (boardView) {
      const bb = body.querySelector('#fbBoardBack');
      if (bb) bb.addEventListener('click', () => { boardView = null; render(); });
    }
    setTimeout(eventHook, 0);
  }

  function forumTitle(rep) {
    if (rep >= 100) return ' · 云栖百事通';
    if (rep >= 50) return ' · 城市通';
    if (rep >= 20) return ' · 活跃份子';
    return '';
  }

  function renderBoards() {
    return `
      <div class="forum-board-grid">
        ${BOARD_CATS.map((b) => `
          <div class="forum-board-cell" data-b="${b.id}">
            <div class="forum-board-name">${b.name}</div>
            <div class="forum-board-count">${(state.phone.forum.posts || []).filter((p) => p.board === b.id).length} 帖</div>
          </div>`).join('')}
      </div>`;
  }

  function renderPosts(posts) {
    return `
      ${posts.length ? '' : '<div class="empty-hint">还没有帖子</div>'}
      ${posts.map((p, i) => renderPostCard(p, i)).join('')}`;
  }

  function renderPostCard(p, i) {
    return `
        <div class="forum-post" data-idx="${i}">
          <div class="forum-post-head">
            <span class="forum-author">${p.author}</span>
            <span class="tag">#${boardName(p.board)}</span>
            <span class="forum-time">${timeAgo(p.ts)}</span>
          </div>
          <div class="forum-title">${p.title || ''}</div>
          <div class="forum-body">${p.content}</div>
          <div class="forum-foot">
            <span data-like="${i}">👍 ${p.likes || 0}</span>
            <span data-reply="${i}">💬 ${p.replies || 0}</span>
            <span data-collect="${i}">${p.myCollect ? '🔖 已收藏' : '🔖 收藏'}</span>
          </div>
        </div>`;
  }

  function eventHook() {
    const body = screen.querySelector('#fbBody');
    body.querySelectorAll('[data-like]').forEach((el) => {
      el.addEventListener('click', () => {
        const i = parseInt(el.dataset.like, 10);
        const list = [...state.phone.forum.posts].sort((a, b) => tab === 'latest' ? b.ts - a.ts : (b.likes || 0) - (a.likes || 0));
        const p = list[i];
        if (p) {
          if (p.myLike) { p.likes = Math.max(0, p.likes - 1); p.myLike = false; }
          else { p.likes = (p.likes || 0) + 1; p.myLike = true; state.phone.forum.rep = (state.phone.forum.rep || 0) + 1; }
          ctx.save();
          render();
        }
      });
    });
    body.querySelectorAll('[data-reply]').forEach((el) => {
      el.addEventListener('click', () => {
        const i = parseInt(el.dataset.reply, 10);
        const list = [...state.phone.forum.posts].sort((a, b) => tab === 'latest' ? b.ts - a.ts : (b.likes || 0) - (a.likes || 0));
        reply(list[i].id);
      });
    });
    body.querySelectorAll('[data-collect]').forEach((el) => {
      el.addEventListener('click', () => {
        const i = parseInt(el.dataset.collect, 10);
        const list = [...state.phone.forum.posts].sort((a, b) => tab === 'latest' ? b.ts - a.ts : (b.likes || 0) - (a.likes || 0));
        const p = list[i];
        if (p) {
          p.myCollect = !p.myCollect;
          if (!state.phone.forum.saved) state.phone.forum.saved = [];
          if (p.myCollect) state.phone.forum.saved.push(p.id);
          else state.phone.forum.saved = state.phone.forum.saved.filter((x) => x !== p.id);
          ctx.save();
          render();
        }
      });
    });
    body.querySelectorAll('.forum-post').forEach((el) => {
      el.addEventListener('click', (e) => {
        if (e.target.closest('.forum-foot')) return;
        const i = parseInt(el.dataset.idx, 10);
        let list;
        if (boardView) list = state.phone.forum.posts.filter((p) => p.board === boardView);
        else list = [...state.phone.forum.posts].sort((a, b) => tab === 'latest' ? b.ts - a.ts : (b.likes || 0) - (a.likes || 0));
        const p = list[i];
        if (p) viewPost(p.id);
      });
    });
    body.querySelectorAll('.forum-board-cell').forEach((b) => {
      b.addEventListener('click', () => {
        boardView = b.dataset.b;
        ctx.setBack(render);
        render();
      });
    });
  }

  function viewPost(postId) {
    const body = screen.querySelector('#fbBody');
    ctx.setBack(render);
    const f = state.phone.forum;
    const p = f.posts.find((x) => x.id === postId);
    if (!p) return;
    const comments = (p.comments || []).slice().sort((a, b) => a.ts - b.ts);
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
        <button class="btn btn-sm" id="vpBack">‹ 返回</button>
        <span style="flex:1;font-size:13px;font-weight:600;color:var(--accent-deep);">#${boardName(p.board)}</span>
        <button class="btn btn-sm" id="vpMenu">···</button>
      </div>
      <div id="vpMenuBox" style="display:none;margin-bottom:10px;border:1px solid var(--card-border);border-radius:12px;padding:6px;background:rgba(255,255,255,0.7);">
        <div class="menu-item" id="vpReport">⚠️ 举报</div>
        <div class="menu-item" id="vpPin">${p.pinned ? '⭐ 取消加精' : '⭐ 申请加精'}</div>
      </div>
      <div class="forum-post" style="background:rgba(255,255,255,0.85);">
        <div class="forum-post-head">
          <span class="forum-author" style="font-size:14px;">${p.author}</span>
          <span class="tag">#${boardName(p.board)}</span>
          ${p.pinned ? '<span class="tag" style="color:#D9A514;">⭐ 加精</span>' : ''}
          <span class="forum-time">${timeAgo(p.ts)}</span>
        </div>
        <div class="forum-title" style="font-size:16px;">${p.title || ''}</div>
        <div class="forum-body" style="font-size:14px;">${p.content}</div>
        <div class="forum-foot">
          <span id="vpLike">${p.myLike ? '👍 已赞' : '👍 点赞'} ${p.likes || 0}</span>
          <span id="vpReply">💬 ${comments.length || p.replies || 0}</span>
          <span id="vpCollect">${p.myCollect ? '🔖 已收藏' : '🔖 收藏'}</span>
        </div>
      </div>
      <div class="panel-sec">评论（${comments.length}）</div>
      <div id="vpComments">
        ${comments.length ? comments.map((cm) => `
          <div class="forum-comment">
            <div class="forum-comment-head">
              <span class="qq-ava" style="width:24px;height:24px;font-size:12px;background:${avatarColor(cm.author)};">${cm.author.slice(0, 1)}</span>
              <span style="font-size:13px;font-weight:600;color:var(--text-primary);">${cm.author}</span>
              <span style="flex:1;"></span>
              <span style="font-size:11px;color:var(--text-faint);">${timeAgo(cm.ts)}</span>
            </div>
            <div style="font-size:13px;color:var(--text-primary);line-height:1.7;margin-top:4px;">${cm.content}</div>
          </div>`).join('')
        : '<div style="font-size:12px;color:var(--text-faint);padding:6px 0;">还没有评论，来抢沙发吧</div>'}
      </div>
      <div style="display:flex;gap:8px;margin-top:12px;">
        <input type="text" id="vpCmtInput" placeholder="写下你的评论…" style="flex:1;">
        <button class="btn btn-sm btn-primary" id="vpCmtSend">发送</button>
      </div>`;
    body.querySelector('#vpBack').addEventListener('click', () => ctx.back());
    body.querySelector('#vpMenu').addEventListener('click', () => {
      const box = body.querySelector('#vpMenuBox');
      box.style.display = box.style.display === 'none' ? 'block' : 'none';
    });
    body.querySelector('#vpReport').addEventListener('click', () => {
      ctx.toast('已举报，管理员会尽快处理');
      body.querySelector('#vpMenuBox').style.display = 'none';
    });
    body.querySelector('#vpPin').addEventListener('click', () => {
      if (p.pinned) { p.pinned = false; ctx.toast('已取消加精'); }
      else { p.pinned = true; f.rep = (f.rep || 0) + 10; ctx.toast('帖子已加精，论坛声望 +10'); }
      ctx.save();
      viewPost(postId);
    });
    body.querySelector('#vpLike').addEventListener('click', () => {
      if (p.myLike) { p.likes = Math.max(0, p.likes - 1); p.myLike = false; }
      else { p.likes = (p.likes || 0) + 1; p.myLike = true; f.rep = (f.rep || 0) + 1; }
      ctx.save();
      viewPost(postId);
    });
    body.querySelector('#vpCollect').addEventListener('click', () => {
      p.myCollect = !p.myCollect;
      if (!f.saved) f.saved = [];
      if (p.myCollect) f.saved.push(p.id);
      else f.saved = f.saved.filter((x) => x !== p.id);
      ctx.save();
      viewPost(postId);
    });
    body.querySelector('#vpReply').addEventListener('click', () => reply(postId));
    body.querySelector('#vpCmtSend').addEventListener('click', () => {
      const t = body.querySelector('#vpCmtInput').value.trim();
      if (!t) return ctx.toast('评论不能为空');
      if (!p.comments) p.comments = [];
      p.comments.push({ author: state.phone.forumNick || '云栖新芽', content: t, ts: Date.now() });
      p.replies = (p.replies || 0) + 1;
      f.rep = (f.rep || 0) + 1;
      ctx.save();
      ctx.toast('评论成功');
      viewPost(postId);
    });
    body.querySelector('#vpCmtInput').addEventListener('keydown', (e) => { if (e.key === 'Enter') body.querySelector('#vpCmtSend').click(); });
  }

  function compose() {
    const body = screen.querySelector('#fbBody');
    ctx.setBack(render);
    body.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:10px;">
        <div style="font-size:13px;color:var(--text-secondary);">发布新帖（${state.phone.forumNick || '云栖新芽'}）</div>
        <input type="text" id="fbTitle" placeholder="帖子标题…" style="width:100%;">
        <select id="fbBoard" style="width:100%;">
          ${BOARD_CATS.map((b) => `<option value="${b.id}">${b.name}</option>`).join('')}
        </select>
        <textarea id="fbInput" placeholder="分享你在云栖市的见闻…" style="width:100%;min-height:120px;font-size:13px;line-height:1.7;resize:none;"></textarea>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm" id="fbCancel">取消</button>
          <button class="btn btn-sm btn-primary" id="fbPost">发布</button>
        </div>
      </div>`;
    body.querySelector('#fbCancel').addEventListener('click', () => ctx.back());
    body.querySelector('#fbPost').addEventListener('click', async () => {
      const content = body.querySelector('#fbInput').value.trim();
      const title = body.querySelector('#fbTitle').value.trim();
      const board = body.querySelector('#fbBoard').value;
      if (!content) return ctx.toast('内容不能为空');
      const f = state.phone.forum;
      let finalContent = content;
      if (isAIReady()) {
        body.querySelector('#fbPost').textContent = 'AI润色中…';
        const sys = buildSystemPrompt(state, '用户在云栖论坛发帖。');
        try {
          finalContent = (await chat([
            { role: 'system', content: sys.system + '\n请将下面的帖子内容润色为更自然、有生活气息的论坛发帖（保留原意，80字以内）：' },
            { role: 'user', content },
          ], { temperature: 0.8, max_tokens: 200 })).trim();
        } catch (e) {}
      }
      f.posts.unshift({ id: 'p' + Date.now(), author: state.phone.forumNick || '云栖新芽', board, title: title || '（无标题）', ts: Date.now(), content: finalContent, likes: 0, replies: 0, myLike: false, myCollect: false });
      f.rep = (f.rep || 0) + 1;
      ctx.save();
      ctx.toast('发布成功');
      ctx.back();
    });
  }

  function reply(postId) {
    const body = screen.querySelector('#fbBody');
    ctx.setBack(render);
    const f = state.phone.forum;
    const p = f.posts.find((x) => x.id === postId);
    if (!p) return;
    body.innerHTML = `
      <div style="font-size:13px;margin-bottom:8px;">
        <b style="color:var(--accent-deep);">${p.author}</b>：${p.content}
      </div>
      <textarea id="fbReply" placeholder="写下你的回复…" style="width:100%;min-height:80px;font-size:13px;line-height:1.7;resize:none;"></textarea>
      <div style="display:flex;gap:10px;margin-top:8px;">
        <button class="btn btn-sm" id="fbRCancel">返回</button>
        <button class="btn btn-sm btn-primary" id="fbRSend">回复</button>
      </div>`;
    body.querySelector('#fbRCancel').addEventListener('click', () => ctx.back());
    body.querySelector('#fbRSend').addEventListener('click', () => {
      const t = body.querySelector('#fbReply').value.trim();
      if (!t) return ctx.toast('回复不能为空');
      if (!p.replies) p.replies = 0;
      p.replies++;
      f.rep = (f.rep || 0) + 1;
      ctx.save();
      ctx.toast('回复成功');
      ctx.back();
    });
  }

  function timeAgo(ts) {
    const diff = Date.now() - ts;
    const min = Math.floor(diff / 60000);
    if (min < 1) return '刚刚';
    if (min < 60) return min + '分钟前';
    const h = Math.floor(min / 60);
    if (h < 24) return h + '小时前';
    return Math.floor(h / 24) + '天前';
  }
}
