export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-wallet';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="wlBack">‹</button>
      <div class="phone-app-title">钱包</div>
      <button class="phone-back-btn" id="wlRefresh" title="刷新">⟳</button>
    </div>
    <div class="phone-app-body" id="wlBody"></div>`;
  screen.querySelector('#wlBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#wlRefresh').addEventListener('click', () => refreshAdvice());
  let tab = 'records';
  let filter = 'all';
  render();

  function refreshAdvice() {
    const tips = ['理性消费，量入为出', '今天适合存下一笔小钱', '关注打折季，先观望再入手', '花钱要花在体验上', '记得给重要的人准备一份礼物'];
    ctx.toast('今日理财建议：' + tips[Math.floor(Math.random() * tips.length)]);
    render();
  }

  function records() {
    return (state.phone.wallet && state.phone.wallet.records) || [];
  }

  function render() {
    const body = screen.querySelector('#wlBody');
    const list = records();
    const balance = state.player.money;
    const income = list.filter((r) => r.amount > 0).reduce((a, r) => a + r.amount, 0);
    const expense = list.filter((r) => r.amount < 0).reduce((a, r) => a + Math.abs(r.amount), 0);
    body.innerHTML = `
      <div class="wallet-balance">
        <div class="amt">¥${balance}</div>
        <div class="lab">云栖市通用货币</div>
      </div>
      <div class="wallet-tabs">
        <button class="wallet-tab ${tab === 'records' ? 'active' : ''}" data-t="records">收支</button>
        <button class="wallet-tab ${tab === 'stats' ? 'active' : ''}" data-t="stats">统计</button>
      </div>
      ${tab === 'records' ? renderRecords() : renderStats(list, expense)}`;
    body.querySelectorAll('.wallet-tab').forEach((b) => {
      b.addEventListener('click', () => { tab = b.dataset.t; render(); });
    });
    if (tab === 'records') {
      body.querySelectorAll('.wallet-record').forEach((el) => {
        const id = el.dataset.id;
        let pressTimer = null;
        el.addEventListener('click', () => {
          const rec = records().find((r) => r.id === id);
          if (rec) recordDetail(rec);
        });
        el.addEventListener('touchstart', (e) => {
          pressTimer = setTimeout(() => { pressTimer = null; deleteManual(id, el); }, 600);
        }, { passive: true });
        el.addEventListener('touchend', () => { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } });
        el.addEventListener('touchmove', () => { if (pressTimer) { clearTimeout(pressTimer); pressTimer = null; } });
        el.addEventListener('contextmenu', (e) => {
          e.preventDefault();
          deleteManual(id, el);
        });
      });
    }
  }

  function renderRecords() {
    const list = records();
    const filtered = list.filter((r) => filter === 'all' || (filter === 'income' ? r.amount > 0 : r.amount < 0));
    const inc = list.filter((r) => r.amount > 0).reduce((a, r) => a + r.amount, 0);
    const exp = list.filter((r) => r.amount < 0).reduce((a, r) => a + Math.abs(r.amount), 0);
    return `
      <div class="wallet-filter">
        <button class="wallet-fb ${filter === 'all' ? 'active' : ''}" data-f="all">全部</button>
        <button class="wallet-fb ${filter === 'income' ? 'active' : ''}" data-f="income">收入</button>
        <button class="wallet-fb ${filter === 'expense' ? 'active' : ''}" data-f="expense">支出</button>
      </div>
      <div class="panel-sec">收支明细 <span style="font-weight:400;font-size:11px;color:var(--text-faint);">长按可删除手动记录</span></div>
      ${filtered.length ? filtered.map((r) => `
        <div class="wallet-record" data-id="${r.id || ''}">
          <div>
            <div style="font-size:13px;">${r.name} ${r.manual ? '<span style="font-size:10px;color:var(--text-faint);">手动</span>' : ''}</div>
            <div class="w-time">${r.gameTime || (r.ts ? new Date(r.ts).toLocaleString() : '')}</div>
          </div>
          <b class="${r.amount >= 0 ? 'income' : 'expense'}">${r.amount >= 0 ? '+' : '-'}${Math.abs(r.amount)}</b>
        </div>`).join('') : '<div class="empty-hint">暂无相关记录</div>'}
      <div class="panel-tip">打工赚取收入，合理规划支出。</div>`;
  }

  function renderStats(list, expense) {
    const catMap = {};
    const keys = { food: '餐饮', shop: '购物', fun: '娱乐', travel: '出行', work: '工作', other: '其他' };
    list.filter((r) => r.amount < 0).forEach((r) => {
      const k = r.cat || 'other';
      catMap[k] = (catMap[k] || 0) + Math.abs(r.amount);
    });
    const entries = Object.entries(catMap).sort((a, b) => b[1] - a[1]);
    const total = entries.reduce((s, x) => s + x[1], 0) || 1;
    const inc = list.filter((r) => r.amount > 0).reduce((a, r) => a + r.amount, 0);
    const srcMap = {};
    const srcKeys = { work: '打工', bonus: '奖金', gift: '礼物', other: '其他' };
    list.filter((r) => r.amount > 0).forEach((r) => {
      const k = r.src || 'other';
      srcMap[k] = (srcMap[k] || 0) + r.amount;
    });
    const srcEntries = Object.entries(srcMap).sort((a, b) => b[1] - a[1]);
    const srcTotal = srcEntries.reduce((s, x) => s + x[1], 0) || 1;
    const balance = inc - expense;
    return `
      <div class="stat-summary">
        <div class="stat-extra-cell"><span style="font-size:11px;">本月总收入</span><b style="font-size:20px;color:#3E9B62;margin-left:6px;">¥${inc}</b></div>
        <div class="stat-extra-cell"><span style="font-size:11px;">本月总支出</span><b style="font-size:20px;color:#C0564F;margin-left:6px;">¥${expense}</b></div>
        <div class="stat-extra-cell"><span style="font-size:11px;">本月结余</span><b style="font-size:20px;color:var(--accent-deep);margin-left:6px;">¥${balance}</b></div>
      </div>
      ${entries.length ? '' : '<div class="empty-hint">暂无支出统计</div>'}
      <div class="panel-sec">支出分类</div>
      ${entries.map(([k, v]) => `
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;">
            <span>${keys[k] || k}</span><span>¥${v} · ${Math.round((v / total) * 100)}%</span>
          </div>
          <div class="bar-track"><div class="bar-fill" style="width:${Math.round((v / total) * 100)}%"></div></div>
        </div>`).join('')}
      ${srcEntries.length ? '<div class="panel-sec">收入来源</div>' : ''}
      ${srcEntries.map(([k, v]) => `
        <div style="margin-bottom:10px;">
          <div style="display:flex;justify-content:space-between;font-size:12px;margin-bottom:4px;">
            <span>${srcKeys[k] || k}</span><span>¥${v} · ${Math.round((v / srcTotal) * 100)}%</span>
          </div>
          <div class="bar-track"><div class="bar-fill good-fill" style="width:${Math.round((v / srcTotal) * 100)}%"></div></div>
        </div>`).join('')}
      <div class="panel-sec">收支比例</div>
      <div class="bar-track"><div class="bar-fill good-fill" style="width:${(inc + expense) ? Math.round((inc / (inc + expense)) * 100) : 50}%"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:11px;color:var(--text-secondary);margin-top:4px;">
        <span>收入 ¥${inc}</span><span>支出 ¥${expense}</span>
      </div>`;
  }

  function recordDetail(rec) {
    const body = screen.querySelector('#wlBody');
    ctx.setBack(render);
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <button class="btn btn-sm" id="rdBack">‹ 返回</button>
        <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">收支详情</span>
      </div>
      <div style="text-align:center;padding:20px 0;">
        <div style="font-size:34px;font-weight:700;color:${rec.amount >= 0 ? '#3E9B62' : '#C0564F'};">${rec.amount >= 0 ? '+' : '-'}¥${Math.abs(rec.amount)}</div>
        <div style="font-size:14px;font-weight:600;margin-top:8px;">${rec.name}</div>
        <div style="font-size:12px;color:var(--text-faint);margin-top:4px;">${rec.gameTime || (rec.ts ? new Date(rec.ts).toLocaleString() : '')}</div>
      </div>
      <div style="font-size:13px;line-height:2;color:var(--text-secondary);padding:0 4px;">
        <div><b style="color:var(--text-primary);">类型：</b>${rec.amount >= 0 ? '收入' : '支出'}</div>
        ${rec.cat ? `<div><b style="color:var(--text-primary);">分类：</b>${({ food: '餐饮', shop: '购物', fun: '娱乐', travel: '出行', work: '工作', other: '其他' })[rec.cat] || rec.cat}</div>` : ''}
        ${rec.src ? `<div><b style="color:var(--text-primary);">来源：</b>${({ work: '打工', bonus: '奖金', gift: '礼物', other: '其他' })[rec.src] || rec.src}</div>` : ''}
        ${rec.note ? `<div><b style="color:var(--text-primary);">备注：</b>${rec.note}</div>` : ''}
        ${rec.manual ? '<div><b style="color:var(--text-primary);">来源：</b>手动记录</div>' : '<div style="color:var(--text-faint);font-size:12px;">系统自动生成记录</div>'}
      </div>`;
    body.querySelector('#rdBack').addEventListener('click', render);
  }

  function deleteManual(id, el) {
    const list = records();
    const rec = list.find((r) => r.id === id);
    if (!rec || !rec.manual) {
      ctx.toast('只能删除手动记录');
      return;
    }
    if (window.confirm(`删除手动记录「${rec.name}」？`)) {
      state.phone.wallet.records = list.filter((r) => r.id !== id);
      state.player.money -= rec.amount;
      ctx.save();
      render();
      ctx.toast('已删除');
    }
  }
}
