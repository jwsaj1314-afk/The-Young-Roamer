import { getRelation } from '../../core/state.js';
import { avatarColor, knownContacts, relLabel } from './common.js';
import { CHARACTERS } from '../../data/characters.js';

const GROUPS = [
  { key: 'special', label: '特别关心', match: (r) => r.isGuardian && r.f >= 60 || r.l >= 50 },
  { key: 'guardian', label: '亲人', match: (r) => r.isGuardian && !(r.f >= 60 || r.l >= 50) },
  { key: 'lover', label: '恋人/暧昧', match: (r) => r.l >= 20 },
  { key: 'friend', label: '好友', match: (r) => r.f >= 40 },
  { key: 'classmate', label: '同学', match: () => false },
  { key: 'other', label: '其他', match: () => true },
];

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-contacts';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="ctBack">‹</button>
      <div class="phone-app-title">通讯录</div>
      <button class="phone-back-btn" id="ctRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="ctCall" title="拨号">☎</button>
    </div>
    <div class="phone-app-body" id="ctBody"></div>`;
  screen.querySelector('#ctBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#ctCall').addEventListener('click', () => dialer());
  screen.querySelector('#ctRefresh').addEventListener('click', () => refreshRecommend());
  renderList();

  function refreshRecommend() {
    const met = knownContacts(state);
    if (met.length) {
      const c = met[Math.floor(Math.random() * met.length)];
      ctx.toast(`「${c.name}」最近有新的动态，去看看 TA 吧`);
    } else {
      ctx.toast('还没有认识的人，先去剧情里认识新朋友吧');
    }
    renderList();
  }

  function groupOf(c) {
    const r = getRelation(state, c.id);
    for (const g of GROUPS) {
      if (g.match(r)) return g.key;
    }
    return 'other';
  }

  function renderList(query = '') {
    const body = screen.querySelector('#ctBody');
    const list = knownContacts(state).filter((c) => {
      if (!query) return true;
      return (c.name + (c.identity || '')).includes(query);
    });
    const grouped = {};
    list.forEach((c) => {
      const k = groupOf(c);
      (grouped[k] = grouped[k] || []).push(c);
    });

    body.innerHTML = `
      <div style="padding:4px 2px 10px;">
        <input type="text" id="ctSearch" placeholder="搜索联系人…" value="${query}" style="width:100%;">
      </div>
      <div style="padding:4px 2px 10px;font-size:12px;color:var(--text-secondary);">共 ${list.length} 位联系人</div>
      ${list.length ? '' : '<div class="empty-hint">通讯录还是空的</div>'}
      ${GROUPS.map((g) => {
        const items = grouped[g.key] || [];
        if (!items.length) return '';
        return `
        <div class="ct-group">
          <div class="ct-group-label">${g.label}</div>
          ${items.map((c) => `
            <div class="contact-item" data-id="${c.id}">
              <div class="qq-ava" style="background:${avatarColor(c.id)};">${c.name.slice(0, 1)}</div>
              <div class="contact-info">
                <div class="contact-name">${c.name}</div>
                <div class="contact-rel">${relTag(c)} · ${c.age}岁 · ${lastContact(c)}</div>
              </div>
              <button class="contact-call" data-call="${c.id}">📞</button>
            </div>`).join('')}
        </div>`;
      }).join('')}`;
    body.querySelector('#ctSearch').addEventListener('input', (e) => {
      renderList(e.target.value.trim());
    });
    body.querySelectorAll('.contact-item').forEach((el) => {
      el.addEventListener('click', () => {
        const c = list.find((x) => x.id === el.dataset.id);
        if (c) detail(c);
      });
    });
    body.querySelectorAll('.contact-call').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        call(btn.dataset.call);
      });
    });
  }

  function lastContact(c) {
    const r = state.relations[c.id];
    if (r && r.dayMet) return '第' + r.dayMet + '天认识';
    return '最近联系';
  }

  function detail(c) {
    const body = screen.querySelector('#ctBody');
    ctx.setBack(renderList);
    const r = getRelation(state, c.id);
    const phone = c.phone || '138****' + String(c.id.length * 37).padStart(4, '0').slice(0, 4);
    const calls = (state.phone.calls || []).filter((x) => x.id === c.id);
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
        <button class="btn btn-sm" id="ctDtlBack">‹ 返回</button>
        <span style="flex:1;"></span>
        <button class="btn btn-sm" id="ctDtlMenu">···</button>
      </div>
      <div id="ctDtlMenuBox" style="display:none;margin-bottom:10px;border:1px solid var(--card-border);border-radius:12px;padding:6px;background:rgba(255,255,255,0.7);">
        <div class="menu-item" id="ctDtlEdit">✎ 编辑关系标签</div>
        <div class="menu-item danger" id="ctDtlDel">🗑 删除联系人</div>
      </div>
      <div style="text-align:center;padding:16px 0 18px;">
        <div class="qq-ava" style="width:70px;height:70px;font-size:30px;margin:0 auto 12px;background:${avatarColor(c.id)};">${c.name.slice(0, 1)}</div>
        <div style="font-size:18px;font-weight:600;color:var(--accent-deep);">${c.name}</div>
        <div style="font-size:12px;color:var(--text-secondary);margin-top:4px;">${c.age}岁 · ${relTag(c)}</div>
      </div>
      <div style="font-size:13px;line-height:2;color:var(--text-secondary);padding:0 4px;">
        <div><b style="color:var(--text-primary);">性别：</b>${c.gender || '未知'}</div>
        <div><b style="color:var(--text-primary);">身份/职业：</b>${c.identity}</div>
        <div><b style="color:var(--text-primary);">电话号码：</b>${phone}</div>
      </div>
      <div class="panel-sec" style="margin-top:14px;">电话记录</div>
      ${calls.length ? calls.map((x) => `<div style="font-size:12px;padding:4px 0;color:var(--text-secondary);">${x.type === 'in' ? '来电' : '去电'} · 第${x.day}天</div>`).join('') : '<div style="font-size:12px;color:var(--text-faint);">暂无通话记录</div>'}
      <div style="display:flex;gap:10px;padding:18px 4px 0;">
        <button class="btn btn-primary" style="flex:1;" id="ctDtlCall">📞 拨打电话</button>
      </div>`;
    body.querySelector('#ctDtlBack').addEventListener('click', renderList);
    body.querySelector('#ctDtlCall').addEventListener('click', () => call(c.id));
    body.querySelector('#ctDtlMenu').addEventListener('click', () => {
      const box = body.querySelector('#ctDtlMenuBox');
      box.style.display = box.style.display === 'none' ? 'block' : 'none';
    });
    body.querySelector('#ctDtlEdit').addEventListener('click', () => editTag(c));
    body.querySelector('#ctDtlDel').addEventListener('click', () => removeContact(c));
  }

  function relTag(c) {
    const override = state.phone.contactTags && state.phone.contactTags[c.id];
    return override || relLabel(getRelation(state, c.id));
  }

  function editTag(c) {
    const body = screen.querySelector('#ctBody');
    ctx.setBack(detail.bind(null, c));
    const tags = ['特别关心', '亲人', '恋人', '好友', '同学', '其他'];
    const current = state.phone.contactTags && state.phone.contactTags[c.id];
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <button class="btn btn-sm" id="tagBack">‹ 返回</button>
        <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">编辑 ${c.name} 的关系标签</span>
      </div>
      <div style="display:flex;flex-direction:column;gap:8px;">
        ${tags.map((t) => `<button class="btn btn-sm ${current === t ? 'btn-primary' : ''}" data-t="${t}" style="justify-content:flex-start;">${t}</button>`).join('')}
        <button class="btn btn-sm ${current === '自定义' ? 'btn-primary' : ''}" data-t="自定义">自定义…</button>
        ${current === '自定义' ? `<input type="text" id="tagCustom" value="${current}" style="width:100%;" placeholder="输入关系标签">` : ''}
        <button class="btn btn-sm btn-primary" id="tagSave">保存</button>
      </div>`;
    let chosen = current || '';
    body.querySelectorAll('[data-t]').forEach((b) => {
      b.addEventListener('click', () => {
        body.querySelectorAll('[data-t]').forEach((x) => x.classList.remove('btn-primary'));
        b.classList.add('btn-primary');
        chosen = b.dataset.t;
        const cb = body.querySelector('#tagCustom');
        if (b.dataset.t === '自定义' && !cb) {
          renderCustom();
        } else if (cb) {
          cb.style.display = b.dataset.t === '自定义' ? 'block' : 'none';
        }
      });
    });
    function renderCustom() {
      body.innerHTML = body.innerHTML.replace('</div></div>', `<input type="text" id="tagCustom" value="" style="width:100%;margin-top:4px;" placeholder="输入关系标签"></div></div>`);
      body.querySelector('#tagSave').addEventListener('click', saveTag);
    }
    function saveTag() {
      const v = chosen === '自定义' ? (body.querySelector('#tagCustom') ? body.querySelector('#tagCustom').value.trim() : '') : chosen;
      if (!v) return ctx.toast('标签不能为空');
      if (!state.phone.contactTags) state.phone.contactTags = {};
      state.phone.contactTags[c.id] = v;
      ctx.save();
      ctx.toast('已保存');
      detail(c);
    }
    body.querySelector('#tagSave').addEventListener('click', saveTag);
    body.querySelector('#tagBack').addEventListener('click', () => detail(c));
  }

  function removeContact(c) {
    if (window.confirm(`确定从通讯录删除「${c.name}」？`)) {
      state.phone.qq.contacts = (state.phone.qq.contacts || []).filter((x) => x.id !== c.id);
      ctx.save();
      ctx.toast('已删除联系人');
      renderList();
    }
  }

  function call(id) {
    const body = screen.querySelector('#ctBody');
    ctx.setBack(renderList);
    const c = CHARACTERS.find((x) => x.id === id);
    body.innerHTML = `
      <div style="text-align:center;padding:70px 20px;">
        <div class="qq-ava" style="width:90px;height:90px;font-size:36px;margin:0 auto 18px;background:${avatarColor(id)};animation:pulse 1.6s infinite;">${c ? c.name.slice(0, 1) : id.slice(0, 1).toUpperCase()}</div>
        <div style="font-size:17px;font-weight:600;">正在呼叫 ${c ? c.name : id}…</div>
        <div style="font-size:12px;color:var(--text-faint);margin-top:6px;">云栖市 4G</div>
        <button class="btn btn-danger" style="margin-top:50px;border-radius:50%;width:66px;height:66px;font-size:22px;" id="hangup">✆</button>
      </div>`;
    if (!state.phone.calls) state.phone.calls = [];
    state.phone.calls.push({ id, type: 'out', day: state.time.day, ts: Date.now() });
    ctx.save();
    screen.querySelector('#hangup').addEventListener('click', () => {
      ctx.toast('通话已结束');
      renderList();
    });
  }

  function dialer() {
    const body = screen.querySelector('#ctBody');
    ctx.setBack(renderList);
    body.innerHTML = `
      <div style="text-align:center;padding-top:20px;">
        <div id="dialDisplay" style="font-size:26px;letter-spacing:3px;color:var(--accent-deep);min-height:36px;margin-bottom:16px;"></div>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:10px;max-width:240px;margin:0 auto;">
          ${['1', '2', '3', '4', '5', '6', '7', '8', '9', '*', '0', '#'].map((n) => `<button class="btn" style="height:60px;font-size:20px;border-radius:50%;" data-n="${n}">${n}</button>`).join('')}
        </div>
        <div style="display:flex;justify-content:center;gap:30px;margin-top:20px;">
          <button class="btn btn-primary" id="dialGo" style="width:60px;height:60px;border-radius:50%;font-size:18px;">📞</button>
        </div>
      </div>`;
    const display = body.querySelector('#dialDisplay');
    let num = '';
    body.querySelectorAll('[data-n]').forEach((b) => {
      b.addEventListener('click', () => { num += b.dataset.n; display.textContent = num; });
    });
    body.querySelector('#dialGo').addEventListener('click', () => {
      if (!num) return ctx.toast('请先输入号码');
      ctx.toast('拨号 ' + num);
    });
  }
}
