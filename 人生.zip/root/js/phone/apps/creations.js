import { isAIReady, chat, buildSystemPrompt } from '../../core/ai.js';
import { knownContacts } from './common.js';

const TYPES = [
  { id: 'video', name: '视频', icon: '🎬' },
  { id: 'photo', name: '图文', icon: '🖼' },
  { id: 'article', name: '文章', icon: '📝' },
  { id: 'novel', name: '小说', icon: '📚' },
];

const LIVE_CATS = ['闲聊', '才艺', '游戏', '知识分享', '美食', '音乐'];

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  screen.className = 'phone-app-screen app-creations';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="crBack">‹</button>
      <div class="phone-app-title">我的创作</div>
      <button class="phone-back-btn" id="crRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="crCenter" title="创作者中心">📊</button>
      <button class="phone-back-btn" id="crNew" title="新建">＋</button>
    </div>
    <div class="phone-app-body" id="crBody"></div>`;
  screen.querySelector('#crBack').addEventListener('click', () => ctx.back());
  screen.querySelector('#crNew').addEventListener('click', () => compose(null));
  screen.querySelector('#crRefresh').addEventListener('click', () => refreshInspiration());
  screen.querySelector('#crCenter').addEventListener('click', () => creatorCenter());
  render();

  function stats() {
    const c = state.phone.creations || [];
    return {
      total: c.length,
      fans: state.phone.fans || 0,
      likes: (state.phone.creations || []).reduce((s, x) => s + (x.likes || 0), 0),
      reads: (state.phone.creations || []).reduce((s, x) => s + (x.reads || 0), 0),
    };
  }

  function render() {
    const body = screen.querySelector('#crBody');
    const list = state.phone.creations || [];
    const s = stats();
    const canLive = s.fans >= 1000;
    body.innerHTML = `
      <div class="create-stats">
        <div class="cs-item"><div class="cs-num">${s.total}</div><div class="cs-lab">作品</div></div>
        <div class="cs-item"><div class="cs-num">${s.fans}</div><div class="cs-lab">粉丝</div></div>
        <div class="cs-item"><div class="cs-num">${s.likes}</div><div class="cs-lab">获赞</div></div>
        <div class="cs-item"><div class="cs-num">${state.phone.creationsCount || 0}</div><div class="cs-lab">灵感</div></div>
      </div>
      ${canLive
        ? '<button class="btn btn-sm create-live-btn" id="crLive">🔴 开始直播</button>'
        : `<div class="empty-hint" style="margin:6px 0 10px;font-size:12px;">🔴 直播需粉丝达到 1000（当前 ${s.fans}）</div>`}
      ${list.length ? '' : '<div class="empty-hint">还没有创作</div>'}
      ${[...list].sort((a, b) => (b.ts || 0) - (a.ts || 0)).map((c) => `
        <div class="create-item ${c.live ? 'create-live' : ''}" data-id="${c.id}">
          <div class="create-item-cover" style="background:${coverBg(c.type)};">${c.type === 'video' ? '▶' : (c.type === 'photo' ? '🖼' : (c.type === 'novel' ? '📚' : '📝'))}</div>
          <div style="flex:1;min-width:0;">
            <div class="create-item-title">${c.title}</div>
            <div class="create-item-type">${typeName(c.type)} · 第${c.day}天 · ${c.status === 'draft' ? '草稿' : '已发布'}</div>
            <div class="create-item-meta">👁 ${c.reads || 0} · 👍 ${c.likes || 0} · 💬 ${c.comments || 0}</div>
          </div>
        </div>`).join('')}`;
    const liveBtn = body.querySelector('#crLive');
    if (liveBtn) liveBtn.addEventListener('click', () => livePrep());
    body.querySelectorAll('.create-item[data-id]').forEach((el) => {
      el.addEventListener('click', () => viewDetail(el.dataset.id));
    });
  }

  async function refreshInspiration() {
    const btn = screen.querySelector('#crRefresh');
    if (btn) { btn.textContent = '…'; btn.disabled = true; }
    let idea = '';
    if (isAIReady()) {
      const sys = buildSystemPrompt(state, '玩家刷新创作灵感。');
      try {
        idea = (await chat([
          { role: 'system', content: sys.system + '\n请给玩家一个云栖市风格的创作灵感点子，15-30字，可以是视频/图文/文章/小说的主题。' },
          { role: 'user', content: '给我一个创作灵感。' },
        ], { temperature: 0.95, max_tokens: 80 })).trim();
      } catch (e) {}
    }
    if (!idea) {
      const pool = [
        '拍一段镜湖日落的 Vlog',
        '写一篇关于老街面包店的图文',
        '写一个发生在雨天相遇的故事',
        '记录云栖市的慢生活随笔',
        '写一部关于海边小镇的连载小说',
      ];
      idea = pool[Math.floor(Math.random() * pool.length)];
    }
    state.phone.creationsCount = (state.phone.creationsCount || 0) + 1;
    ctx.save();
    if (btn) { btn.textContent = '⟳'; btn.disabled = false; }
    ctx.toast('灵感：' + idea);
    render();
  }

  function compose(existing) {
    const body = screen.querySelector('#crBody');
    ctx.setBack(render);
    let type = existing ? existing.type : 'video';
    let saved = false;
    body.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:10px;">
        <div style="font-size:13px;color:var(--text-secondary);">${existing ? '编辑作品' : '新建作品'}</div>
        <div class="opt-list" id="crTypes">
          ${TYPES.map((t) => `<div class="opt ${t.id === type ? 'selected' : ''}" data-t="${t.id}">${t.icon} ${t.name}</div>`).join('')}
        </div>
        <input type="text" id="crTitle" placeholder="作品标题" value="${existing ? existing.title || '' : ''}" style="width:100%;">
        <div id="crForm"></div>
        <div style="display:flex;align-items:center;gap:8px;">
          <label class="switch" style="flex-shrink:0;"><input type="checkbox" id="crPublish" ${existing && existing.status === 'published' ? 'checked' : (existing ? '' : 'checked')}><span class="slider"></span></label>
          <span style="font-size:12px;color:var(--text-secondary);">发布（不勾选则存为草稿）</span>
        </div>
        <div style="display:flex;gap:10px;flex-wrap:wrap;">
          <button class="btn btn-sm" id="crCancel">取消</button>
          <button class="btn btn-sm btn-primary" id="crSave">${existing ? '保存' : '创建'}</button>
          ${isAIReady() ? '<button class="btn btn-sm" id="crAI">✨ AI创作</button>' : ''}
        </div>
      </div>`;
    renderForm();
    body.querySelectorAll('#crTypes .opt').forEach((el) => {
      el.addEventListener('click', () => {
        body.querySelectorAll('#crTypes .opt').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        type = el.dataset.t;
        renderForm();
      });
    });
    function renderForm() {
      const form = body.querySelector('#crForm');
      const cur = state.phone.creations && existing;
      if (type === 'video') {
        form.innerHTML = `
          <input type="text" id="crCover" placeholder="封面标题 / 简介（可选）" value="${cur ? existing.intro || '' : ''}" style="width:100%;">
          <div class="cr-upload" id="crUpload">🎬 上传视频文件（模拟）</div>
          <textarea id="crInput" placeholder="视频简介…" style="width:100%;min-height:100px;font-size:13px;line-height:1.7;resize:none;">${cur ? existing.content || '' : ''}</textarea>`;
      } else if (type === 'photo') {
        form.innerHTML = `
          <div class="cr-upload" id="crUpload">🖼 添加图片（模拟多图）</div>
          <textarea id="crInput" placeholder="配图文字…" style="width:100%;min-height:120px;font-size:13px;line-height:1.7;resize:none;">${cur ? existing.content || '' : ''}</textarea>`;
      } else if (type === 'novel') {
        form.innerHTML = `
          <input type="text" id="crChapter" placeholder="章节名（连载，选填）" value="${cur && existing.chapter ? existing.chapter : ''}" style="width:100%;">
          <textarea id="crInput" placeholder="本章正文…" style="width:100%;min-height:140px;font-size:13px;line-height:1.7;resize:none;">${cur ? existing.content || '' : ''}</textarea>`;
      } else {
        form.innerHTML = `
          <textarea id="crInput" placeholder="正文…" style="width:100%;min-height:160px;font-size:13px;line-height:1.7;resize:none;">${cur ? existing.content || '' : ''}</textarea>`;
      }
      const upload = form.querySelector('#crUpload');
      if (upload) upload.addEventListener('click', () => { upload.classList.add('uploaded'); upload.innerHTML = '✅ 已添加素材'; });
    }
    body.querySelector('#crCancel').addEventListener('click', () => ctx.back());
    body.querySelector('#crSave').addEventListener('click', () => {
      const title = body.querySelector('#crTitle').value.trim();
      const content = (body.querySelector('#crInput') ? body.querySelector('#crInput').value : '').trim();
      if (!content && type !== 'video') return ctx.toast('内容不能为空');
      if (!title) return ctx.toast('请填写标题');
      const publish = body.querySelector('#crPublish').checked;
      if (!state.phone.creations) state.phone.creations = [];
      const data = {
        type,
        title,
        content,
        intro: body.querySelector('#crCover') ? body.querySelector('#crCover').value.trim() : '',
        chapter: body.querySelector('#crChapter') ? body.querySelector('#crChapter').value.trim() : '',
        status: publish ? 'published' : 'draft',
        reads: existing ? existing.reads || 0 : Math.floor(Math.random() * 50) + 5,
        likes: existing ? existing.likes || 0 : 0,
        comments: existing ? existing.comments || 0 : 0,
      };
      if (existing) {
        Object.assign(existing, data);
        ctx.toast('已保存');
      } else {
        data.id = 'cr' + Date.now();
        data.day = state.time.day;
        data.ts = Date.now();
        data.live = false;
        state.phone.creations.push(data);
        state.phone.creationsCount = (state.phone.creationsCount || 0) + 1;
        if (publish && Math.random() < 0.3) state.phone.fans = (state.phone.fans || 0) + Math.floor(Math.random() * 5) + 1;
        ctx.toast('创作已' + (publish ? '发布' : '存为草稿'));
      }
      ctx.save();
      render();
    });
    const aiBtn = body.querySelector('#crAI');
    if (aiBtn) {
      aiBtn.addEventListener('click', async () => {
        aiBtn.textContent = 'AI创作中…';
        aiBtn.disabled = true;
        const title = body.querySelector('#crTitle').value.trim() || '无题';
        const sys = buildSystemPrompt(state, '玩家想创作一篇作品。');
        try {
          const content = (await chat([
            { role: 'system', content: sys.system + `\n请为玩家创作一篇${typeName(type)}作品，题目「${title}」，120字以内，风格治愈、有云栖市的气息。` },
            { role: 'user', content: '开始创作。' },
          ], { temperature: 0.95, max_tokens: 300 })).trim();
          const input = body.querySelector('#crInput');
          if (input) input.value = content;
          if (type === 'video') {
            const intro = body.querySelector('#crCover');
            if (intro && !intro.value) intro.value = title;
          }
        } catch (e) {
          ctx.toast('AI 生成失败');
        }
        aiBtn.textContent = '✨ AI创作';
        aiBtn.disabled = false;
      });
    }
  }

  function viewDetail(cid) {
    const body = screen.querySelector('#crBody');
    ctx.setBack(render);
    const c = (state.phone.creations || []).find((x) => x.id === cid);
    if (!c) return;
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:8px;">
        <button class="btn btn-sm" id="crDtlBack">‹ 返回</button>
        <span style="flex:1;font-size:13px;font-weight:600;color:var(--accent-deep);">${typeName(c.type)} · ${c.status === 'draft' ? '草稿' : '已发布'}</span>
        <button class="btn btn-sm" id="crDtlEdit">✎ 编辑</button>
      </div>
      <div class="create-item" style="background:rgba(255,255,255,0.85);">
        <div style="font-size:17px;font-weight:700;color:var(--accent-deep);">${c.title}</div>
        <div class="create-item-type" style="margin:4px 0;">${typeName(c.type)} · 第${c.day}天 · 👁 ${c.reads || 0} · 👍 ${c.likes || 0} · 💬 ${c.comments || 0}</div>
        ${c.intro ? `<div style="font-size:13px;color:var(--text-secondary);margin:6px 0;">${c.intro}</div>` : ''}
        ${c.chapter ? `<div style="font-size:12px;color:var(--accent-deep);margin:6px 0;">📖 ${c.chapter}</div>` : ''}
        <div style="font-size:14px;line-height:1.9;color:var(--text-primary);white-space:pre-wrap;margin-top:8px;">${c.content}</div>
        <div style="display:flex;gap:10px;margin-top:14px;">
          <button class="btn btn-sm" id="crLike">👍 ${c.likes || 0}</button>
          <button class="btn btn-sm" id="crCmt">💬 ${c.comments || 0}</button>
        </div>
      </div>`;
    body.querySelector('#crDtlBack').addEventListener('click', render);
    body.querySelector('#crDtlEdit').addEventListener('click', () => compose(c));
    body.querySelector('#crLike').addEventListener('click', () => {
      c.likes = (c.likes || 0) + 1;
      ctx.save();
      viewDetail(cid);
    });
    body.querySelector('#crCmt').addEventListener('click', () => {
      c.comments = (c.comments || 0) + 1;
      ctx.save();
      ctx.toast('收到一条评论（模拟）');
      viewDetail(cid);
    });
  }

  function livePrep() {
    const body = screen.querySelector('#crBody');
    ctx.setBack(render);
    body.innerHTML = `
      <div style="display:flex;flex-direction:column;gap:10px;">
        <div style="font-size:13px;color:var(--text-secondary);">直播准备</div>
        <input type="text" id="lvTitle" placeholder="直播标题" style="width:100%;">
        <div class="cr-upload" id="lvCover">🎬 选择封面（模拟）</div>
        <div>
          <div style="font-size:12px;color:var(--text-secondary);margin-bottom:4px;">分类</div>
          <div class="opt-list" id="lvCats">
            ${LIVE_CATS.map((cat, i) => `<div class="opt ${i === 0 ? 'selected' : ''}" data-c="${cat}">${cat}</div>`).join('')}
          </div>
        </div>
        <div style="display:flex;gap:10px;">
          <button class="btn btn-sm" id="lvBack">返回</button>
          <button class="btn btn-sm btn-primary" id="lvStart">开始直播</button>
        </div>
      </div>`;
    let cat = LIVE_CATS[0];
    body.querySelector('#lvBack').addEventListener('click', render);
    body.querySelector('#lvCover').addEventListener('click', (e) => { e.currentTarget.innerHTML = '✅ 已选择封面'; });
    body.querySelectorAll('#lvCats .opt').forEach((el) => {
      el.addEventListener('click', () => {
        body.querySelectorAll('#lvCats .opt').forEach((x) => x.classList.remove('selected'));
        el.classList.add('selected');
        cat = el.dataset.c;
      });
    });
    body.querySelector('#lvStart').addEventListener('click', () => {
      const title = body.querySelector('#lvTitle').value.trim() || ('云栖直播间 · ' + cat);
      live(title, cat);
    });
  }

  function live(title, cat) {
    const body = screen.querySelector('#crBody');
    ctx.setBack(render);
    const viewers = Math.max(3, Math.round((state.phone.fans || 0) / 5));
    let online = viewers;
    const aud = ['云栖小鹿', '爱吃可颂', '夜航星', '街角的面包', '一只路过的小猫', '白噪音', '南河的风'];
    body.innerHTML = `
      <div class="create-item create-live" style="padding:0;overflow:hidden;">
        <div style="display:flex;align-items:center;gap:6px;padding:8px 10px;background:rgba(0,0,0,0.06);">
          <span class="live-dot"></span>
          <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">${title}</span>
          <span style="flex:1;"></span>
          <span style="font-size:11px;color:var(--text-faint);" id="lvOnline">👁 ${online}</span>
          <button class="btn btn-sm" id="lvClose">✕</button>
        </div>
        <div id="lvStage" style="height:150px;display:flex;align-items:center;justify-content:center;font-size:34px;background:linear-gradient(135deg,#2E3B52,#4A5B7A,#F2C94C);">🎤 直播中 · ${cat}</div>
        <div style="display:flex;gap:8px;padding:8px 10px;justify-content:center;">
          <button class="btn btn-sm" id="lvLikeBtn">❤️</button>
        </div>
        <div id="lvChat" style="text-align:left;font-size:12px;color:var(--text-secondary);min-height:100px;line-height:1.8;padding:8px 10px;max-height:140px;overflow-y:auto;"></div>
        <div style="display:flex;gap:8px;padding:0 10px 10px;">
          <input type="text" id="lvInput" placeholder="说点什么…" style="flex:1;">
          <button class="btn btn-sm btn-primary" id="lvSend">发送</button>
        </div>
      </div>`;
    const chatEl = body.querySelector('#lvChat');
    const input = body.querySelector('#lvInput');
    chatEl.innerHTML = '💬 观众「云栖小鹿」进入直播间\n';
    const likesEl = body.querySelector('#lvLikeBtn');
    likesEl.addEventListener('click', () => {
      likesEl.textContent = '❤️ ' + (parseInt(likesEl.textContent.replace(/[^\d]/g, '') || 0, 10) + 1);
    });
    const stage = body.querySelector('#lvStage');
    const stageColors = ['linear-gradient(135deg,#2E3B52,#4A5B7A,#F2C94C)', 'linear-gradient(135deg,#3A2E52,#6C4F9E,#F2C94C)', 'linear-gradient(135deg,#1F4D38,#2E6B4F,#F0D9A0)'];
    let colorIdx = 0;
    const bgTimer = setInterval(() => {
      colorIdx = (colorIdx + 1) % stageColors.length;
      if (stage) stage.style.background = stageColors[colorIdx];
    }, 4000);
    const onlineTimer = setInterval(() => {
      online = Math.max(3, online + Math.floor(Math.random() * 5) - 2);
      const el = body.querySelector('#lvOnline');
      if (el) el.textContent = '👁 ' + online;
    }, 6000);
    const sendBtn = body.querySelector('#lvSend');
    sendBtn.addEventListener('click', () => {
      const text = input.value.trim();
      if (!text) return;
      input.value = '';
      chatEl.innerHTML += `你：${text}\n`;
      aiReply(text);
    });
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') sendBtn.click(); });
    async function aiReply(text) {
      const sys = buildSystemPrompt(state, '玩家在直播，观众在互动。');
      try {
        const reply = (await chat([
          { role: 'system', content: sys.system + '\n你是一位直播间的观众，用一两句亲切随意的话回应主播（20字内）。' },
          { role: 'user', content: `主播说：${text}` },
        ], { temperature: 0.9, max_tokens: 80 })).trim();
        const who = aud[Math.floor(Math.random() * aud.length)];
        chatEl.innerHTML += `💬 ${who}：${reply}\n`;
        chatEl.scrollTop = chatEl.scrollHeight;
      } catch (e) {}
    }
    body.querySelector('#lvClose').addEventListener('click', () => {
      clearInterval(bgTimer);
      clearInterval(onlineTimer);
      if (!state.phone.creations) state.phone.creations = [];
      state.phone.creations.push({ id: 'cr' + Date.now(), title: '直播回放：' + title, type: 'video', content: '一次 ' + cat + ' 主题直播互动，最高 ' + online + ' 人在线。', intro: '', chapter: '', status: 'published', reads: online * 3, likes: online, comments: Math.round(online / 2), day: state.time.day, ts: Date.now(), live: true });
      ctx.save();
      ctx.toast('直播已结束，回放已发布为视频作品');
      render();
    });
  }

  function creatorCenter() {
    const body = screen.querySelector('#crBody');
    ctx.setBack(render);
    const c = state.phone.creations || [];
    const s = stats();
    const recentReads = c.reduce((a, x) => a + (x.reads || 0), 0);
    body.innerHTML = `
      <div style="display:flex;align-items:center;gap:6px;margin-bottom:10px;">
        <button class="btn btn-sm" id="ccBack">‹ 返回</button>
        <span style="font-size:13px;font-weight:600;color:var(--accent-deep);">创作者中心</span>
      </div>
      <div class="panel-sec">数据看板（近7日）</div>
      <div class="create-stats" style="margin-bottom:6px;">
        <div class="cs-item"><div class="cs-num">${recentReads}</div><div class="cs-lab">阅读量</div></div>
        <div class="cs-item"><div class="cs-num">${s.likes}</div><div class="cs-lab">点赞量</div></div>
        <div class="cs-item"><div class="cs-num">+${Math.max(0, s.fans - (state.phone.fansPrev || 0))}</div><div class="cs-lab">粉丝增长</div></div>
      </div>
      <div class="panel-sec">消息中心</div>
      <div style="display:flex;flex-direction:column;gap:6px;">
        ${renderMsgs()}
      </div>
      <div class="panel-sec">粉丝管理</div>
      <div style="font-size:12px;color:var(--text-secondary);line-height:2;">
        ${renderFans()}
      </div>`;
    body.querySelector('#ccBack').addEventListener('click', render);
    state.phone.fansPrev = s.fans;
    ctx.save();
  }

  function renderMsgs() {
    const c = state.phone.creations || [];
    const msgs = [
      `📢 系统：作品「${c.length ? c[c.length - 1].title : '你的作品'}」获得平台推荐`,
      '💬 评论回复：粉丝说"太喜欢你的更新了！"',
      `🔔 通知：本周你的作品共获得 ${stats().likes} 次点赞`,
    ];
    return msgs.map((m) => `<div style="font-size:12px;color:var(--text-secondary);background:rgba(255,255,255,0.55);border-radius:10px;padding:8px 10px;">${m}</div>`).join('');
  }

  function renderFans() {
    const fans = Math.min(6, state.phone.fans || 0);
    if (!fans) return '<div style="color:var(--text-faint);">还没有粉丝</div>';
    const names = ['云栖小鹿', '爱吃可颂', '夜航星', '街角的面包', '白噪音', '南河的风'];
    return names.slice(0, fans).map((n) => `• ${n}`).join('<br>') + (fans > 6 ? '<br>…' : '');
  }

  function coverBg(t) {
    return {
      video: 'linear-gradient(135deg,#4A5B7A,#2E3B52)',
      photo: 'linear-gradient(135deg,#7FA8C9,#BBD8F0)',
      article: 'linear-gradient(135deg,#8FBFA0,#D7EBD9)',
      novel: 'linear-gradient(135deg,#B5A6C9,#E4D9F0)',
      live: 'linear-gradient(135deg,#C0564F,#7A2E2E)',
    }[t] || 'linear-gradient(135deg,#7FA8C9,#BBD8F0)';
  }

  function typeName(t) {
    return { video: '视频', photo: '图文', article: '文章', novel: '小说', live: '直播', poem: '诗歌', essay: '散文', drawing: '绘画', music: '音乐' }[t] || t;
  }
}
