import { CHARACTERS } from '../../data/characters.js';
import { getRelation } from '../../core/state.js';

export function getChar(id) {
  return CHARACTERS.find((c) => c.id === id);
}

export function charName(state, id) {
  if (id === 'me') return state.player.nickname || state.player.name;
  const c = getChar(id);
  return c ? c.name : id;
}

export function avatarColor(id) {
  let hash = 0;
  for (let i = 0; i < id.length; i++) hash = (hash * 31 + id.charCodeAt(i)) % 360;
  return `hsl(${hash}, 40%, 62%)`;
}

export function knownContacts(state) {
  const list = [];
  for (const [id, r] of Object.entries(state.relations)) {
    if (r.met) {
      const c = getChar(id);
      if (c) list.push({ ...c, rel: r });
    }
  }
  return list;
}

export function formatClock(state) {
  return `${state.time.hour}:${String(state.time.minute).padStart(2, '0')}`;
}

export function relLabel(r) {
  if (r.isGuardian) return '亲人';
  if (r.l >= 80) return '挚爱';
  if (r.l >= 50) return '爱慕';
  if (r.f >= 70) return '挚友';
  if (r.f >= 40) return '熟识';
  if (r.f >= 20) return '相识';
  return '初识';
}

export function chipLabel(state, id) {
  const r = getRelation(state, id);
  return relLabel(r);
}

export function todayBirthdays(state) {
  const m = state.time.date.month;
  const d = state.time.date.day;
  return CHARACTERS.filter((c) => c.birthday && c.birthday.month === m && c.birthday.day === d);
}

export function seedGuardian(state) {
  const q = state.phone.qq;
  if (!q.contacts || !q.contacts.length) {
    q.contacts = [{ id: 'xulinan', nick: '许临安' }];
  }
  if (!q.chats || !q.chats['xulinan']) {
    q.chats['xulinan'] = [];
  }
}
