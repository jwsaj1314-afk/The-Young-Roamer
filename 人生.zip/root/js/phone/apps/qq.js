import { CHARACTERS } from '../../data/characters.js';
import { INITIAL_QQ_MESSAGES } from '../../data/misc.js';
import { getRelation } from '../../core/state.js';
import { isAIReady, chat, buildSystemPrompt } from '../../core/ai.js';
import { avatarColor, charName, formatClock, relLabel } from './common.js';

const STICKERS = ['😄', '😭', '😡', '🥰', '😴', '🤯', '🤗', '🥳', '😎', '🤔', '👍', '🎉', '🌸', '☕', '🌈', '💙'];
const GALLERY = [
  'linear-gradient(135deg,#7FA8C9,#BBD8F0)',
  'linear-gradient(135deg,#D9B26B,#F5D9A0)',
  'linear-gradient(135deg,#8FBFA0,#D7EBD9)',
  'linear-gradient(135deg,#B5A6C9,#E4D9F0)',
  'linear-gradient(135deg,#C77E7E,#F0C9C9)',
];

export function renderApp(id, screen, ctx) {
  const state = ctx.state;
  seed(state);

  screen.className = 'phone-app-screen app-qq';
  screen.innerHTML = `
    <div class="phone-app-bar">
      <button class="phone-back-btn" id="qqBack">‹</button>
      <div class="phone-app-title">QQ</div>
      <button class="phone-back-btn" id="qqRefresh" title="刷新">⟳</button>
      <button class="phone-back-btn" id="qqNew" title="发起会话">＋</button>
    </div>
    <div class="phone-app-body" id="qqBody"></div>`;

  screen.querySelector('#qqBack').addEventListener('click', () => ctx.goBack());
  screen.querySelector('#qqNew').addEventListener('click', () => newChat());
  screen.querySelector('#qqRefresh').addEventListener('click', () => refreshFeed());
  renderList();

  async function refreshFeed() {
    const q = state.phone.qq;
    const candidates = (q.contacts || []).filter((c) => c.id !== 'me');
    if (!candidates.length) return ctx.toast('还没有可联系的好友');
    const c = candidates[Math.floor(Math.random() * candidates.length)];
    const btn = screen.querySelector('#qqRefresh');
    if (btn) { btn.textContent = '…'; btn.disabled = true; }
    let msg = '';
    if (isAIReady()) {
      const sys = buildSystemPrompt(state, '一位好友主动发来新消息。');
      try {
        msg = (await chat([
          { role: 'system', content: sys.system + `\n你是「${c.nick}」，主动给玩家发一条云栖市的日常消息，20-40字，自然亲切，不要提及AI。` },
          { role: 'user', content: '发一条消息吧。' },
        ], { temperature: 0.95, max_tokens: 100 })).trim();
      } catch (e) {}
    }
    if (!msg) {
      const fallbacks = ['周末一起去镜湖走走？', '食堂今天有新菜，别忘了。', '作业写完了吗？', '明天见，早点睡。', '最近天气转凉，记得加件外套。'];
      msg = fallbacks[Math.floor(Math.random() * fallbacks.length)];
    }
    if (!q.chats[c.id]) q.chats[c.id] = [];
    q.chats[c.id].push({ from: c.id, content: msg, type: 'text', ts: Date.now(), read: false });
    q.unread[c.id] = (q.unread[c.id] || 0) + 1;
    ctx.save();
    if (btn) { btn.textContent = '⟳'; btn.disabled = false; }
    ctx.toast(`${c.nick} 发来新消息`);
    renderList();
  }

  function seed(s) {
    const q = s.phone.qq;
    if (!q.chats) q.chats = {};
    if (!q.unread) q.unread = {};
    if (!q.contacts) q.contacts = [{ id: 'xulinan', nick: '许临安' }];
    if (!q.chats['xulinan']) q.chats['xulinan'] = [];
    if (!q._seeded) {
      q._seeded = true;
      const init = INITIAL_QQ_MESSAGES || [{ from: 'xulinan', content: '到家了吗？路上还顺利吗？' }];
      init.forEach((m) => {
        if (!q.chats['xulinan'].some((x) => x.content === m.content)) {
          q.chats['xulinan'].push({ from: m.from, content: m.content, type: 'text', ts: m.timestamp || Date.now(), read: false });
          q.unread['xulinan'] = (q.unread['xulinan'] || 0) + 1;
        }
      });
      ctx.save();
    }
  }

  function renderList() {
    const q = state.phone.qq;
    screen.innerHTML = `
      <div class="phone-app-bar">
        <button class="phone-back-btn" id="qqBack">‹</button>
        <div class="phone-app-title">QQ</div>
        <button class="phone-back-btn" id="qqRefresh" title="刷新">⟳</button>
        <button class="phone-back-btn" id="qqNew" title="发起会话">＋</button>
      </div>
      <div class="phone-app-body" id="qqBody"></div>`;
    screen.querySelector('#qqBack').addEventListener('click', () => ctx.back());
    screen.querySelector('#qqNew').addEventListener('click', () => newChat());
    screen.querySelector('#qqRefresh').addEventListener('click', () => refreshFeed());
    const body = screen.querySelector('#qqBody');
    const unreadTotal = Object.values(q.unread || {}).reduce((a, b) => a + b, 0);
    const sorted = [...q.contacts].sort((a, b) => {
      const ta = (q.chats[a.id] || []).length ? q.chats[a.id][q.chats[a.id].length - 1].ts : 0;
      const tb = (q.chats[b.id] || []).length ? q.chats[b.id][q.chats[b.id].length - 1].ts : 0;
      return tb - ta;
    });

    body.innerHTML = `
      <div style="padding:6px 2px 10px;font-size:13px;color:var(--text-secondary);display:flex;justify-content:space-between;">
        <span>${unreadTotal ? `${unreadTotal} 条未读` : '没有未读消息'}</span>
        <span style="color:var(--text-faint);">${state.phone.qq.id || '13702149922'}</span>
      </div>
      ${sorted.length ? '' : '<div class="empty-hint">还没有联系人</div>'}
      ${sorted.map((c) => {
        const msgs = q.chats[c.id] || [];
        const last = msgs[msgs.length - 1];
        const un = q.unread[c.id] || 0;
        const char = CHARACTERS.find((x) => x.id === c.id);
        return `
        <div class="qq-list-item" data-id="${c.id}">
          <div class="qq-ava-wrap">
            <div class="qq-ava" style="background:${avatarColor(c.id)};">${c.nick.slice(0, 1)}</div>
            ${un ? `<span class="qq-badge">${un}</span>` : ''}
          </div>
          <div class="qq-info">
            <div class="qq-name">${c.nick}${char ? `<span class="tag">${relLabel(getRelation(state, char.id))}</span>` : ''}</div>
            <div class="qq-last">${last ? (last.from === 'me' ? '我：' : '') + lastPreview(last) : '开始聊天吧'}</div>
          </div>
          <span class="qq-time">${last ? formatClock(state) : ''}</span>
        </div>`;
      }).join('')}`;

    body.querySelectorAll('.qq-list-item').forEach((el) => {
      el.addEventListener('click', () => openChat(el.dataset.id));
    });
  }

  function lastPreview(m) {
    if (m.type === 'sticker') return '[表情]';
    if (m.type === 'image') return '[图片]';
    if (m.type === 'location') return '[位置] ' + (m.content || '');
    if (m.type === 'card') return '[名片] ' + (m.content || '');
    return m.content;
  }

  function newChat() {
    const body = screen.querySelector('#qqBody');
    ctx.setBack(renderList);
    let q = '';
    render();

    function render() {
      const known = CHARACTERS.filter((c) => state.relations[c.id] && state.relations[c.id].met)
        .filter((c) => !q || c.name.includes(q));
      body.innerHTML = `
        <div style="padding:6px 2px 10px;font-size:13px;color:var(--text-secondary);">选择要会话的角色</div>
        <input type="text" id="qqSearch" placeholder="搜索已认识的角色…" value="${q}" style="width:100%;margin-bottom:10px;">
        ${known.length ? '' : '<div class="empty-hint">未找到符合条件的角色<br>先去剧情里认识 TA 吧</div>'}
        ${known.map((c) => {
          const inContacts = (state.phone.qq.contacts || []).some((x) => x.id === c.id);
          return `
          <div class="qq-list-item" data-id="${c.id}">
            <div class="qq-ava" style="background:${avatarColor(c.id)};">${c.name.slice(0, 1)}</div>
            <div class="qq-info">
              <div class="qq-name">${c.name}</div>
              <div class="qq-last">${inContacts ? '已在联系人中' : '点击添加并会话'}</div>
            </div>
            <span class="tag">${inContacts ? '已有' : '添加'}</span>
          </div>`;
        }).join('')}`;
      body.querySelector('#qqSearch').addEventListener('input', (e) => {
        q = e.target.value.trim();
        render();
      });
      body.querySelectorAll('.qq-list-item').forEach((el) => {
        el.addEventListener('click', () => {
          const id = el.dataset.id;
          const qq = state.phone.qq;
          if (!qq.contacts.some((x) => x.id === id)) {
            const c = CHARACTERS.find((x) => x.id === id);
            qq.contacts.push({ id, nick: c ? c.name : id });
            qq.chats[id] = [];
          }
          ctx.save();
          openChat(id);
        });
      });
    }
  }

  async function openChat(charId) {
    const q = state.phone.qq;
    q.unread[charId] = 0;
    const char = CHARACTERS.find((x) => x.id === charId);
    ctx.save();

    screen.innerHTML = `
      <div class="phone-app-bar">
        <button class="phone-back-btn" id="chatBack">‹</button>
        <div class="phone-app-title">${charName(state, charId)}</div>
        <span class="tag">${char ? relLabel(getRelation(state, charId)) : ''}</span>
        <button class="phone-back-btn" id="chatMore" title="更多">···</button>
      </div>
      <div class="phone-app-body qq-chat">
        <div class="qq-msgs" id="qqMsgs"></div>
        <div class="qq-attach" id="qqAttach" style="display:none;"></div>
        <div class="qq-input-row">
          <button class="btn btn-sm" id="qqStickerBtn">😊</button>
          <button class="btn btn-sm" id="qqAttachBtn">⊕</button>
          <input type="text" id="qqInput" placeholder="输入消息…" maxlength="60">
          <button class="btn btn-sm btn-primary" id="qqSend">发送</button>
        </div>
      </div>`;
    screen.querySelector('#chatBack').addEventListener('click', renderList);
    screen.querySelector('#chatMore').addEventListener('click', () => {
      const known = CHARACTERS.filter((c) => state.relations[c.id] && state.relations[c.id].met && c.id !== charId);
      ctx.toast(known.length ? `可以把名片分享给：${known.map((c) => c.name).slice(0, 3).join('、')}${known.length > 3 ? ' 等' : ''}` : '还没有其他人可分享名片');
    });
    const msgsEl = screen.querySelector('#qqMsgs');
    const inputEl = screen.querySelector('#qqInput');
    const attachEl = screen.querySelector('#qqAttach');
    const stickerBtn = screen.querySelector('#qqStickerBtn');
    const attachBtn = screen.querySelector('#qqAttachBtn');

    renderMsgs();
    function renderMsgs() {
      msgsEl.innerHTML = '';
      (q.chats[charId] || []).forEach((m) => {
        const el = document.createElement('div');
        el.className = 'qq-msg ' + (m.from === 'me' ? 'me' : 'them');
        if (m.type === 'sticker') {
          el.innerHTML = `<span style="font-size:34px;">${m.content}</span>`;
        } else if (m.type === 'image') {
          el.innerHTML = `<div class="qq-img" style="background:${m.content};width:120px;height:90px;border-radius:10px;"></div><div style="font-size:11px;color:var(--text-faint);margin-top:2px;">[图片]</div>`;
        } else if (m.type === 'location') {
          el.innerHTML = `📍 ${m.content}<div style="font-size:11px;color:var(--text-faint);margin-top:2px;">云栖市地图位置</div>`;
        } else if (m.type === 'card') {
          const cc = CHARACTERS.find((x) => x.name === m.content);
          el.innerHTML = `<div class="qq-card"><div class="qq-card-ava" style="background:${cc ? avatarColor(cc.id) : '#888'};">${m.content.slice(0, 1)}</div><div><b>${m.content}</b><div style="font-size:11px;color:var(--text-faint);">名片</div></div></div>`;
        } else {
          el.textContent = m.content;
        }
        msgsEl.appendChild(el);
      });
      msgsEl.scrollTop = msgsEl.scrollHeight;
    }

    function pushMsg(m) {
      if (!q.chats[charId]) q.chats[charId] = [];
      q.chats[charId].push(m);
      ctx.save();
      renderMsgs();
    }

    async function send() {
      const text = inputEl.value.trim();
      if (!text) return;
      inputEl.value = '';
      pushMsg({ from: 'me', content: text, type: 'text', ts: Date.now() });
      await replyFlow(text);
    }

    async function replyFlow(userText) {
      const typing = document.createElement('div');
      typing.className = 'qq-typing';
      typing.textContent = charName(state, charId) + ' 正在输入…';
      msgsEl.appendChild(typing);
      msgsEl.scrollTop = msgsEl.scrollHeight;
      const delay = 1000 + Math.random() * 9000;
      await new Promise((r) => setTimeout(r, delay));
      typing.remove();
      const reply = await getReply(userText);
      pushMsg({ from: charId, content: reply, type: 'text', ts: Date.now() });
    }

    async function getReply(userText) {
      if (isAIReady()) {
        const sys = buildSystemPrompt(state, `你正以QQ消息的形式与「${charName(state, charId)}」聊天。`);
        const msgs = [
          { role: 'system', content: sys.system + `\n当前对话角色：${char ? char.name : ''}（${char ? char.personality : ''}）。请以该角色的口吻用简体中文回复，20-50字，符合其性格，不要提及这是AI。` },
          ...(q.chats[charId] || []).slice(-6).map((m) => ({ role: m.from === 'me' ? 'user' : 'assistant', content: m.type === 'text' ? m.content : '[' + m.type + ']' })),
        ];
        try {
          return (await chat(msgs, { temperature: 0.9, max_tokens: 120 })).trim();
        } catch (e) {
          return '（AI不可用：' + e.message + '）';
        }
      }
      const replies = [
        '嗯嗯，我在呢。',
        '今天过得怎么样？',
        '放学一起走走？',
        '知道了，你也注意休息。',
        '哈哈，挺好的。',
        '明天见。',
      ];
      return replies[Math.floor(Math.random() * replies.length)];
    }

    screen.querySelector('#qqSend').addEventListener('click', send);
    inputEl.addEventListener('keydown', (e) => { if (e.key === 'Enter') send(); });

    stickerBtn.addEventListener('click', () => {
      attachEl.style.display = attachEl.style.display === 'none' ? 'block' : 'none';
      attachEl.innerHTML = `
        <div style="font-size:11px;color:var(--text-faint);margin-bottom:4px;">发送表情</div>
        <div style="display:flex;flex-wrap:wrap;gap:6px;">
          ${STICKERS.map((s) => `<button class="btn btn-sm qq-sticker" data-s="${s}" style="font-size:22px;">${s}</button>`).join('')}
        </div>`;
      attachEl.querySelectorAll('.qq-sticker').forEach((b) => {
        b.addEventListener('click', () => {
          attachEl.style.display = 'none';
          pushMsg({ from: 'me', content: b.dataset.s, type: 'sticker', ts: Date.now() });
          replyFlow('[表情]');
        });
      });
    });

    attachBtn.addEventListener('click', () => {
      const showing = attachEl.style.display !== 'none';
      attachEl.style.display = showing ? 'none' : 'block';
      attachEl.innerHTML = `
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
          <button class="btn btn-sm" data-a="album">🖼 相册</button>
          <button class="btn btn-sm" data-a="camera">📷 拍照</button>
          <button class="btn btn-sm" data-a="location">📍 位置</button>
          <button class="btn btn-sm" data-a="card">👤 名片</button>
        </div>`;
      attachEl.querySelectorAll('[data-a]').forEach((b) => {
        b.addEventListener('click', () => {
          const kind = b.dataset.a;
          attachEl.style.display = 'none';
          if (kind === 'album' || kind === 'camera') {
            const img = GALLERY[Math.floor(Math.random() * GALLERY.length)];
            pushMsg({ from: 'me', content: img, type: 'image', ts: Date.now() });
            replyFlow('[图片]');
          } else if (kind === 'location') {
            const places = ['云栖汇购物中心', '中央公园', '镜湖', '金沙滩', '云栖港', '南河滨水步道', '市立图书馆', '云栖食集'];
            const loc = places[Math.floor(Math.random() * places.length)];
            pushMsg({ from: 'me', content: loc, type: 'location', ts: Date.now() });
            replyFlow('[位置] ' + loc);
          } else if (kind === 'card') {
            const known = CHARACTERS.filter((c) => state.relations[c.id] && state.relations[c.id].met);
            if (!known.length) return ctx.toast('还没有认识的人可以分享名片');
            const cc = known[Math.floor(Math.random() * known.length)];
            pushMsg({ from: 'me', content: cc.name, type: 'card', ts: Date.now() });
            replyFlow('[名片] ' + cc.name);
          }
        });
      });
    });
  }
}
