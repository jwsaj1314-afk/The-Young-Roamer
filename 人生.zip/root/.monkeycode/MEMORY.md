# User Instruction Memory

This file records user instructions, preferences, and teachings for reference in future interactions.

## Format

### User Instruction Entry
User instruction entries should follow this format:

[User Instruction Summary]
- Date: [YYYY-MM-DD]
- Context: [Mentioned scenario or time]
- Instructions:
  - [Content of user teaching or instruction, described line by line]

### Project Knowledge Entry
Entries discovered by the Agent during task execution should follow this format:

[Project Knowledge Summary]
- Date: [YYYY-MM-DD]
- Context: Discovered by Agent while performing [specific task description]
- Category: [Operations & Deployment|Build Methods|Testing Methods|Troubleshooting & Debugging|Workflow & Collaboration|Environment Configuration]
- Instructions:
  - [Specific knowledge points, described line by line]

## Deduplication Strategy
- Before adding a new entry, check for similar or identical instructions.
- If a duplicate is found, skip the new entry or merge it with the existing one.
- When merging, update the context or date information.
- This helps avoid redundant entries and keeps the memory file tidy.

## Entries

[Project Knowledge Summary]
- Date: 2026-08-12
- Context: Discovered by Agent while performing browser end-to-end verification of the 《此间少年行》 web game
- Category: Testing Methods
- Instructions:
  - 项目是纯静态前端（无构建工具），本地预览用 `cd /workspace && python3 -m http.server 8000`，通过后台终端启动（timeout=0）
  - e2e 用 puppeteer + 全局 Chrome：executablePath 为 `/root/.cache/puppeteer/chrome/linux-151.0.7922.77/chrome-linux64/chrome`，需 `--no-sandbox --disable-setuid-sandbox --disable-dev-shm-usage`
  - 测试脚本位于 `/tmp/opencode/e2e.mjs`（全流程回归）、`/tmp/opencode/e2e_loc.mjs`（地点面板）、`/tmp/opencode/e2e_ach.mjs`（成就）；页面选择器为 430x860 移动视口
  - e2e 环境没有 `page.waitForTimeout`，需自定义 `sleep`；QQ 发送后统计 3 条消息（我方+兜底回复）
  - 单文件语法校验用 `node --check js/xxx.js`
  - 成就解锁引擎挂在 `saveState`（storage.js），解锁时通过 `window` CustomEvent `cijian-ach` 通知 UI 弹 toast；相关进度字段在 `state.journal`（workCount/workTypes/earned/crimePeak/grayTrades/convenienceNight）

[Project Knowledge Summary]
- Date: 2026-08-12
- Context: Discovered by Agent while implementing 649 行新规格（侧边栏/作弊/开场/手机/色卡/内置角色）
- Category: Troubleshooting & Debugging
- Instructions:
  - 规格文档位置：`/workspace/.monkeycode-tmp-files/83e28027-long-input-20260812-171319.txt`（已被 git 忽略，勿提交）；后续更新规格：`412e2ae4-再来一次更新-1.txt`（模型拉取列表/中央行动输入框/按钮高亮跟随点击）
  - 侧边栏改版：七栏目含作弊（`panel-cheat`）、背包移除（在右上悬浮球）；侧边栏宽 60%、默认收起、右滑或点左边缘展开；信息条 `.sidebar-info` + 6 状态条 `.sidebar-status` + 动态提示 `.sidebar-tips`；角色头像 `.sbAvatar` 点击调 `showPortrait` 全屏立绘
  - 作弊面板入口在侧边栏（设置面板不再有 `#openCheat`），面板根元素 `#cheatBody`；开启开关 `#cheatOn`，功能含数值/状态/金钱/天数/小时/传送/技能/关系/物品/全员认识好感
  - 开场动画每次进入都播放（main.js bootstrap 无"有存档直接进游戏"分支）→ 大厅，大厅用 `#lbContinue`（有存档时显示）回主界面
  - 手机主页：底部 Dock `.phone-dock` 固定 qq,contacts,forum,diary 四应用；通知中心 `#phoneNotif` 下拉展开（`openNotif` 暴露在元素上供测试调用，`.notif-item` 计数）；长按拖动非固定应用改 `state.phone.layout`
  - 手机壁纸 8 预设（`WALLPAPERS` 在 phone/index.js）+ 导入图片（`custom:` 前缀 dataURL）；游戏背景 22 色卡 `BG_PALETTE`（panels.js）+ `bgPair`（main.js）
  - e2e 回归注意：`#openCheat` 选择器已失效，需用 `.sidebar-item.panel-cheat`；刷新后是开场→大厅（`#lbContinue`）而非直接 `#gameStage`；`#cheatBody` 代替 `#cheatPanel`

[Project Knowledge Summary]
- Date: 2026-08-13
- Context: Discovered by Agent while implementing 396 行手机 11 应用差异化规格 + 侧边栏模组/想法页规格
- Category: Testing Methods & Troubleshooting
- Instructions:
  - 手机 11 应用规格：`/workspace/.monkeycode-tmp-files/be010e96-14手机功能-1.txt`（git 忽略）；侧边栏模组/想法页规格：`/workspace/.monkeycode-tmp-files/4950c61f-更新-1.txt`（git 忽略）
  - 手机 app 主题：各 app 在 `renderApp` 里设 `screen.className = 'phone-app-screen app-xxx'`（qq/contacts/forum/diary/creations/tarot/calendar/wallet/mail/music/psettings），差异化主题 CSS 集中在 `css/phone.css`（`.app-xxx .phone-app-bar` 顶栏 + `.app-xxx.phone-app-screen` 背景 + 暗色 app 在类内重定义 `--text-*`/`--accent-*` 变量）；不新增全局渲染钩子
  - 手机 e2e 验证：进入游戏必须处理 免责声明→开场动画（点 `#skipBtn`）→大厅（点 `#lbStart`）→创建/进入；进入自由模式后点 `#floatPhone` 打开手机，点 `.phone-app[data-app="xx"]` 图标进 app，`.phone-homebar` 返回主屏；主题是否生效用 `getComputedStyle(.phone-app-screen).backgroundImage`/`.backgroundImage` 判断（纯色背景 app 的 backgroundImage 为 none，需读 backgroundColor）
  - 侧边栏弹窗入口是 `.sidebar-item.panel-xxx`（属性 attr/社交 social/日志 journal/成就 achievements/存档 save/模组 mods/作弊 cheat/设置 settings）；第 4 行左槽位固定为「📦 模组」`openModPanel`（panels.js，s.mods 存储，FileReader 导入 .json）
  - 想法页 `renderThoughts`（panels.js，社交面板 tab「想法」）只列已遇到角色姓名；对 relations 中 met 但不在 CHARACTERS/createdChars 的 id 视为 AI 生成角色，显示「加入角色库」按钮，调用 `addCreatedChar`（state.js 166 行，需构造含 id/name/age/identity 等的 char 对象）
  - 中央文本区 `renderFreeMode` 只含叙事+提示，无属性卡/动作按钮；属性在侧边栏 `.sidebar-status`，背包/手机/外出等入口在悬浮球 `#floatBag`/`#floatPhone`
